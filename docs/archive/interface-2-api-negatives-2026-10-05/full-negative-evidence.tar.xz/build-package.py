#!/usr/bin/env python3
"""Evidence-only assembly; never builds, runs a test, or modifies the repo."""
import difflib, gzip, hashlib, io, json, os, re, shutil, subprocess, tarfile
from pathlib import Path

ROOT = Path('/workspace/scratch/308e2340bae7')
REPO = ROOT / 'chatadhd'
OUT = ROOT / 'interface-2-api-negatives'
BASE = '5917495fe3def9a005dfdddc44623199843d1b0e'
OUT.mkdir(exist_ok=True)
notes, excluded, source_proofs = [], [], []

def digest(data): return hashlib.sha256(data).hexdigest()
def file_hash(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024*1024), b''): h.update(part)
    return h.hexdigest()
def put(relative, data):
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != data:
        raise RuntimeError('Refusing to overwrite differing retained evidence: '+str(path))
    path.write_bytes(data)
    return path
def copy(path, relative): return put(relative, path.read_bytes())
def copy_tree(source, relative):
    for path in sorted(source.rglob('*')):
        if not path.is_file(): continue
        name = path.name.lower()
        if path.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.gif','.o','.so','.a','.exe'} or name in {'analysis','a.out','loom_tests','loom-server'} or 'node_modules' in path.parts:
            excluded.append({'path':str(path),'reason':'screenshot or compiled binary; raw DOM/logs/source retained'})
            continue
        with path.open('rb') as stream: magic = stream.read(8)
        if magic.startswith((b'\x7fELF', b'!<arch>\n')):
            excluded.append({'path':str(path),'reason':'compiled ELF/archive; source/receipt retained'})
            continue
        copy(path, str(Path(relative)/path.relative_to(source)))

raw_names = ['api-build-initial.txt','api-build-resume.txt','api-baseline-fixtures.txt',
 'api-baseline-fixtures.receipt.json','api-baseline-fixtures-readonly.txt','api-baseline-fixtures-readonly.receipt.json',
 'method-ui-syntax.log','method-ui-syntax.cpp','graph-chat-ui-opaque-attempt-001.txt',
 'graph-chat-ui-profile-raw.txt','graph-chat-ui-native-attempt-001.txt',
 'graph-chat-negative-capture-reconstruction.json','graph-chat-negative-source-capture-replay.md',
 'graph-chat-negative-source-capture-replay.patch']
for name in raw_names: copy(ROOT/name,'raw/'+name)
for name in ['methods-ui-attempt-002','methods-ui-attempt-003','methods-ui-native-attempt-001',
 'methods-ui-native-attempt-002','methods-ui-native-attempt-003','methods-ui-native-attempt-004',
 'native-onboarding-2026-10-05','onboarding-host-negative-network-verification-2026-10-05']:
    copy_tree(ROOT/name,'raw/'+name)
copy_tree(ROOT/'analysis-native-evidence/claim-id-setup-failure-reconstructed',
          'raw/analysis-claim-id-setup-failure-reconstructed')
for name in ['api-ctest-inputs-after.json','api-ctest-execution-negative.json','api-ctest-final-LastTest.log']:
    if (ROOT/name).exists(): copy(ROOT/name,'raw/ctest-final-negative/'+name)
    else: notes.append('Missing '+name)
for directory in sorted(ROOT.glob('knowledge-semantic-isolated-*')):
    copy_tree(directory,'raw/'+directory.name)
for number in range(1,6):
    directory=ROOT/f'app-native-navigation-final-attempt-{number}-2026-10-05'
    copy_tree(directory,'raw/'+directory.name)
layout=ROOT/'app-native-navigation-final-attempt-6-2026-10-05'
copy(layout/'analysis-native-expert-preview.png','raw/observed-analysis-layout-clipping/analysis-native-expert-preview.png')
old_css=subprocess.check_output(['git','show','3807e31:loom/web/src/components/analysis-panel.css'],cwd=REPO)
assert digest(old_css)=='5d80c71a062b12c68c0e2e88da7d6a3cce480af45901c60c34dc561f3dd6f458'
assert old_css==subprocess.check_output(['git','show','27d7975:loom/web/src/components/analysis-panel.css'],cwd=REPO)
put('raw/observed-analysis-layout-clipping/analysis-panel.css.git-3807e31',old_css)
put('raw/observed-analysis-layout-clipping/observation.json',(json.dumps({
    'classification':'positive-functional / observed-negative-layout',
    'source_receipt':str(layout/'results.json'),
    'source_receipt_sha256':file_hash(layout/'results.json'),
    'functional_result':'7/7 passing; not classified as a failed functional run',
    'observation':'Analysis preview clipping observed in retained screenshot; owner reviewed and fixed CSS.',
    'old_css_source':{'classification':'exact recovered public git blob; root confirms unchanged until geometry fix',
        'ref':'3807e31:loom/web/src/components/analysis-panel.css','also_identical_ref':'27d7975',
        'sha256':digest(old_css),'bytes':len(old_css),
        'receipt_boundary':'No component CSS source hash in attempt6 source receipt; built combined CSS hash is distinct and cannot independently certify this source blob'},
    'source_inputs_reference':str(layout/'source-inputs'),
    'measurements':'No independent failing geometry measurement receipt existed; screenshot is an observation, not a measured regression assertion.'
},indent=2)+'\n').encode())

# Do not include positive attempts. The early native method source was actually
# retained during a separate analysis attempt; its hash is the original proof.
retained = ROOT/'analysis-native-evidence/current-attempt/method-ui-routes.h'
assert file_hash(retained)=='c4536a08af3cbb93cf6842adc7e9d37b3acd11c8db12c468bfc7318004294f64'
copy(retained,'replay/retained-original/method-ui-routes.h')

def patch(name, repo_path, faulty, classification, expected=None):
    current=(REPO/repo_path).read_bytes()
    if expected is not None: assert digest(faulty)==expected, (name,digest(faulty),expected)
    put('replay/'+name+'/'+Path(repo_path).name,faulty)
    diff=''.join(difflib.unified_diff(current.decode().splitlines(True),faulty.decode().splitlines(True),
        fromfile='a/'+repo_path,tofile='b/'+repo_path))
    put('replay/'+name+'/restore-fault.patch',diff.encode())
    source_proofs.append({'case':name,'path':repo_path,'classification':classification,
                         'current_sha256':digest(current),'replay_sha256':digest(faulty),
                         'historical_expected_sha256':expected,'hash_verified':expected is not None})

method=(REPO/'loom/server/src/method-ui-routes.h').read_text()
remove='''    if (!profile.is_object() || !selection.is_object()) return invalid("profile and reviewed selection must be objects");
    // Selection is configuration metadata, separate from immutable graph rows.
    // Both native slots must describe the exact choice reviewed by the owner;
    // keeping an old profile default would misreport the saved profile on read.
    profile["selection"] = selection;
'''
assert method.count(remove)==1
patch('profile-selection','loom/server/src/method-ui-routes.h',method.replace(remove,'').encode(),
      'reconstructed_exact_historical_hash; also identical original copy retained',
      'c4536a08af3cbb93cf6842adc7e9d37b3acd11c8db12c468bfc7318004294f64')
app=(REPO/'loom/server/src/app.cpp').read_text()
fixed='''    // Validation must not reorder opaque method/profile DTOs before the
    // native ordered-json config reader sees them.
    const std::string patch_bytes = req.body.empty() ? "{}" : req.body;
    int rc = loom_set_config_json(ctx_, patch_bytes.c_str());'''
old='''    int rc = loom_set_config_json(ctx_, body.dump(-1, ' ', false, json::error_handler_t::replace).c_str());'''
assert app.count(fixed)==1
app=app.replace(fixed,old).replace('''    const auto ordered_body = nlohmann::ordered_json::parse(req.body);
    const nlohmann::ordered_json patch = {{key, ordered_body["value"]}};''','''    const json patch = {{key, body["value"]}};''')
app=app.replace("patch.dump(-1, ' ', false, nlohmann::ordered_json::error_handler_t::replace)",
                "patch.dump(-1, ' ', false, json::error_handler_t::replace)")
patch('config-order','loom/server/src/app.cpp',app.encode(),'reconstructed_exact_historical_hash',
      'c34705e78485d980656898dd3b27c13788bae200602b97dd8da3c298a1251ebd')
onb=(REPO/'loom/web/e2e/onboarding-native.mjs').read_text()
onb=onb.replace('const runtimeFoundationInstalled = existsSync(path.join(loomRoot, "include/loom/runtime_profile.h"));\n','')
start=onb.index('    if (runtimeFoundationInstalled) {')
end=onb.index('    for (const field of Object.values',start)
onb=onb[:start]+'    assert.ok(snapshot.snapshot.runtime_profile.available !== false, "This gate requires the installed native RuntimeProfile foundation");\n'+onb[end:]
onb=onb.replace('''      provider_completions: 0, runtime_foundation_installed: runtimeFoundationInstalled,
      runtime_foundation_inspection: snapshot?.snapshot.runtime_profile,
      commands, final_revision: snapshot?.revision''','''      provider_completions: 0, commands, final_revision: snapshot?.revision''')
onb_expected=json.loads((ROOT/'native-onboarding-2026-10-05/source-before.json').read_text())['loom/web/e2e/onboarding-native.mjs']['sha256']
patch('onboarding-optional-foundation-test','loom/web/e2e/onboarding-native.mjs',onb.encode(),
      'reconstructed_exact_historical_hash',onb_expected)
host=(REPO/'loom/web/src/api/onboarding-host.ts').read_text()
host=host.replace('''          this.publish({ revision: null, reloadRequired: true, outcomeUnknown: true,
            error: "Native profile revision changed. Reload and inspect; the outcome of this edit is unverified." });''',
'''          this.publish({ revision: null, reloadRequired: true,
            error: "Native profile revision changed. Reload and inspect; the outcome of this edit is unverified." });''')
patch('onboarding-network-409','loom/web/src/api/onboarding-host.ts',host.encode(),
      'behavior_reconstruction_only; original source not retained and no original source hash')

# Original manifest portions are small; never load 60MB response captures just
# to extract their source receipts.
def section(path,name):
    lines=[]; collecting=False
    with path.open() as stream:
        for line in stream:
            if line.startswith('  "'+name+'":'):
                collecting=True; lines.append(line.split(':',1)[1]); continue
            if collecting and re.match(r'^  "[^\"]+":',line): break
            if collecting: lines.append(line)
    return json.loads(''.join(lines).strip().rstrip(',')) if lines else None

commits=[BASE,'f8338bc','27d7975','f145d9d','447b589']
for case in ['methods-ui-native-attempt-001','methods-ui-native-attempt-002','methods-ui-native-attempt-003','methods-ui-native-attempt-004']:
    receipt=section(ROOT/case/'results.json','manifestBefore')
    for name,expected in receipt['sources'].items():
        repo_path='loom/'+name; p=REPO/repo_path; data=None; kind=None
        if p.exists() and file_hash(p)==expected: data=p.read_bytes(); kind='current_copy_matches_original_receipt_hash'
        elif name=='server/src/app.cpp' and digest(app.encode())==expected: data=app.encode(); kind='reconstructed_exact_historical_hash'
        elif name=='server/src/method-ui-routes.h' and file_hash(retained)==expected: data=retained.read_bytes(); kind='retained_original_source'
        else:
            for commit in commits:
                candidate=subprocess.run(['git','show',commit+':'+repo_path],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
                if candidate.returncode==0 and digest(candidate.stdout)==expected:
                    data=candidate.stdout;kind='git_blob_matches_original_receipt_hash';break
        if data is not None:
            assert digest(data)==expected
            copy_path='replay/historical-hash-matches/'+expected+'/'+Path(name).name
            put(copy_path,data)
        else: copy_path=None;kind='missing_original_source_bytes'
        source_proofs.append({'case':case,'path':repo_path,'historical_expected_sha256':expected,
                             'classification':kind,'archive_path':copy_path,'hash_verified':data is not None})

# A complete tracked implementation/build/tests/fixture snapshot from the
# pinned public commit. Historical result archives, holdout keys, screenshots,
# compiled outputs and third-party dependency installs are explicitly excluded.
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE],cwd=REPO).decode().splitlines()
selected=[]
for name in tracked:
    if name.startswith(('history/','docs/archive/','docs/reports/','docs/verification/','docs/research/')) or '/results/' in name or '/real-holdout-key' in name or 'node_modules/' in name or '/build/' in name or '/dist/' in name:
        excluded.append({'path':BASE+':'+name,'reason':'historical result/private-key namespace/build output outside replay source scope'});continue
    if name.endswith(('.o','.a','.so','.dll','.exe','.png','.jpg','.jpeg','.gif','.webp','.pdf','.pptx')):
        excluded.append({'path':BASE+':'+name,'reason':'compiled/output/media artifact; not required for source replay'});continue
    selected.append(name)
archive=subprocess.Popen(['git','archive','--format=tar',BASE,'--',*selected],cwd=REPO,stdout=subprocess.PIPE)
base_manifest={}
with tarfile.open(fileobj=archive.stdout,mode='r|') as source:
    for member in source:
        if not member.isfile(): continue
        if member.name not in selected: raise RuntimeError('Unexpected source archive member '+member.name)
        data=source.extractfile(member).read()
        put('source-base-5917495/'+member.name,data)
        base_manifest[member.name]={'bytes':len(data),'sha256':digest(data)}
assert archive.wait()==0
put('source-base-manifest.json',(json.dumps({'commit':BASE,'files':base_manifest,'excluded':excluded},indent=2)+'\n').encode())
put('source-replay-proofs.json',(json.dumps(source_proofs,indent=2)+'\n').encode())

guards=[]
for number in range(1,6):
    case=f'app-native-navigation-final-attempt-{number}-2026-10-05'
    receipt=json.loads((ROOT/case/'results.json').read_text())
    sources=[]
    for path,expected in receipt['inputsBefore']['sources'].items():
        archived=OUT/'raw'/case/'source-inputs'/path
        actual=file_hash(archived)
        assert actual==expected,(case,path,actual,expected)
        sources.append({'path':path,'recorded_sha256':expected,'archived_sha256':actual,'exact_match':True})
    guards.append({'case':case,'original_inputs_stable':receipt.get('inputs_stable'),
        'binary_before':receipt['inputsBefore']['binary'],'binary_after':receipt['inputsAfter']['binary'],
        'binary_retained':False,'dist_retained':False,'sources':sources})
put('negative-sourceguard-manifest.json',(json.dumps({
    'schema':'loom.interface2_negative_sources/1','whole_app_source_guards':guards,
    'historical_method_replay_proofs':source_proofs,
    'ctest':'Full before/after inputs preserved, mixed server/app/header run; native core/test bytes unchanged per recorded receipt. Exact binaries excluded.',
    'layout_observation':'One screenshot from passing functional attempt6, separately labelled observed layout clipping. Old component CSS recovered as exact public git blob; no component CSS source hash or failing geometry assertion in original receipt.',
    'no_original_source_claim_for_missing_bytes':True,'no_build_or_test_replay_performed':True
},indent=2)+'\n').encode())

# Secret/privacy review is separate from cryptographic preservation. Raw test
# captures are not rewritten. Every candidate is retained as a hash/length,
# never a plaintext credential in a tool output.
credential=re.compile(rb'(?:api_key|authorization|x-api-key|access_token|password|client_secret)[\\"\s:,{]+([^\r\n]{1,180})',re.I)
hard_secret=re.compile(rb'(?:sk-(?:proj-|or-v1-)?[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|AIza[A-Za-z0-9_-]{30,}|-----BEGIN(?: RSA| EC| OPENSSH)? PRIVATE KEY-----)')
hard=[]; candidates=[]; files=[]
for p in sorted(OUT.rglob('*')):
    if not p.is_file() or p.name.endswith(('.tar.gz','.tar.xz')): continue
    size=p.stat().st_size; files.append({'path':str(p.relative_to(OUT)),'bytes':size,'sha256':file_hash(p)})
    tail=b''
    with p.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            chunk=tail+chunk
            for m in hard_secret.finditer(chunk): hard.append({'path':str(p.relative_to(OUT)),'value_sha256':digest(m.group()),'bytes':len(m.group())})
            # Source code has get_string("api_key") and schema examples. These
            # are candidate contexts, not evidence of a retained credential.
            for m in credential.finditer(chunk):
                candidate=m.group(1)
                candidates.append({'path':str(p.relative_to(OUT)),'context_sha256':digest(candidate),'bytes':len(candidate),
                    'classification':'authored fixture or code/schema context; inspect source provenance'})
            tail=chunk[-256:]
reviewed_patterns = {
    'bc95a08f202dcf78189c5369c1bba4b91d4db0e69c63cfc85a29dc184e1b5ee3':
        'False positive inside a public TaskEngine report filename; no credential.',
    '7b7386734a119f82ed45390cb6135d4aae9a91b0e6c86367c6d2239f49831b12':
        'Authored public test_credential_handoff.py fabricated string; explicitly synthetic error-path fixture.',
}
unreviewed=[row for row in hard if row['value_sha256'] not in reviewed_patterns]
if unreviewed:
    put('secret-scan-blocked.json',(json.dumps(unreviewed,indent=2)+'\n').encode())
    raise RuntimeError('High-risk credential patterns require inspection before packaging; values not printed')
put('privacy-secret-review.json',(json.dumps({'unreviewed_high_risk_credential_matches':unreviewed,
    'reviewed_pattern_matches':[dict(row,classification=reviewed_patterns[row['value_sha256']]) for row in hard],
    'credential_context_count':len(candidates),
    'credential_contexts':candidates,'data_provenance':'Public authored synthetic fixtures, loopback-only captures and pinned public repository source.',
    'fake_tokens':'Ephemeral loopback/test credential literals may be present; these are fixtures, never production secrets.',
    'limits':'Pattern scan is not mathematical proof. Source provenance and loopback fixture ownership were checked; private user data was not requested or collected.',
    'database_captures':'Whole-App failed-native-data is authored synthetic state retained because it is necessary for replay; compiled binaries and screenshots are excluded.'},indent=2)+'\n').encode())

readme='''# W10 API increment — full negative evidence

This archive is evidence, not a passing validation receipt. Raw failed attempts are retained unchanged. Final positive runs are deliberately separate.

## Negative cases

| Case | Failure and scope | Replay/source boundary |
|---|---|---|
| api-build-initial / resume | Initial build incomplete; resumed link rejected an empty prompt_contract.cpp.o | Full logs retained. The original zero-byte object and contemporaneous resource metrics were not saved. Resource cause is not proven by this archive. |
| method-ui-syntax | Compiler killed; exit 1 | Full log and source retained; host memory pressure is environmental, not a deterministic source failure. |
| baseline fixtures (first two) | Geometry gate saw six POST then six GET method-settings reads during navigation | Full logs/receipts retained. Historical built web bundles were not retained. |
| methods-ui-attempt-002 / 003 | Missing visible lineage assertion; then only 9 of 10 declared groups | Full synthetic responses/logs retained. Exact original uncommitted JS sources lack a complete receipt. |
| methods-ui-native-attempt-001 | 11/14, native snapshot locator timeout | Complete original request/response captures and manifests retained. Missing JS source bytes are explicitly listed in source-replay-proofs.json. |
| methods-ui-native-attempt-002 | 12/14, float serialization assertion | Same; config-order faulty app is reconstructed with the exact historical SHA. |
| methods-ui-native-attempt-003 | 12/14, selected-profile readback timeout | Original faulty method header retained; reconstructed copy matches exact historical SHA. Source/binary changed between before/after receipts: mixed attempt, not a frozen whole-build receipt. |
| methods-ui-native-attempt-004 | 12/14, result locator timeout | Complete full response/source receipts and log now retained; original test JS hash is checked independently and missing bytes remain explicit. |
| first native onboarding | 1/8, new test wrongly required optional absent W11 foundation | The erroneous test is reconstructed to its exact recorded SHA; source/hash receipts retained. This was a test assumption, not a native onboarding failure. |
| onboarding-host network | Expected unknown-outcome marker absent after lost response and browser-retried POST produced HTTP409 | Full DOM/commands/error retained. Original source not retained; behavior-only fault patch is labelled reconstructed. |
| graph-chat opaque 001 / profile-raw | Malformed authored JSON fixture; then numeric representation assertion | Full logs retained; original uncommitted fixture source/bundle unavailable. |
| graph-chat native 001 | preparation_error/conflict instead of candidate: capture ID collision | Original full negative plus reconstructed byte strings/locators/IDs and fault patch retained. Reconstructed IDs match receipt; faulty native rebuild was not rerun. |
| analysis claim-ID setup | SIGABRT in fixture setup before provider request | Original stderr retained; source/header copies explicitly reconstructed after temp cleanup. No original full-source hash proof. |
| whole-App attempts 1–4 | New test assumed incorrect native data shapes | Exact captured source-inputs, synthetic DB, full HTTP/DOM/error retained; screenshots excluded. |
| whole-App attempt 5 | AnalysisPanel lost LoomHttpApi receiver (`reading req`); zero analysis HTTP requests | Exact captured source-inputs, synthetic DB, full HTTP/DOM/error retained; production binding bug, not native analysis failure. |
| observed Analysis layout clipping | Screenshot from functionally positive attempt 6 (7/7) showed clipping | Necessary PNG plus exact public old CSS blob retained. Separate positive receipt/source-inputs referenced; component CSS hash was not in that receipt, no measured negative geometry receipt existed. |
| full CTest | 120/121 entries passed; knowledge_semantic failed 3 cases/8 assertions | Full log/JUnit/receipt/LastTest/before+after inputs retained. Mixed server/app/header changes during test, not a frozen receipt. Execution-count report is derived after the run, not an original guard receipt. |
| isolated knowledge_semantic | Root-authored read-only focused reproduction; diagnosis attributes W1 stable operation ID + W2 unresolved accounting interaction | Full stdout/JUnit/receipt/diagnosis retained independently; no test thresholds or production source modified here. |

## Source and replay

`source-base-5917495/` contains tracked implementation/build/test/data source from public commit `5917495fe3def9a005dfdddc44623199843d1b0e`; `source-base-manifest.json` lists every byte hash and exclusion. Historical reports/results, compiled binaries, screenshots, media artifacts and holdout-key namespaces are excluded. For the complete authoritative repository and its historical resources, use an isolated checkout of that exact public commit. This package does not claim to replace every excluded repository artifact or the original compiler/system image.

`source-replay-proofs.json` distinguishes originally retained copies, current bytes matching historical hashes, exact-hash reconstructions, and missing original bytes. The config-order reconstruction matches `c34705e...`; the pre-selection header matches `c4536a08...` and also has a separately retained original copy. Exact original test blobs are not claimed where the receipt hashes differ.

Apply one fault only to an isolated checkout, never to the production branch:

```
git checkout 5917495fe3def9a005dfdddc44623199843d1b0e
git apply /absolute/package/replay/config-order/restore-fault.patch
# alternatively: replay/profile-selection/restore-fault.patch
# or raw/graph-chat-negative-source-capture-replay.patch
```

Build the isolated server with the recorded compiler/CMake settings, install the pinned web dependencies and build web. Run `LOOM_SERVER_BIN=<isolated-server> node e2e/methods-ui.mjs --native` or `node e2e/graph-chat-ui.mjs --native` from `loom/web`. Use the archived exact source where it exists; otherwise this is a behavioral replay recipe, not byte-for-byte replay proof. Whole-App attempts retain source-inputs and fixture DB for their exact frontend/native boundary; invoke `e2e/app-native-navigation.mjs --native` using the retained source and a fresh evidence directory. First-onboarding replay uses its exact reconstructed erroneous test and native bridge; the absent optional foundation must remain absent. The onboarding-network patch reproduces only the HTTP409 classification fault and requires the lost-response/browser-retry fixture from `e2e/onboarding-host.mjs`.

The native analysis setup reproduction uses the retained `analysis.cc` plus copied headers/fixture and the compile/run recipe in the analysis harness; the result explicitly states reconstructed source and SIGABRT before dispatch. CTest replay uses the preserved command receipt and pinned source; exact old binaries were excluded. Its original guard/resources/mixed-server execution cannot be fabricated from a later build.

No compiler, test or provider call was run while packaging. Fake loopback credential literals are labelled fixtures; raw evidence is unredacted after the source-provenance and secret-pattern review. `verify-package.py` checks every archived member against the manifest. Gzip and XZ archives contain identical uncompressed members; compression receipts are outside the archives to avoid self-reference.
'''
put('README.md',readme.encode())
verifier='''#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for row in manifest['files']:
    p=root/row['path'];data=p.read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
print('verified',len(manifest['files']),'files; raw bytes unchanged')
'''
put('verify-package.py',verifier.encode())
files=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name not in {'manifest.json','archive-receipt.json'} and not p.name.endswith(('.tar','.tar.gz','.tar.xz')):
        files.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':file_hash(p)})
put('manifest.json',(json.dumps({'schema':'loom.interface2_negative_archive/1','base_commit':BASE,
    'files':files,'raw_bytes':sum(p['bytes'] for p in files),'notes':notes,'excluded':excluded,
    'no_builds_or_tests_performed':True,'positive_runs_included':False},indent=2)+'\n').encode())

# Deterministic tar metadata/gzip timestamp. Do not archive the archives or
# receipt inside themselves; preserve all raw captures plus reconstruction docs.
tar_path=OUT/'interface-2-api-negatives.tar'
with tarfile.open(tar_path,'w',format=tarfile.PAX_FORMAT) as tar:
    for p in sorted(OUT.rglob('*')):
        if not p.is_file() or p==tar_path or p.name=='archive-receipt.json' or p.name.endswith(('.tar.gz','.tar.xz')):continue
        name=str(p.relative_to(OUT));info=tar.gettarinfo(str(p),arcname=name)
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with p.open('rb') as stream:tar.addfile(info,stream)
gz=OUT/'interface-2-api-negatives.tar.gz'
with tar_path.open('rb') as stream, gz.open('wb') as destination:
    with gzip.GzipFile(filename='',mode='wb',compresslevel=9,fileobj=destination,mtime=0) as zipped:
        shutil.copyfileobj(stream,zipped)
# Fixed one thread, bounded compressor memory; dictionary may be reduced by xz.
xz=OUT/'interface-2-api-negatives.tar.xz'
with xz.open('wb') as destination:
    run=subprocess.run(['xz','-9e','--threads=1','--memlimit-compress=192MiB','-c',str(tar_path)],stdout=destination,stderr=subprocess.PIPE)
assert run.returncode==0,run.stderr.decode()
receipt={'files':len(files),'payload_bytes':sum(p['bytes'] for p in files),'tar_bytes':tar_path.stat().st_size,
         'archives':{p.name:{'bytes':p.stat().st_size,'sha256':file_hash(p)} for p in [gz,xz]},
         'xz_command':['xz','-9e','--threads=1','--memlimit-compress=192MiB'],'xz_stderr':run.stderr.decode(),
         'source_replay_missing':[p for p in source_proofs if p['classification']=='missing_original_source_bytes']}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
tar_path.unlink()
print(json.dumps(receipt,indent=2))
