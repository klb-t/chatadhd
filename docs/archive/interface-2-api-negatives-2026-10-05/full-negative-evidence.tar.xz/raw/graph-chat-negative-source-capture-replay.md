The preserved negative output is `graph-chat-ui-native-attempt-001.txt`.
The first native graph mode reached `preparation_error` / `conflict` and kept the ordinary model text. This was a UI capture identity collision with MethodRegistry runtime capture, not a provider schema failure.

`graph-chat-negative-capture-reconstruction.json` retains the exact three captured definition/prompt byte strings and locators. Recomputing Observation IDs with the old content-only unit `un_<source_sha256>` reproduces all three IDs in the original failing method-resolution receipt exactly:

- method: `ob_69c7947c7962c91e`
- recipe: `ob_5298e3fe8309a751`
- prompt: `ob_dd439360194a2f78`

`graph-chat-negative-source-capture-replay.patch` restores that faulty unit identity in `profile_preview`. Apply only in an isolated checkout, build its server, and run `LOOM_SERVER_BIN=<isolated-server> node e2e/graph-chat-ui.mjs --native` from `loom/web`. The expected first-mode assertion is `candidate` versus `preparation_error` with conflict. Never retain the fault patch in production source.

The reconstructed IDs were checked offline. A second native build with the fault patch was not run during this session: the parent owns native compilation, and required final builds were active. The original full negative log and this replay recipe are retained independently of the fixed production code.
