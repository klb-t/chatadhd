
#include "analysis-ui-routes.h"
#include "loom/usage_policy.h"
#include "loom/util/fs.h"
#include <cassert>
#include <iostream>
using namespace loom;
using loom_server::native_ui::Json;
template<class T> T must(Result<T> result) { if(!result) throw std::runtime_error(result.error().to_string()); return std::move(result).value(); }
int main(int argc,char** argv) {
 assert(argc==2);
 auto empty_stream=must(loom_server::analysis_ui_detail::decode("data: [DONE]\n\n",true));
 assert(!empty_stream["choices"][0]["message"].contains("content"));
 auto service_stream=must(loom_server::analysis_ui_detail::decode("data: {\"error\":{\"message\":\"scripted service error\"}}\n\ndata: [DONE]\n\n",true));
 assert(service_stream.contains("error")&&!service_stream["choices"][0]["message"].contains("content"));
 auto model_stream=must(loom_server::analysis_ui_detail::decode("data: {\"model\":\"scripted-model\",\"choices\":[{\"delta\":{\"content\":\"{}\"}}]}\n\ndata: [DONE]\n\n",true));
 assert(model_stream["model"]=="scripted-model"&&model_stream["choices"][0]["message"]["content"]=="{}");
 fsutil::TempDir dir; auto http=std::make_shared<net::ScriptedTransport>(); RuntimeOptions options;
 options.data_dir=dir.path().string(); options.start_workers=false; options.http=http;
 LoomContext context; context.rt=must(Runtime::open(options)); auto& rt=*context.rt;
 rt.config().set("loom_usage_policy", usage_policy_defaults()); rt.secrets().set("api_key", "native-fixture-private-key");
 auto contract=must(extract::prompts::resolve("semantic.analysis"));
 contract.definition["validation_mode"]="strict"; contract.definition["output_schema"]=Json{{"type","object"},{"required",Json::array({"result"})},{"properties",{{"result",{{"type","boolean"}}}}}};
 contract=must(extract::prompts::from_snapshot(contract.definition));
 const std::string known="2026-10-05T00:00:00Z";
 const Json origin{{"kind","user"},{"actor","synthetic-test-owner"},{"model",nullptr},{"recipe_sha256",nullptr},{"response_sha256",nullptr}};
 // Install the actual owner-data graph-chat preset, including its real recipe
 // and prompt relations, through exactly the native profile preview/accept API.
 const auto data=must(json::parse(must(fsutil::read_file(argv[1]))));
 const auto preset=data["presets"][0];
 const auto kinds=data["vocabulary"]["kinds"],predicates=data["vocabulary"]["predicates"];
 Json profile{{"vocabulary",data["vocabulary"]},{"entities",Json::array()},{"claims",Json::array()},{"sources",Json::array()},{"selection",preset["selection"]}};
 std::map<std::string,std::string> ids;
 for(const auto& spec:preset["entities"]) {
  Json entity=data["entity_template"]; Json attrs=spec["attrs"]; std::string version_hash;
  if(attrs.contains("definition")) {version_hash=loom_server::method_ui::hash(attrs["definition"]);attrs["definition_sha256"]=version_hash;}
  if(attrs.contains("text")) {version_hash=Sha256::hex(attrs["text"].get<std::string>());attrs["text_sha256"]=version_hash;}
  const auto base=spec["id"].get<std::string>(); const auto id=version_hash.empty()?base:base+":"+version_hash; ids[base]=id;
  entity["id"]=id;entity["canonical_key"]=id;entity["kind"]=kinds[spec["role"].get<std::string>()];entity["label"]=spec["label"];entity["attrs"]=attrs;
  profile["entities"].push_back(entity);
 }
 for(const auto& spec:preset["claims"]) {
  Json row=data["claim_template"];row["subject"]=ids.at(spec["subject"].get<std::string>());row["object"]=ids.at(spec["object"].get<std::string>());row["predicate"]=predicates[spec["predicate"].get<std::string>()];
  auto claim=must(model::Claim::from_json(row));claim.id=model::Claim::make_id(claim.subject,claim.predicate,claim.object,claim.value,claim.qualifiers);profile["claims"].push_back(claim.to_json());
 }
 for(auto& member:profile["selection"]["members"]) member["method_version_id"]=ids.at(member["method_version_id"].get<std::string>());
 const std::string version_id=profile["selection"]["members"][0]["method_version_id"];
 context::MethodRegistry registry(rt.db());
 auto installation=must(loom_server::method_ui::execute(rt,Json{{"action","profile_preview"},{"profile_json",profile.dump()},{"target","synthetic-analysis-library"},{"actor","synthetic-owner"},{"known_at",known}}));
 auto installed=must(loom_server::method_ui::execute(rt,Json{{"action","accept"},{"request_json",installation["accept_request_json"]}}));
 const auto original_receipt=installed["receipt"]["id"].get<std::string>();
 auto snapshot=must(registry.load(installation["profile"],{original_receipt}));
 auto original_plan=must(registry.resolve(snapshot,Json::object(),loom_server::method_ui::capabilities()));
 assert(!original_plan["leaves"][0]["recipe"].is_null()&&!original_plan["leaves"][0]["prompt"].is_null());
 Json identity_claims=Json::array();
 for(const auto& claim:snapshot["claims"]) if(claim["subject"]==version_id&&claim["predicate"]==predicates["version_of"]&&claim["assessment"]["status"]=="active") identity_claims.push_back(claim["id"]);
 assert(!identity_claims.empty());
 Json attrs_patch{{"definition",{{"execution_capability","analysis.http"},{"analysis_contract",contract.definition},{"analysis_contract_sha256",contract.hash},{"analysis_result_kind","synthetic.analysis_response"}}}};
 Json remove_paths=Json::array();for(const auto* key:{"recipe_sha256","prompt_sha256","preset_sha256","parameter_set_sha256"})remove_paths.push_back(Json::array({"definition",key}));
 const Json edited=must(loom_server::method_ui::execute(rt,Json{{"action","version_edit"},{"snapshot_json",snapshot.dump()},{"entity_id",version_id},{"attrs_patch_json",attrs_patch.dump()},{"outgoing_claim_ids",identity_claims},{"attrs_remove_paths",remove_paths},{"target","synthetic-analysis-library"},{"actor","synthetic-owner"},{"known_at",known}}));
 assert(edited["profile_json"].get<std::string>().find("1.0")!=std::string::npos);
 auto accepted=must(registry.accept(must(json::parse(edited["accept_request_json"].get<std::string>()))));
 const auto receipt=accepted["receipt"]["id"];
 const std::string bytes="{  \"model\" : \"offline/test\", \"messages\" : [{\"role\":\"user\",\"content\":\"exact α🙂\"}]  }\n";
 Json command{{"operation","prepare"},{"prompt_snapshot",contract.definition},{"model","offline/test"},{"provider","https://scripted.invalid"},{"bindings",{{"text","synthetic source"}}},{"body_bytes",bytes},
 {"method",{{"profile_json",edited["profile_json"]},{"receipt_ids",Json::array({original_receipt,receipt})},{"selection_json",Json{{"members",Json::array({Json{{"method_version_id",edited["new_version_id"]}}})},{"fusion",nullptr}}.dump()},{"target","synthetic-analysis-library"},{"origin",origin},{"known_at",known}}}};
 loom_server::analysis_ui_detail::State state; auto prepared=must(loom_server::analysis_ui_detail::dispatch(&context,state,command));
 assert(http->requests().empty()); assert(!std::filesystem::exists(dir.path()/"usage-policy.sqlite"));
 assert(prepared.dump().find("native-fixture-private-key")==std::string::npos); assert(prepared["request"]["body_bytes"]==bytes); assert(prepared["graph_binding_available"]==true);
 const Json payload{{"choices",Json::array({Json{{"message",{{"content","{\"result\":true}"}}},{"finish_reason","stop"}}})},{"usage",{{"completion_tokens",1}}},{"model","offline/test"}};
 http->expect("POST","https://scripted.invalid",net::ScriptedTransport::Reply::json(200,payload));
 Json dispatch{{"operation","execute"},{"prepared_id",prepared["prepared_id"]},{"request_identity_hash",prepared["request_identity_hash"]}};
 auto result=must(loom_server::analysis_ui_detail::dispatch(&context,state,dispatch));
 if(result["status"]!="completed") throw std::runtime_error(result.dump());
 assert(http->requests().size()==1); assert(http->requests()[0].body==bytes); assert(net::header_value(http->requests()[0].headers,"Authorization")=="Bearer native-fixture-private-key");
 assert(result["result"]["output_validation"]["valid"]==true); assert(result["result"]["graph_binding_status"]=="native_result_run_version_edges");
 const auto result_id=result["result"]["result_entity_id"]; bool run_edge=false,version_edge=false;
 for(const auto& edge:result["result"]["candidate_packet"]["claims"]) if(edge["subject"]==result_id) {run_edge=run_edge||edge["predicate"]==predicates["produced_in_run"];version_edge=version_edge||edge["predicate"]==predicates["produced_by_method_version"];}
 assert(run_edge&&version_edge); auto stored=must(registry.accept(must(json::parse(result["result"]["accept_request_json"].get<std::string>())))); assert(stored.contains("receipt"));
 auto replay=must(loom_server::analysis_ui_detail::dispatch(&context,state,dispatch)); assert(replay["replayed"]==true); assert(http->requests().size()==1);
 command["execution"]={{"estimated_output_tokens",100}}; auto held=must(loom_server::analysis_ui_detail::dispatch(&context,state,command));
 dispatch["prepared_id"]=held["prepared_id"]; dispatch["request_identity_hash"]=held["request_identity_hash"];
 auto pause=must(loom_server::analysis_ui_detail::dispatch(&context,state,dispatch)); assert(pause["status"]=="requires_confirmation"); assert(http->requests().size()==1);
 dispatch["confirmation"]={{"receipt_id",pause["result"]["usage_decision"]["receipt_id"]},{"approved",true},{"ref","synthetic-exact-owner-confirmation"}};
 http->expect("POST","https://scripted.invalid",net::ScriptedTransport::Reply::json(200,payload));
 auto confirmed=must(loom_server::analysis_ui_detail::dispatch(&context,state,dispatch)); if(confirmed["status"]!="completed")throw std::runtime_error(confirmed.dump()); assert(http->requests().size()==2);
 auto frozen=command; frozen.erase("method"); auto raw=must(loom_server::analysis_ui_detail::dispatch(&context,state,frozen)); dispatch={{"operation","execute"},{"prepared_id",raw["prepared_id"]},{"request_identity_hash",raw["request_identity_hash"]}};
 auto unavailable=loom_server::analysis_ui_detail::dispatch(&context,state,dispatch); assert(!unavailable&&unavailable.error().code==Errc::Unavailable); assert(http->requests().size()==2);
 command["execution"]=Json::object();
 auto attempt=[&](net::ScriptedTransport::Reply reply) {
  auto fresh=must(loom_server::analysis_ui_detail::dispatch(&context,state,command));
  http->expect("POST","https://scripted.invalid",std::move(reply));
  return must(loom_server::analysis_ui_detail::dispatch(&context,state,Json{{"operation","execute"},{"prepared_id",fresh["prepared_id"]},{"request_identity_hash",fresh["request_identity_hash"]}}));
 };
 auto invalid_model=payload; invalid_model["choices"][0]["message"]["content"]="{\"wrong\":true}";
 auto rejected=attempt(net::ScriptedTransport::Reply::json(200,invalid_model));
 assert(rejected["status"]=="schema_rejected"&&rejected["result"]["model_content_available"]==true);
 assert(rejected["result"]["candidate_packet"]["entities"].size()>0);
 auto service=attempt(net::ScriptedTransport::Reply::json(500,Json{{"error",{{"message","scripted service error"}}}}));
 assert(service["status"]=="transport_error"&&service["result"]["model_content_available"]==false&&service["result"]["content_truth"]=="service_or_transport_result");
 for(const auto& entity:service["result"]["candidate_packet"]["entities"]) if(entity["id"]==service["result"]["result_entity_id"]) assert(!entity["attrs"].contains("model_origin"));
 std::string binary_response(1,static_cast<char>(0xff)); binary_response+="scripted binary error";
 auto binary_service=attempt(net::ScriptedTransport::Reply::text(503,binary_response));
 assert(binary_service["result"]["raw_response_bytes"].is_null());
 assert(must(base64::decode(binary_service["result"]["raw_response_base64"].get<std::string>(),true))==binary_response);
 auto ledger=must(UsagePolicy::open(dir.path()/"usage-policy.sqlite",usage_policy_defaults()));
 auto accounting=must(ledger->inspect(prepared["usage_estimate"]["baseline_key"].get<std::string>()));
 bool found_binary=false;
 for(const auto& operation:accounting["operations"]) if(operation["operation_id"]==binary_service["prepared_id"]) {
  found_binary=true; assert(operation["actual"]["requests"]["value"]==1); assert(operation["actual"]["response_bytes"]["value"]==binary_response.size());
  assert(operation["actual"]["output_tokens"]["value"].is_null()&&operation["actual"]["cost_usd"]["value"].is_null());
 }
 assert(found_binary&&http->requests().size()==5);
 std::cout<<"native exact-byte dispatch, actual graph edges, receipt binding and duplicate protection passed\n";
}
