#!/usr/bin/env python3
"""Recover task-local packages; never invoke global dpkg installation."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path('/workspace/scratch/2fbae43b23fa')
prefix = root / 'toolchain-2026-10-05'
cache = root / 'apt-debs-2026-10-05'
proof = root / 'evidence-2026-10-05/local-toolchain'
proof.mkdir(parents=True, exist_ok=True)
prefix.mkdir(parents=True, exist_ok=True)

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

packages = sorted(cache.glob('*.deb'))
if not packages:
    raise SystemExit('No complete debs; finish the scratch download first.')
receipt = {'schema': 'loom.local_toolchain_extraction/1', 'prefix': str(prefix),
           'global_dpkg_install': False, 'packages': [], 'probes': []}
if '--probe-only' in sys.argv:
    old = proof / 'manifest.json'
    (proof / 'initial-extraction-probe.json').write_bytes(old.read_bytes())
    receipt = json.loads(old.read_text())
    receipt['previous_probes'] = receipt.pop('probes')
    receipt['probes'] = []
    recovery = proof / 'llvm-truncation-recovery.json'
    if recovery.exists():
        receipt['exact_package_file_recovery'] = json.loads(recovery.read_text())
    packages = []
with (proof / 'extraction.log').open('a') as log:
    for package in packages:
        metadata = subprocess.check_output(['dpkg-deb', '-f', str(package),
                                            'Package', 'Version', 'Architecture'], text=True)
        receipt['packages'].append({'file': str(package), 'bytes': package.stat().st_size,
                                    'sha256': sha(package), 'metadata': metadata.strip()})
        command = ['dpkg-deb', '-x', str(package), str(prefix)]
        log.write(json.dumps(command) + '\n'); log.flush()
        subprocess.run(command, check=True, stdout=log, stderr=log)

runtime = prefix / 'runtime-lib'
runtime.mkdir(exist_ok=True)
excluded = ('ld-linux', 'libc.', 'libc-', 'libpthread', 'libdl.', 'libdl-',
            'librt.', 'librt-', 'libm.', 'libm-', 'libmvec', 'libresolv',
            'libnss_', 'libutil', 'libanl', 'libBrokenLocale', 'libthread_db')
receipt['exposed_libraries'] = []
for directory in [prefix / 'usr/lib/x86_64-linux-gnu', prefix / 'lib/x86_64-linux-gnu',
                  prefix / 'usr/lib/llvm-18/lib']:
    if not directory.is_dir():
        continue
    for library in sorted(directory.glob('*.so*')):
        if library.name.startswith(excluded) or not library.exists():
            continue
        link = runtime / library.name
        if not link.exists() and not link.is_symlink():
            link.symlink_to(library.resolve())
        receipt['exposed_libraries'].append({'name': library.name, 'target': str(library.resolve())})

clang = prefix / 'usr/lib/llvm-18/bin/clang'
clangxx = prefix / 'usr/lib/llvm-18/bin/clang++'
resource = prefix / 'usr/lib/llvm-18/lib/clang/18'
header = prefix / 'usr/include/sqlite3.h'
sqlite = runtime / 'libsqlite3.so'
for item in [clang, clangxx, resource, header, sqlite]:
    if not item.exists():
        raise SystemExit('Missing extracted input: ' + str(item))
environment = os.environ.copy()
environment['LD_LIBRARY_PATH'] = str(runtime)
flags = ['--gcc-toolchain=/usr', '-resource-dir=' + str(resource)]
receipt['environment'] = {'LD_LIBRARY_PATH': str(runtime)}
receipt['compiler'] = {'c': str(clang), 'cxx': str(clangxx), 'flags': flags}
receipt['sqlite'] = {'include': str(header.parent), 'header_sha256': sha(header),
                     'library': str(sqlite), 'library_sha256': sha(sqlite)}

def run(name, command, required=True):
    result = subprocess.run(command, cwd=prefix, env=environment,
                            capture_output=True, text=True)
    (proof / (name + '.stdout.txt')).write_text(result.stdout)
    (proof / (name + '.stderr.txt')).write_text(result.stderr)
    receipt['probes'].append({'name': name, 'command': command, 'exit_code': result.returncode,
                              'stdout_bytes': len(result.stdout.encode()),
                              'stderr_bytes': len(result.stderr.encode())})
    if required and result.returncode:
        (proof / 'manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')
        raise SystemExit(name + ': ' + result.stderr[-1200:])
    return result

version = run('clang-version', [str(clangxx), '--version']).stdout.splitlines()[0]
run('clang-resource-dir', [str(clangxx), '-print-resource-dir'])
source = prefix / 'standalone-probe.cpp'
source.write_text('#include <iostream>\n#include <vector>\n#include <sqlite3.h>\n'
                  'int main(){std::vector<int> v{18,1,3};sqlite3* db=nullptr;'
                  'if(sqlite3_open(":memory:",&db)!=SQLITE_OK)return 1;sqlite3_close(db);'
                  'std::cout<<v.at(0)<<" sqlite="<<sqlite3_libversion()<<"\\n";}\n')
binary = prefix / 'standalone-probe'
asan = prefix / 'standalone-asan-probe'
args = ['-std=c++20', '-Wall', '-Wextra', '-Werror'] + flags
libs = ['-I' + str(header.parent), str(sqlite), '-Wl,-rpath,' + str(runtime)]
run('standalone-compile-link', [str(clangxx)] + args + [str(source)] + libs + ['-o', str(binary)])
plain = run('standalone-run', [str(binary)])
run('standalone-asan-compile-link', [str(clangxx)] + args + ['-fsanitize=address,undefined',
    '-fno-omit-frame-pointer', str(source)] + libs + ['-o', str(asan)])
sanitized = run('standalone-asan-run', [str(asan)], required=False)
receipt['standalone_cpp_sqlite_passed'] = plain.returncode == 0
receipt['standalone_asan_compile_link_passed'] = True
receipt['standalone_asan_runtime_passed'] = sanitized.returncode == 0
receipt['sanitizer_options_weakened'] = False
receipt['artifacts'] = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                        for p in [source, binary, asan, clang.resolve()]}
(proof / 'manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'packages': len(receipt['packages']), 'clang': version, 'prefix': str(prefix),
                  'standalone': plain.returncode, 'asan_runtime': sanitized.returncode,
                  'output': plain.stdout.strip(), 'manifest': str(proof / 'manifest.json')}))
