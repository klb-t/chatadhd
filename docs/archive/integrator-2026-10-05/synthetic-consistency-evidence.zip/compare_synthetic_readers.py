#!/usr/bin/env python3
"""Tiny actual vendor SQLite reader versus Python on separate identical copies."""
from pathlib import Path
import hashlib,json,os,shutil,sqlite3,subprocess,time
ROOT=Path('/workspace/scratch/2fbae43b23fa');R=ROOT/'chatadhd';E=ROOT/'evidence-2026-10-05';D=E/'1-synthetic-before-investigation';O=D/'vendor-python-comparison';O.mkdir(exist_ok=False)
code=r'''#include "sqlite3.h"
#include <stdio.h>
static int row(void* u,int n,char** v,char** names) {
  (void)u;(void)names;
  for(int i=0;i<n;++i) printf("%s%s",i?" | ":"ROW ",v[i]?v[i]:"NULL");
  puts("");return 0;
}
int main(int argc,char** argv) {
  printf("LIBVERSION %s\nHEADER_VERSION %s\nSOURCEID %s\n",sqlite3_libversion(),SQLITE_VERSION,sqlite3_sourceid());
  for(int i=1;i<argc;++i) {
    sqlite3* db=0;printf("DATABASE %s\n",argv[i]);
    int rc=sqlite3_open_v2(argv[i],&db,SQLITE_OPEN_READONLY|SQLITE_OPEN_URI,0);
    printf("OPEN_RC %d\n",rc);
    if(rc==SQLITE_OK) {
      const char* sqls[]={"PRAGMA query_only=ON","PRAGMA quick_check","PRAGMA integrity_check","SELECT COUNT(*) FROM loom_kb_operators"};
      for(unsigned j=0;j<sizeof(sqls)/sizeof(sqls[0]);++j) {
        char* error=0;printf("SQL %s\n",sqls[j]);rc=sqlite3_exec(db,sqls[j],row,0,&error);
        printf("RC %d ERROR %s\n",rc,error?error:"");sqlite3_free(error);
      }
    } else printf("ERROR %s\n",sqlite3_errmsg(db));
    if(db) printf("CLOSE_RC %d\n",sqlite3_close(db));
  }
  return 0;
}
'''
(O/'vendor-reader.c').write_text(code)
def identity(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def measured(cmd,log):
 start=time.monotonic()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT)
  _,status,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 return {'command':cmd,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'cpu_seconds':u.ru_utime+u.ru_stime,'peak_rss_kib':u.ru_maxrss,'log':log.name,'log_identity':identity(log)}
lib=R/'loom/build/dev/libloom_sqlite3_amalgamation.a';libbefore=identity(lib)
compilecmd=['cc','-std=c11','-O0','-g0','-I'+str(R/'loom/third_party/sqlite'),str(O/'vendor-reader.c'),str(lib),'-ldl','-lm','-pthread','-o',str(O/'vendor-reader')]
compile_result=measured(compilecmd,O/'compile.txt');assert compile_result['exit_code']==0
inputs=[];vendor_paths=[];python_paths=[]
for label,source in (('original',D/'original-failure-copy'),('fresh',E/'1-synthetic-before-replay-work')):
 for db in sorted(source.glob('*/[ab]*/chatadhd.db')):
  rel=Path(label)/db.relative_to(source);dbinputs={};pair=[]
  for reader in ('vendor','python'):
   target=O/(reader+'-input')/rel;target.parent.mkdir(parents=True,exist_ok=True)
   for suffix in ('','-wal','-shm'):
    p=Path(str(db)+suffix)
    if p.exists():
     q=Path(str(target)+suffix);shutil.copyfile(p,q);assert identity(q)==identity(p)
     dbinputs[suffix]=identity(p)
   pair.append(target)
  vendor_paths.append(pair[0]);python_paths.append(pair[1]);inputs.append({'case':str(rel),'files_before':dbinputs})
commands=[compile_result]
commands.append(measured([str(O/'vendor-reader'),*map(str,vendor_paths)],O/'vendor-paired.txt'))
pyresults=[]
for p in python_paths:
 d={'case':str(p.relative_to(O/'python-input')),'checks':{}}
 con=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True)
 for name,sql in (('quick_check','PRAGMA quick_check'),('integrity_check','PRAGMA integrity_check'),('operators_count','SELECT COUNT(*) FROM loom_kb_operators')):
  try:d['checks'][name]={'ok':True,'rows':con.execute(sql).fetchall()}
  except sqlite3.Error as error:d['checks'][name]={'ok':False,'error':str(error),'code':getattr(error,'sqlite_errorcode',None)}
 con.close();pyresults.append(d)
(O/'python-paired.json').write_text(json.dumps({'sqlite_version':sqlite3.sqlite_version,'results':pyresults},indent=2)+'\n')
materialized=[p for p in sorted((D/'wal-analysis').glob('*/*/[ab]*/chatadhd.db'))]
commands.append(measured([str(O/'vendor-reader'),*[p.resolve().as_uri()+'?mode=ro&immutable=1' for p in materialized]],O/'vendor-materialized.txt'))
for item,v,p in zip(inputs,vendor_paths,python_paths):
 item['files_after']={reader:{suffix:identity(Path(str(path)+suffix)) for suffix in item['files_before'] if Path(str(path)+suffix).exists()} for reader,path in (('vendor',v),('python',p))}
 item['db_wal_stable']=all(item['files_before'][suffix]==after.get(suffix) for after in item['files_after'].values() for suffix in item['files_before'] if suffix!='-shm')
receipt={'commands':commands,'vendor_library_before':libbefore,'vendor_library_after':identity(lib),'library_stable':libbefore==identity(lib),'reader_source':identity(O/'vendor-reader.c'),'reader_binary':identity(O/'vendor-reader'),'header':identity(R/'loom/third_party/sqlite/sqlite3.h'),'amalgamation_source':identity(R/'loom/third_party/sqlite/sqlite3.c'),'inputs':inputs,'python_version':sqlite3.sqlite_version,'production_translation_units_compiled':0,'live_calls':0}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('COMPILE',json.dumps(compile_result))
print('VENDOR_PAIRED\n'+(O/'vendor-paired.txt').read_text())
print('PYTHON_PAIRED\n'+(O/'python-paired.json').read_text())
print('VENDOR_MATERIALIZED\n'+(O/'vendor-materialized.txt').read_text())
print('INPUT_DB_WAL_STABLE',all(i['db_wal_stable'] for i in inputs))
