#!/usr/bin/env python3
"""Independent offline replay of the unchanged synthetic tool/CLI and immutable evidence."""
import hashlib,json,os,shutil,sqlite3,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/scratch/2fbae43b23fa');REPO=ROOT/'chatadhd';E=ROOT/'evidence-2026-10-05';B=REPO/'loom/build/dev'
OUT=E/'1-synthetic-before-investigation';OUT.mkdir(exist_ok=False)
WORK=E/'1-synthetic-before-replay-work';assert not WORK.exists()
COMMAND=['python3','loom/tools/eval/knowledge_eval.py','synthetic','--loom','loom/build/dev/cli/loom','--work',str(WORK),'--out',str(E/'1-synthetic-before-replay.json')]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def ident(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def snapshot():
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip();files={}
 entries=subprocess.check_output(['git','ls-tree','-r','-z',commit,'loom/src','loom/include','loom/cli','loom/tools/eval','loom/tests/fixtures/eval/synthetic_dev'],cwd=REPO)
 for entry in entries.split(b'\0'):
  if not entry:continue
  info,name=entry.split(b'\t',1);name=name.decode();p=REPO/name;raw=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  assert blob==info.split()[2].decode(),name
  files[name]={'git_blob':blob,**ident(p)}
 return {'commit':commit,'sources':files,'binaries':{name:ident(B/name) for name in ('libloom_core.a','libloom_sqlite3_amalgamation.a','libloom_miniz.a','cli/loom')}}
before=snapshot();(OUT/'source-binary-before.json').write_text(json.dumps(before,indent=2)+'\n')
actualgate=json.loads((E/'5-final-gate/before.json').read_text());oldreplay=json.loads((E/'5-replays/preflight-after.json').read_text())
assert before['binaries']['libloom_core.a']['sha256']==oldreplay['libraries']['libloom_core.a']['sha256']
for name,d in before['binaries'].items():assert d==actualgate['binaries'][name],name
# Preserve copies before further SQLite reads; originals are never repaired or reused.
old=E/'1-synthetic-before-work';failed={}
for p in sorted(old.rglob('*')):
 if p.is_file() and (p.name.startswith('chatadhd.db') or p.name.startswith('chatadhd.fts.db') or p.name=='knowledge_config.json'):
  name=str(p.relative_to(old));q=OUT/'original-failure-copy'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);failed[name]=ident(p)
shutil.copyfile(E/'1-synthetic-before.txt',OUT/'original-failure.txt')
(OUT/'original-failure-files.json').write_text(json.dumps(failed,indent=2)+'\n')
log=E/'1-synthetic-before-replay.txt';start=time.monotonic()
with log.open('wb') as f:
 process=subprocess.Popen(COMMAND,cwd=REPO,stdout=f,stderr=subprocess.STDOUT)
 _,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
run={'argv':COMMAND,'cwd':str(REPO),'exit_code':process.returncode,'wall_seconds':time.monotonic()-start,'cpu_seconds':usage.ru_utime+usage.ru_stime,'peak_child_rss_kib':usage.ru_maxrss,'log':str(log),'log_identity':ident(log),'live_provider_calls':0,'threshold_changes':0,'source_edits':0}
(OUT/'run.json').write_text(json.dumps(run,indent=2)+'\n')
after=snapshot();(OUT/'source-binary-after.json').write_text(json.dumps(after,indent=2)+'\n')
checks=[]
for label,work in (('original',OUT/'original-failure-copy'),('fresh',WORK)):
 for db in sorted(work.rglob('*.db')):
  d={'label':label,'path':str(db.relative_to(work)),**ident(db),'checks':{}}
  # Original opens operate only on the saved copies, never the failed source directory.
  try:
   con=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON')
   for name,sql in (('quick_check','PRAGMA quick_check'),('integrity_check','PRAGMA integrity_check'),('operators_count','SELECT COUNT(*) FROM loom_kb_operators'),('operators_ordered_body','SELECT body FROM loom_kb_operators ORDER BY id')):
    try:
     rows=con.execute(sql).fetchall();d['checks'][name]={'ok':True,'rows':len(rows),'values':rows if name.endswith('_check') else None}
    except sqlite3.Error as error:d['checks'][name]={'ok':False,'error':str(error),'error_code':getattr(error,'sqlite_errorcode',None)}
   con.close()
  except sqlite3.Error as error:d['open_error']=str(error)
  checks.append(d)
# DB/WAL content is pinned after the read-only inspection; SHM read marks are not an input artifact.
original_content_stable=all(ident(old/name)==d for name,d in failed.items() if not name.endswith('-shm'))
report={'schema':'loom.integrator_synthetic_corruption_replay/1','run':run,'source_binary_stable':before==after,'source_files':len(before['sources']),'original_db_wal_config_stable':original_content_stable,'kernel_equals_successful_w5_replay':True,'binaries_equal_current_full_ctest_before':True,'python_sqlite_version':sqlite3.sqlite_version,'database_checks':checks,'original_failure_preserved':True,'original_failure_copy_files':len(failed),'scorecard':ident(E/'1-synthetic-before-replay.json') if (E/'1-synthetic-before-replay.json').is_file() else None}
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'run':run,'stable':before==after,'original_preserved':original_content_stable,'db_checks':[{k:v for k,v in d.items() if k in ('label','path','checks')} for d in checks]},indent=2))
raise SystemExit(0 if before==after and original_content_stable else 2)
