#include "sqlite3.h"
#include <stdio.h>
static int row(void* u,int n,char** v,char** names) {
  (void)u;(void)names;
  for(int i=0;i<n;++i) printf("%s%s",i?" | ":"ROW ",v[i]?v[i]:"NULL");
  puts("");return 0;
}
int main(int argc,char** argv) {
  printf("LIBVERSION %s\nHEADER_VERSION %s\nSOURCEID %s\n",sqlite3_libversion(),SQLITE_VERSION,sqlite3_sourceid());
  for(int i=1;i<argc;++i) {
    sqlite3* db=0;printf("DATABASE %s\n",argv[i]);
    int rc=sqlite3_open_v2(argv[i],&db,SQLITE_OPEN_READONLY|SQLITE_OPEN_URI,0);
    printf("OPEN_RC %d\n",rc);
    if(rc==SQLITE_OK) {
      const char* sqls[]={"PRAGMA query_only=ON","PRAGMA quick_check","PRAGMA integrity_check","SELECT COUNT(*) FROM loom_kb_operators"};
      for(unsigned j=0;j<sizeof(sqls)/sizeof(sqls[0]);++j) {
        char* error=0;printf("SQL %s\n",sqls[j]);rc=sqlite3_exec(db,sqls[j],row,0,&error);
        printf("RC %d ERROR %s\n",rc,error?error:"");sqlite3_free(error);
      }
    } else printf("ERROR %s\n",sqlite3_errmsg(db));
    if(db) printf("CLOSE_RC %d\n",sqlite3_close(db));
  }
  return 0;
}
