#!/usr/bin/env python3
"""Same synthetic tool/CLI, isolated /tmp work and separate identical reader copies."""
from pathlib import Path
import hashlib,json,os,shutil,sqlite3,subprocess,tempfile,time
ROOT=Path('/workspace/scratch/2fbae43b23fa');REPO=ROOT/'chatadhd';E=ROOT/'evidence-2026-10-05';BASE=E/'1-synthetic-before-investigation';OUT=BASE/'tmp-comparison';OUT.mkdir(exist_ok=False)
TMP=Path(tempfile.mkdtemp(prefix='integrator-5-synthetic-before-'))
B=REPO/'loom/build/dev';READER=BASE/'vendor-python-comparison/vendor-reader'
def identity(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def snapshot():
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip();old=json.loads((BASE/'source-binary-before.json').read_text());sources={}
 for name,d in old['sources'].items():
  path=REPO/name;sources[name]=identity(path)
  assert sources[name]=={k:v for k,v in d.items() if k!='git_blob'},name
 return {'commit':commit,'sources':sources,'binaries':{name:identity(B/name) for name in old['binaries']},'reader':identity(READER)}
def measured(cmd,log,cwd=REPO):
 start=time.monotonic()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
  _,status,u=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 return {'argv':cmd,'cwd':str(cwd),'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'cpu_seconds':u.ru_utime+u.ru_stime,'peak_rss_kib':u.ru_maxrss,'log':str(log),'log_identity':identity(log)}
before=snapshot();(OUT/'source-binary-before.json').write_text(json.dumps(before,indent=2)+'\n')
old=json.loads((BASE/'source-binary-before.json').read_text());assert before['binaries']==old['binaries']
cmd=['python3','loom/tools/eval/knowledge_eval.py','synthetic','--loom','loom/build/dev/cli/loom','--work',str(TMP/'work'),'--out',str(E/'1-synthetic-before-tmp.json')]
run=measured(cmd,E/'1-synthetic-before-tmp.txt')
checks=[];paths=[];inputs=[]
for db in sorted((TMP/'work').rglob('*.db')):
 rel=db.relative_to(TMP/'work');pair=[];artifacts={}
 for who in ('vendor','python'):
  target=TMP/(who+'-input')/rel;target.parent.mkdir(parents=True,exist_ok=True)
  for suffix in ('','-wal','-shm'):
   p=Path(str(db)+suffix)
   if p.exists():
    q=Path(str(target)+suffix);shutil.copyfile(p,q);artifacts[suffix]=identity(p);assert identity(q)==artifacts[suffix]
  pair.append(target)
 inputs.append({'case':str(rel),'files_before':artifacts})
 paths.append(pair[0]);d={'case':str(rel),'python':{}}
 con=sqlite3.connect(pair[1].resolve().as_uri()+'?mode=ro',uri=True)
 for name,sql in (('quick_check','PRAGMA quick_check'),('integrity_check','PRAGMA integrity_check')):
  try:
   rows=con.execute(sql).fetchall();d['python'][name]={'rows':rows,'passed':rows==[('ok',)]}
  except sqlite3.Error as ex:d['python'][name]={'error':str(ex),'passed':False}
 con.close();checks.append(d)
probe=measured([str(READER),*map(str,paths)],OUT/'vendor-readers.txt')
raw=(OUT/'vendor-readers.txt').read_text()
for d,p in zip(checks,paths):
 block=raw.split('DATABASE '+str(p)+'\n',1)[1].split('DATABASE ',1)[0];d['vendor']={}
 for name in ('quick_check','integrity_check'):
  text=block.split('SQL PRAGMA '+name+'\n',1)[1].split('SQL ',1)[0]
  d['vendor'][name]={'passed':text.startswith('ROW ok\nRC 0 ERROR \n'),'output':text}
for data,p in zip(inputs,paths):
 data['files_after']={suffix:identity(Path(str(p)+suffix)) for suffix in data['files_before'] if Path(str(p)+suffix).exists()}
 data['database_wal_stable']=all(data['files_before'][s]==data['files_after'].get(s) for s in data['files_before'] if s!='-shm')
after=snapshot();(OUT/'source-binary-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'schema':'loom.integrator_synthetic_tmp_differential/1','tmp_root':str(TMP),'original_command_change':'work physical directory and scorecard/log filenames only; unchanged tool/CLI/config/import-mode/no floors','run':run,'vendor_run':probe,'checks':checks,'inputs':inputs,'source_binary_stable':before==after,'source_files':len(before['sources']),'baseline_binaries_same':True,'all_six_databases_both_readers_passed':len(checks)==6 and all(x['passed'] for d in checks for r in ('python','vendor') for x in d[r].values()),'python_sqlite_version':sqlite3.sqlite_version,'vendor_sqlite_version':raw.splitlines()[0],'production_translation_units_compiled':0,'source_edits':0,'threshold_changes':0,'paid_or_live_calls':0,'scorecard':identity(E/'1-synthetic-before-tmp.json') if (E/'1-synthetic-before-tmp.json').exists() else None,'filesystem_inference':'If only workspace-backed DB/WAL snapshots fail while /tmp passes on identical binary/source inputs, this supports a workspace consistency hypothesis; this single differential does not identify the exact write/restore mechanism.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
