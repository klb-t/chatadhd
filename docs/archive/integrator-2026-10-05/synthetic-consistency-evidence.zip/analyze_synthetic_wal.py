#!/usr/bin/env python3
"""Forensic read only: WAL checksums and independent materialized snapshot copies."""
import hashlib,json,shutil,sqlite3,struct
from pathlib import Path
E=Path('/workspace/scratch/2fbae43b23fa/evidence-2026-10-05');OUT=E/'1-synthetic-before-investigation';D=OUT/'wal-analysis';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def checksum(raw,initial=(0,0),order='<'):
 s1,s2=initial;words=struct.unpack(order+str(len(raw)//4)+'I',raw)
 for a,b in zip(words[::2],words[1::2]):
  s1=(s1+a+s2)&0xffffffff;s2=(s2+b+s1)&0xffffffff
 return s1,s2
def check_db(path,full):
 con=sqlite3.connect(path.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
 out={}
 for label,sql in (('quick_check','PRAGMA quick_check'),('integrity_check','PRAGMA integrity_check')):
  try:out[label]=con.execute(sql).fetchmany(40)
  except sqlite3.Error as e:out[label]={'error':str(e)}
 if full:
  tablechecks={}
  try:names=[r[0] for r in con.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
  except sqlite3.Error as e:names=[];out['schema_error']=str(e)
  for name in names:
   qname=name.replace('"','""')
   try:
    rows=con.execute('PRAGMA integrity_check("'+qname+'")').fetchall()
    if rows!=[('ok',)]:tablechecks[name]=rows
   except sqlite3.Error as e:tablechecks[name]={'error':str(e)}
  out['table_failures']=tablechecks;out['tables_checked']=len(names)
 con.close();return out
results=[]
for label,root in (('original',OUT/'original-failure-copy'),('fresh',E/'1-synthetic-before-replay-work')):
 for db in sorted(root.glob('*/[ab]*/chatadhd.db')):
  rel=str(db.relative_to(root));target=D/label/rel;target.parent.mkdir(parents=True,exist_ok=True)
  raw=db.read_bytes();walpath=Path(str(db)+'-wal');wal=walpath.read_bytes() if walpath.exists() else b''
  record={'label':label,'path':rel,'database_sha256':hashlib.sha256(raw).hexdigest(),'database_bytes':len(raw),'wal_sha256':hashlib.sha256(wal).hexdigest(),'wal_bytes':len(wal)}
  # Raw DB snapshot ignores WAL only in this separately named copy.
  main=target.parent/'main-only.db';main.write_bytes(raw);record['main_only']=check_db(main,False)
  material=bytearray(raw);updates={};lastcommit=0;valid=0;invalid=None
  if wal:
   magic,version,page_size,sequence,s1,s2,c1,c2=struct.unpack('>8I',wal[:32]);order='>' if magic&1 else '<'
   previous=checksum(wal[:24],order=order)
   record['wal_header']={'magic':hex(magic),'version':version,'page_size':page_size,'sequence':sequence,'salt':[s1,s2],'header_checksum_valid':previous==(c1,c2)}
   assert previous==(c1,c2),(label,rel,'headerchecksum')
   frames=(len(wal)-32)//(24+page_size)
   record['physical_frames']=frames;record['trailing_bytes']=(len(wal)-32)%(24+page_size)
   for idx in range(frames):
    offset=32+idx*(24+page_size);h=wal[offset:offset+24];data=wal[offset+24:offset+24+page_size]
    pgno,commit,t1,t2,f1,f2=struct.unpack('>6I',h)
    if (t1,t2)!=(s1,s2) or pgno==0:
     invalid={'frame':idx+1,'reason':'stale salt or zero page','pgno':pgno,'salt':[t1,t2]};break
    previous=checksum(h[:8],previous,order);previous=checksum(data,previous,order)
    if previous!=(f1,f2):
     invalid={'frame':idx+1,'reason':'checksum','pgno':pgno,'expected':[f1,f2],'actual':list(previous)};break
    valid+=1;updates[pgno]=data
    if commit:
     size=commit*page_size
     if len(material)<size:material.extend(b'\0'*(size-len(material)))
     for page,body in updates.items():
      if page<=commit:material[(page-1)*page_size:page*page_size]=body
     del material[size:];updates={};lastcommit=idx+1
   record['valid_frames']=valid;record['last_commit_frame']=lastcommit;record['first_invalid']=invalid
  target.write_bytes(material);record['materialized_bytes']=len(material);record['materialized_sha256']=sha(target);record['materialized']=check_db(target,True)
  results.append(record)
(D/'receipt.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:
 print(json.dumps({k:v for k,v in r.items() if k not in ('main_only','materialized')},indent=2))
 print('MAIN_ONLY',r['main_only'])
 print('MATERIALIZED',r['materialized'])
