# Synthetic DB/WAL consistency differential, integrator 9

Public synthetic corpus only. Source revision `0a81480bd1a70b394bac72e98f6b5e7cb49f5d0b` has unchanged `loom/src` and `loom/include` bytes from actual mixed W5 replay `66da570d3b5379492e128d940ad474467082c59f`. Exact CLI/kernel/eval/fixture bindings and all 305 selected source file hashes before/after are in `records/source-binary-before.json` and `records/source-binary-after.json`. Actual core SHA256 `80df4818b27c966ac31cb53499771eb8d810f84b0d8f0b34c38334b86c26324d`; CLI SHA256 `20a7a8c8768af11f958f019c37f83ef75c2bb50a81aea78e3ed58528665e8083`. They match the full CTest integrator's own before snapshot. No production translation unit, source change, test/threshold change, live call or paid operation.

Three observations are preserved without overwriting failures:

1. Original workspace run exited1 during an ordered knowledge-body read. Both `a` and `a2` main DB views fail quick_check/integrity_check; `b` and all FTS DBs pass.
2. A fresh, unique workspace directory using the exact same tool/CLI/config returned exit0 but `a` still fails both integrity checks. Wall43.27s, peak29248KiB. Thus successful scorecard exit alone did not validate storage.
3. The exact command with only work directory moved to `/tmp` returned exit0. All6 main/FTS DBs pass quick_check and integrity_check with Python SQLite3.53.1 and the actual archive SQLite3.47.2, 24/24 checks. Wall35.36s, peak29412KiB. Rendered scorecard stdout is byte-identical. Raw JSON differs only in `work_dir` and34 generated conversation IDs under `stages.catalog.import.conversations`; all metrics, other stage statistics and determinism fields are identical. Each configuration differs only in `out_dir`. All source/kernel/CLI bytes remain identical.

The actual vendored reader confirms the negative cases and agrees with Python. This excludes a reader-version explanation for these snapshots. Main DB bytes alone are structurally valid; retaining the WAL yields stale smaller committed views and invalid page references. Raw WAL header and frame-prefix checksums are valid; following old-salt tail frames are ordinary residue and not treated as valid. Independently materialized snapshots of the valid commit prefix reproduce the same corruption in both readers. No WAL is deleted or ignored to make a negative case pass. `wal-analysis` receipts retain the exact algorithm/source binding; materialized copies can be regenerated from the dataset.

Inference: the physical work-directory differential and advanced main DB/stale WAL mismatch support a workspace file-consistency hypothesis. The exact write, restore or synchronization mechanism has not been demonstrated. This evidence does not identify a production source bug, nor prove all filesystem behavior. Full CTest and performance scheduling are separate integrator gates and not asserted here.

`datasets` contains every main/FTS DB, retained WAL/SHM and configuration from the original failure, fresh workspace replay and fresh `/tmp` control. `records` contains complete commands/logs/resources/source/library/input hashes, Python results and actual-vendor outputs. Original scripts are retained as historical launch records with original paths. The tiny vendor-reader source can be compiled against any completed exact build with:

```sh
TASK_REPO=/absolute/path/to/public/checkout
TASK_BUILD=/absolute/path/to/completed/native/build
TASK_BUNDLE=/absolute/path/to/extracted/bundle
TASK_READER=/tmp/integrator-sqlite-reader
cc -std=c11 -O0 -g0 -I"$TASK_REPO/loom/third_party/sqlite" "$TASK_BUNDLE/records/vendor-python-comparison/vendor-reader.c" "$TASK_BUILD/libloom_sqlite3_amalgamation.a" -ldl -lm -pthread -o "$TASK_READER"
"$TASK_READER" /absolute/path/to/copied/chatadhd.db
```

Use separate identical copies for the readers, preserving adjacent WAL/SHM files. The reader opens read-only, prints runtime/header SQLite versions and source ID, and reports every pragma result plus SQLite return code; its process exit0 means the reader completed, not that every database passed. Inspect `RC` and `ROW` values. The original pipeline command is preserved in `records/run.json`; a future independent `/tmp` differential uses the unchanged public tool/CLI/defaults and fresh output/work paths. `SHA256.json` hashes every bundled file except itself. Native binaries/static archives are omitted, with hashes retained. This bundle contains negative evidence and must remain archived separately from accepted source.
