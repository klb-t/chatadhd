#!/usr/bin/env python3
import argparse, hashlib, json, os, subprocess, time
from pathlib import Path

ROOT = Path('/workspace/scratch/2fbae43b23fa/chatadhd')
EVIDENCE = ROOT.parent / 'evidence-2026-10-05'
BUILD = ROOT / 'loom/build/dev'
CTEST = '/root/.local/bin/ctest'
NINJA = '/root/.local/bin/ninja'

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def snapshot():
    query = subprocess.check_output([NINJA, '-C', str(BUILD), '-t', 'query', 'libloom_core.a'], text=True)
    inputs = [line.strip() for line in query.splitlines() if line.strip().endswith('.o')]
    assert inputs and len(inputs) == len(set(inputs))
    objects = {}
    for name in inputs:
        path = BUILD / name
        with path.open('rb') as f:
            assert f.read(4) == b'\x7fELF', name
        objects[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    all_objects = {}
    for path in sorted((BUILD / 'CMakeFiles').rglob('*.o')):
        with path.open('rb') as f:
            assert f.read(4) == b'\x7fELF', str(path)
        all_objects[str(path.relative_to(BUILD))] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    binaries = {}
    for name in ['libloom_core.a', 'libloom_miniz.a', 'libloom_sqlite3_amalgamation.a',
                 'libloom.so.0.1.0', 'loom_tests', 'loom_compat_tool',
                 'loom_candidate_graph_native_tool', 'cli/loom', 'server/loom-server']:
        path = BUILD / name
        assert path.stat().st_size > 0, name
        with path.open('rb') as f:
            header = f.read(8)
        assert header == b'!<arch>\n' if name.endswith('.a') else header[:4] == b'\x7fELF', name
        binaries[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    sources = {}
    names = git('ls-files', 'loom/src', 'loom/include', 'loom/cli', 'loom/server', 'loom/data', 'loom/tests', 'loom/CMakeLists.txt', 'loom/CMakePresets.json').splitlines()
    for name in names:
        path = ROOT / name
        if not path.is_file():
            continue
        sources[name] = sha(path)
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'kernel_object_count': len(objects), 'objects': objects, 'all_objects': all_objects, 'binaries': binaries, 'sources': sources}

def run(command, log, cwd=ROOT):
    started = time.monotonic()
    with log.open('w') as f:
        result = subprocess.run(command, cwd=cwd, stdout=f, stderr=subprocess.STDOUT)
    return {'argv': command, 'cwd': str(cwd), 'exit_code': result.returncode,
            'seconds': time.monotonic() - started, 'log_sha256': sha(log)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('lane')
    parser.add_argument('--jobs', type=int, default=4)
    parser.add_argument('--ctest-only', action='store_true')
    args = parser.parse_args()
    out = EVIDENCE / (args.lane + '-gate')
    out.mkdir(exist_ok=False)
    receipt = {'schema': 'loom.integrator_gate/1', 'lane': args.lane, 'commands': []}
    receipt['before'] = snapshot()
    (out / 'before.json').write_text(json.dumps(receipt['before'], indent=2) + '\n')
    # Generated ELF executables may lose mode bits at execution-host boundaries.
    # Preserve and record bytes; this is not a source or test modification.
    receipt['artifact_modes'] = {}
    for name in ['loom_tests', 'loom_compat_tool', 'loom_candidate_graph_native_tool', 'cli/loom', 'server/loom-server']:
        path = BUILD / name
        mode = path.stat().st_mode & 0o777
        if not mode & 0o111:
            path.chmod(mode | 0o111)
        receipt['artifact_modes'][name] = {'before': oct(mode), 'after': oct(path.stat().st_mode & 0o777), 'sha256': sha(path)}
    manifest = subprocess.check_output([CTEST, '--test-dir', str(BUILD), '--show-only=json-v1'], text=True)
    (out / 'manifest.json').write_text(manifest)
    command = [CTEST, '--test-dir', str(BUILD), '--parallel', str(args.jobs), '--output-on-failure', '--test-output-size-passed', '0', '--test-output-size-failed', '0', '--output-junit', str(out / 'ctest.xml')]
    receipt['commands'].append(run(command, out / 'ctest.txt'))
    guard = ['python3', str(EVIDENCE / 'verify_ctest.py'), '--manifest', str(out / 'manifest.json'), '--junit', str(out / 'ctest.xml'), '--preset', 'dev', '--output', str(out / 'cases.json')]
    receipt['commands'].append(run(guard, out / 'guard.txt'))
    if not args.ctest_only:
        receipt['commands'].append(run(['npm', 'run', 'build'], out / 'web.txt', ROOT / 'loom/web'))
    receipt['after'] = snapshot()
    receipt['stable'] = receipt['before'] == receipt['after']
    receipt['passed'] = receipt['stable'] and all(item['exit_code'] == 0 for item in receipt['commands'])
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'lane': args.lane, 'passed': receipt['passed'], 'commit': receipt['before']['commit'], 'objects': receipt['before']['kernel_object_count'], 'commands': receipt['commands']}), flush=True)
    raise SystemExit(0 if receipt['passed'] else 1)

if __name__ == '__main__':
    main()
