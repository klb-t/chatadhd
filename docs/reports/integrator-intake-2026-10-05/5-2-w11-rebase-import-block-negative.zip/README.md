# W5-2 actual rebase attempt onto selected W11

Original selected W5 source: `dc29970a46e9658c2994736cc706b9aaac88d5ad`, parent `6ae0e28b8405b43aa9d8995ad8273a0bcb0b34c4`. Source bytes originate in public W5 `156a82080a7abb8a68d249747dfa167b3045effe`, report tip `f494931dbf24c7debac588361d1d0098275bd47a`.

Target selected W11: `e033f25853fa8429c895d1d08eb8a163e2cf5ede`. The actual local fetch and rebase are recorded verbatim in commands.json and logs. No compile, tests, live call, push or root-checkout edit occurred.

Rebase exit 1. One unresolved import-block conflict in `loom/cli/tests/test_cli_smoke.py`: W11 adds `import struct`; W5 adds `import sqlite3`. Both are used by their own test additions (attempt lines 493 and 353). Neither import should be lost. No conflict has been resolved, no `rebase --continue` performed. All remaining 23 files including production CLI auto-merge mechanically.

Static production check: new W5 valued `--import-preset` and `--audit-preset` names remain consumed as generic valued options by Args::parse; W11 flags pack enumerates boolean flags. W5 insertion at cmd_import follows W11's existing import setup. This is static inspection, not executable verification.

The preserved attempted worktree remains in the isolated clone at `gpt/integrator-w5-presets-on-w11-2026-10-05` with rebase in progress. original-and-target.bundle contains both source/target refs and requires base 6ae above; bundle verify passed. Source snapshots preserve original test stage 1/2/3, conflicted output, original CLI sources and auto-merged output. The receipt binds their SHA256 and all 24 selected attempted paths.

Portable reproduction in an isolated repository containing base 6ae:

```sh
git fetch /path/to/original-and-target.bundle refs/heads/gpt/integrator-w5-presets-stage-2026-10-05:refs/heads/w5-original refs/remotes/isolated-w11/selected:refs/heads/w11-target
git checkout -b w5-on-w11 w5-original
git rebase --onto w11-target 6ae0e28b8405b43aa9d8995ad8273a0bcb0b34c4 w5-on-w11
```

The conflict is retained as an unsuccessful staging receipt and must not be described as completed integration. A mechanical union of the two imports would require a separately documented resolution and subsequent full actual gates.
