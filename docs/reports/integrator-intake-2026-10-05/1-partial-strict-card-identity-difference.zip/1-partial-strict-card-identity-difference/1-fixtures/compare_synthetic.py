#!/usr/bin/env python3
"""Compare every actual synthetic metric/stat; only known ephemeral fields excluded."""
import argparse
import copy
import json
from pathlib import Path

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("before", type=Path)
ap.add_argument("after", type=Path)
ap.add_argument("--out", type=Path, required=True)
args = ap.parse_args()
a, b = (json.loads(path.read_text()) for path in (args.before, args.after))
areas = ["corpus", "temporal_cut", "catalog", "resolve", "extract", "assess", "generalize",
         "retrospective_consistency", "epistemic", "calibration_ece", "determinism", "stages"]
results = {}
for key in areas:
    av, bv = copy.deepcopy(a[key]), copy.deepcopy(b[key])
    if key == "stages":
        for value in (av, bv):
            imported = value.get("catalog", {}).get("import", {})
            if isinstance(imported, dict):
                imported.pop("conversations", None)
    results[key] = {"equal": av == bv}
    if av != bv:
        results[key].update(before=av, after=bv)
report = {"schema": "loom.integrator_synthetic_metric_parity/1",
          "before": str(args.before.resolve()), "after": str(args.after.resolve()),
          "excluded_ephemeral_fields": ["work_dir", "stages.catalog.import.conversations"],
          "all_equal": all(row["equal"] for row in results.values()), "sections": results,
          "boundary": "Fictional synthetic_dev regression; no new calibration/model-accuracy claim."}
args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"all_equal": report["all_equal"], "differences": [key for key,row in results.items() if not row["equal"]]}))
raise SystemExit(0 if report["all_equal"] else 1)
