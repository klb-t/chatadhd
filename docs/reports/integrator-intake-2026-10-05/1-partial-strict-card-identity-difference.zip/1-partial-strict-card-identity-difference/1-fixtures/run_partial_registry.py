#!/usr/bin/env python3
"""Exact 43-case public registry fixture against the completed partial normal core."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess

PIN='50e6bb9f80b0cd855e4dd1efedaf3399cac5e4e6'
HERE=Path(__file__).resolve().parent
SELECTED=[
 'loom/data/lexicons/cues.json','loom/data/lexicons/version_patterns.json',
 'loom/src/extract/extractors.cpp','loom/src/extract/lexicon.cpp','loom/src/extract/lexicon.h',
 'loom/src/generalize/common.cpp','loom/src/generalize/internal.h','loom/src/generalize/match.cpp',
 'loom/src/kb/pack_embedded.inc',
 'loom/data/prompts/README.md','loom/data/prompts/analysis.prompt','loom/data/prompts/relation.prompt',
 'loom/data/prompts/occurrence_graph.prompt','loom/data/prompts/jev_active_refute_v2.recipe',
 'loom/src/extract/prompt_contract.cpp','loom/src/extract/prompt_contract.h',
 'loom/src/extract/gen_prompt_contracts.py','loom/src/extract/prompt_contract_data.inc',
 'loom/src/extract/tests/prompt_contract_probe.cpp.fixture',
 'loom/src/extract/tests/run_prompt_contract_probe.py']

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def execute(argv,repo,out,name):
 p=subprocess.run(argv,cwd=repo,text=True,capture_output=True)
 a,b=out/(name+'.stdout'),out/(name+'.stderr');a.write_text(p.stdout);b.write_text(p.stderr)
 return {'command':argv,'exit_code':p.returncode,'stdout':str(a),'stdout_sha256':sha(a),'stderr':str(b),'stderr_sha256':sha(b)}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for x in ('repo','build-dir','out'):ap.add_argument('--'+x,type=Path,required=True)
 ap.add_argument('--cxx',default='c++');args=ap.parse_args()
 repo,build,out=args.repo.resolve(),args.build_dir.resolve(),args.out.resolve()
 out.mkdir(parents=True,exist_ok=False)
 source=HERE/'originals/loom/src/extract/tests/prompt_contract_probe.cpp.fixture'
 expected_fixture='63edc7f1ad3edc7927d98c462641b65555c38cce789cca845c2eaab38c2fdf2b'
 if sha(source)!=expected_fixture:raise RuntimeError('Exact reviewed public fixture changed')
 sources={}
 for name in SELECTED:
  wanted=hashlib.sha256(subprocess.check_output(['git','show',PIN+':'+name],cwd=repo)).hexdigest()
  sources[name]=sha(repo/name)
  if sources[name]!=wanted:raise RuntimeError('Selected partial source differs from reviewed author: '+name)
 libraries=[build/x for x in ('libloom_core.a','libloom_sqlite3_amalgamation.a','libloom_miniz.a')]
 receipt={'schema':'loom.integrator_w1_partial_registry/1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
  'W1_fixture_pin':PIN,'selected_source_sha256':sources,'libraries':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in libraries],
  'paid_or_live_calls':0,'link_mode':'Completed normal partial archive; no foreign objects/header overrides',
  'scope':'43 registry cases only. Semantic backend/semantic_usage are excluded from this increment; no 15 native or 6 ledger shipping claim.','success':False}
 try:
  binary=out/'prompt_contract_probe'
  includes=['-I'+str(repo/'loom/include'),'-I'+str(repo/'loom/src'),'-I'+str(repo/'loom/tests'),'-isystem',str(repo/'loom/third_party/nlohmann'),'-isystem',str(repo/'loom/third_party/doctest'),'-I'+str(repo/'loom/third_party/miniz')]
  receipt['compile']=execute([args.cxx,'-std=c++20','-O0','-g0','-Wall','-Wextra','-Werror',*includes,'-x','c++',str(source),'-x','none',*map(str,libraries),'-pthread','-ldl','-lm','-lssl','-lcrypto','-Wl,--no-keep-memory,--reduce-memory-overheads','-o',str(binary)],repo,out,'registry-compile')
  if receipt['compile']['exit_code']:raise RuntimeError('Registry compilation failed; first outputs retained')
  receipt['binary_sha256']=sha(binary);receipt['source_sha256']=sha(source)
  receipt['run']=execute([str(binary),str(out/'owner-overlays')],repo,out,'registry-run')
  matched=re.search(r'^checks (\d+)/(\d+)$',Path(receipt['run']['stdout']).read_text(),re.MULTILINE)
  receipt['cases']={'passed':int(matched[1]),'total':int(matched[2])} if matched else None
  receipt['success']=receipt['run']['exit_code']==0 and matched is not None and matched.groups()==('43','43')
 except (OSError,ValueError,RuntimeError) as error:receipt['error']=str(error)
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'success':receipt['success'],'receipt':str(out/'receipt.json')}));return 0 if receipt['success'] else 1

if __name__=='__main__':raise SystemExit(main())
