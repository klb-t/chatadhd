#!/usr/bin/env python3
"""Run only after explicit root confirmation of completed actual W1 PARTIAL20 normal build."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import tempfile
import time

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--build-dir',type=Path,required=True)
ap.add_argument('--evidence',type=Path,required=True)
ap.add_argument('--reader',type=Path)
args=ap.parse_args()
repo,build,e=args.repo.resolve(),args.build_dir.resolve(),args.evidence.resolve()
reader=(args.reader or e/'1-synthetic-before-investigation/vendor-python-comparison/vendor-reader').resolve()
proof=e/'1-partial-synthetic-after-tmp-proof';proof.mkdir(exist_ok=False)
before_card=e/'1-synthetic-before-tmp.json';after_card=e/'1-partial-synthetic-after-tmp.json'
if not before_card.is_file() or not reader.is_file() or not os.access(reader,os.X_OK):
 raise SystemExit('Expected valid before-card and existing vendored reader are required; do not rebuild/invent them.')
if after_card.exists() or (e/'1-partial-normal-registry').exists():
 raise SystemExit('First outputs exist; choose a separately recorded retry path instead of overwriting.')

def identity(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}

def snapshot():
 paths=subprocess.check_output(['git','ls-files','-z','loom/src','loom/include','loom/data',
  'loom/tools/eval/knowledge_eval.py','loom/tools/eval/kbeval','loom/tests/fixtures/eval/synthetic_dev'],cwd=repo).decode().split('\0')
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
  'sources':{name:identity(repo/name) for name in paths if name},
  'binaries':{name:identity(build/name) for name in ('cli/loom','libloom_core.a','libloom_sqlite3_amalgamation.a','libloom_miniz.a')},'reader':identity(reader)}

def measured(command,log):
 started=time.monotonic()
 with log.open('xb') as output:
  p=subprocess.Popen(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
  _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 return {'argv':command,'cwd':str(repo),'exit_code':p.returncode,
  'wall_seconds':time.monotonic()-started,'cpu_seconds':usage.ru_utime+usage.ru_stime,
  'peak_rss_kib':usage.ru_maxrss,'log':str(log),'log_identity':identity(log)}

receipt={'schema':'loom.integrator_after1_partial_tmp_proof/1','paid_or_live_calls':0,
 'tool_options':'Same synthetic tool/CLI bytes/config/import-mode/no floors as valid BEFORE. Authorized physical CLI path is an exact byte copy in /tmp with0755; fresh /tmp work and output names differ. Semantic backend is excluded; registry43 is fresh partial-core coverage only.',
 'before_card':identity(before_card),'success':False}
frozen=snapshot();(proof/'source-binary-before.json').write_text(json.dumps(frozen,indent=2)+'\n')
focus=measured(['python3',str(Path(__file__).with_name('run_partial_registry.py')),'--repo',str(repo),
 '--build-dir',str(build),'--out',str(e/'1-partial-normal-registry')],proof/'focused-command.txt')
receipt['focused']=focus
if focus['exit_code']:
 (proof/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(focus['exit_code'])
tmp=Path(tempfile.mkdtemp(prefix='integrator-1-partial-synthetic-after-'))
receipt['tmp_root']=str(tmp)
original_cli=build/'cli/loom'
original_identity=identity(original_cli)
copy_cli=tmp/'cli/loom';copy_cli.parent.mkdir(parents=True)
shutil.copyfile(original_cli,copy_cli);copy_cli.chmod(0o755)
copy_identity=identity(copy_cli)
if original_identity!=copy_identity:raise RuntimeError('Authorized CLI copy differs from actual normal build bytes')
receipt['cli_physical_copy']={'original_path':str(original_cli),'copy_path':str(copy_cli),'original':{**original_identity,'mode':oct(original_cli.stat().st_mode & 0o7777)},'copy_before':{**copy_identity,'mode':oct(copy_cli.stat().st_mode & 0o7777)},'sha256_identical':True,'source_binary_mutation':False,'authorization':'root explicit partial-only exact-byte /tmp CLIcopy0755'}
cli=str(copy_cli)
run=measured(['python3','loom/tools/eval/knowledge_eval.py','synthetic','--loom',cli,
 '--work',str(tmp/'work'),'--out',str(after_card)],e/'1-partial-synthetic-after-tmp.txt')
receipt['run']=run
checks=[];inputs=[];vendor_paths=[]
for db in sorted((tmp/'work').rglob('*.db')):
 rel=db.relative_to(tmp/'work');pair=[];originals={}
 for who in ('vendor','python'):
  copy=tmp/(who+'-input')/rel;copy.parent.mkdir(parents=True,exist_ok=True)
  for suffix in ('','-wal','-shm'):
   path=Path(str(db)+suffix)
   if path.exists():
    copied=Path(str(copy)+suffix);shutil.copyfile(path,copied);originals[suffix]=identity(path)
    if identity(copied)!=originals[suffix]:raise RuntimeError('DB/WAL copy drift')
  pair.append(copy)
 vendor_paths.append(pair[0]);row={'case':str(rel),'python':{}}
 con=sqlite3.connect(pair[1].as_uri()+'?mode=ro',uri=True)
 for name in ('quick_check','integrity_check'):
  try:
   rows=con.execute('PRAGMA '+name).fetchall();row['python'][name]={'rows':rows,'passed':rows==[('ok',)]}
  except sqlite3.Error as error:row['python'][name]={'error':str(error),'passed':False}
 con.close();checks.append(row);inputs.append({'case':str(rel),'files_before':originals})
vendor=measured([str(reader),*map(str,vendor_paths)],proof/'vendor-readers.txt');receipt['vendor_run']=vendor
raw=(proof/'vendor-readers.txt').read_text()
for row,path in zip(checks,vendor_paths):
 row['vendor']={}
 for name in ('quick_check','integrity_check'):
  marker='DATABASE '+str(path)+'\n';block=raw.split(marker,1)[1].split('DATABASE ',1)[0] if marker in raw else ''
  marker='SQL PRAGMA '+name+'\n';text=block.split(marker,1)[1].split('SQL ',1)[0] if marker in block else ''
  row['vendor'][name]={'passed':text.startswith('ROW ok\nRC 0 ERROR \n'),'output':text}
for data,path in zip(inputs,vendor_paths):
 data['files_after']={s:identity(Path(str(path)+s)) for s in data['files_before'] if Path(str(path)+s).exists()}
 data['database_wal_stable']=all(data['files_before'][s]==data['files_after'].get(s) for s in data['files_before'] if s!='-shm')
current=snapshot();(proof/'source-binary-after.json').write_text(json.dumps(current,indent=2)+'\n')
comparison=measured(['python3',str(Path(__file__).with_name('compare_synthetic.py')),str(before_card),
 str(after_card),'--out',str(e/'1-partial-synthetic-before-after-tmp-comparison.json')],proof/'metric-comparison.txt') if after_card.is_file() else None
passed=sum(int(x['passed']) for row in checks for who in ('python','vendor') for x in row[who].values())
receipt.update(checks=checks,inputs=inputs,source_binary_stable=frozen==current,integrity_checks_passed=passed,
 integrity_checks_total=len(checks)*4,all_24_integrity_checks_passed=len(checks)==6 and passed==24,
 metrics_comparison=comparison,python_sqlite_version=sqlite3.sqlite_version,
 vendor_sqlite_version=raw.splitlines()[0] if raw.splitlines() else None,
 scorecard=identity(after_card) if after_card.is_file() else None)
receipt['cli_physical_copy']['copy_after']={**identity(copy_cli),'mode':oct(copy_cli.stat().st_mode & 0o7777)}
receipt['cli_physical_copy']['copy_bytes_stable']=copy_identity==identity(copy_cli)
receipt['success']=receipt['cli_physical_copy']['copy_bytes_stable'] and run['exit_code']==vendor['exit_code']==0 and receipt['all_24_integrity_checks_passed'] and frozen==current and all(x['database_wal_stable'] for x in inputs) and comparison is not None and comparison['exit_code']==0
(proof/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'success':receipt['success'],'integrity':str(passed)+'/24','receipt':str(proof/'receipt.json')}))
raise SystemExit(0 if receipt['success'] else 1)
