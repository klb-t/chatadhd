Fresh partial20 checkpoint at `a95a3e1d9117af4b5ebfa3bc2a042c74efbd08f8`: registry43/43, syntheticexecution0,24/24SQLitechecks, all11metricsections identical to validBEFORE. Only versioned catalog.scan.input_hash and catalog.score.run_id changed; both were exactly recomputed using unchanged source recipes and the two intentional changed lexiconJSON files. The unchanged strict comparison outcome is retained in the separate archive linked by hash in positive-checkpoint.json. Wholecard bitparity is not claimed.

# W1 partial20 offline normal-core proof

This increment includes9precision files,5promptdata files,4promptregistry files and2registryprobe files from author50e6bb9. Semantic backend and semantic_usage are excluded. Only a fresh exact original43case registry execution belongs to this partial increment; earlier fullcandidate native15 and ledger6 evidence stays archive and is not shipping coverage.

The synthetic harness/tool/config/import-mode and CLI bytes match the valid BEFORE protocol. Only the CLI physical path is changed to an exact bytecopy in /tmp with execute bit0755, and work/output names are fresh. The original normal build file is not modified. Both readers independently check quick_check and integrity_check on six databases:24checks. The comparison excludes only work_dir and imported path-derived conversationIDs. Source/HEAD, originalCLI and all3normalarchives plus reader are fingerprinted before/after; copiedCLI bytes are fingerprinted before/after.

No binaries, databases, historical failed runs, credentials or private exports are included. Binaries and SQLite files are identified by hashes. Zero paid/live calls. The fictional synthetic_dev corpus is a regression check, not a new model semantic accuracy/calibration result.

To reproduce on a completed normal build, fetch author pin and the accepted source HEAD recorded in receipts, then build the tiny vendored reader (does not build core):

```sh
cc -std=c11 -O0 -g0 -I/path/to/chatadhd/loom/third_party/sqlite 1-synthetic-before-investigation/vendor-python-comparison/vendor-reader.c /path/to/chatadhd/loom/build/dev/libloom_sqlite3_amalgamation.a -ldl -lm -pthread -o /tmp/w1-vendor-reader
python3 1-fixtures/run_after1_partial_ready.py --repo /path/to/chatadhd --build-dir /path/to/chatadhd/loom/build/dev --evidence /path/to/new-proof-root --reader /tmp/w1-vendor-reader
```

Copy the valid BEFOREcard into the new proof root as1-synthetic-before-tmp.json. Original first outputs are never overwritten. The sourcepin validators, exact fixture hash, compiler flags and assertions remain unchanged.
