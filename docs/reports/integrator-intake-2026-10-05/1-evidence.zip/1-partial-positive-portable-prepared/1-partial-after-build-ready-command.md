# W1 partial20 positive proof

Await explicit integrator confirmation of completed partial-only normal build. This runs fresh originalregistry43 only; the rejected fullbackend native15 and ledger6 are not rerun or counted. The same synthetictool runs with the original CLI bytes copied into an executable file in /tmp, plus fresh tmpwork. Original source/core/CLI/HEAD and copy bytes are fingerprinted. Six SQLiteDBs receive both pragmas through both readers (24actualchecks). Exact BEFOREcard comparison retains all metrics/stats except work_dir and imported path-derived conversationIDs. No paid/livecalls, no thresholds/fixtureschanged.

```sh
python3 /workspace/scratch/2fbae43b23fa/evidence-2026-10-05/1-fixtures/run_after1_partial_ready.py --repo /workspace/scratch/2fbae43b23fa/chatadhd --build-dir /workspace/scratch/2fbae43b23fa/chatadhd/loom/build/dev --evidence /workspace/scratch/2fbae43b23fa/evidence-2026-10-05
```
