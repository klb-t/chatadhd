#!/usr/bin/env python3
"""Sequential integrator verification; original repository sources only."""
from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,time,traceback
ROOT=Path('/workspace/scratch/2fbae43b23fa/chatadhd')
BUILD=ROOT/'loom/build/dev'
OUT=ROOT.parent/'evidence-2026-10-05/34-supplemental'
PIN='a1be689dc026367783473133de3c25cf5ae60971'
MANIFEST={'schema':'loom.integrator_34_supplemental/1','source_commit':PIN,
          'provider_calls':0,'paid_calls':0,'build_core':False,'max_compile_jobs':1,
          'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[]}
def digest(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save():
    (OUT/'manifest.json').write_text(json.dumps(MANIFEST,indent=2,sort_keys=True)+'\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def archive_members(path):
    result=[]
    with path.open('rb') as f:
        assert f.read(8)==b'!<arch>\n',path
        while True:
            header=f.read(60)
            if not header: break
            assert len(header)==60 and header[58:60]==b'`\n',path
            name=header[:16].decode('ascii').strip()
            size=int(header[48:58].decode('ascii').strip())
            offset=f.tell()
            magic=f.read(min(4,size))
            if name not in ('/','//','/SYM64/'):
                assert size>0 and magic==b'\x7fELF',(path,name,size,magic)
                result.append({'archive_name':name,'bytes':size,'elf':True})
            f.seek(offset+size+(size%2))
    assert result,path
    return result
try:
    build_result=ROOT.parent/'evidence-2026-10-05/34-build-final-result.json'
    status=json.loads(build_result.read_text())
    assert status['exit_code']==0 and status['source_commit']==PIN,status
    assert git('rev-parse','HEAD').decode().strip()==PIN
    MANIFEST['build_final_result']={'path':str(build_result),'sha256':digest(build_result),'result':status}
    binary_records={}
    for name in ('libloom_core.a','libloom.so.0.1.0','libloom_sqlite3_amalgamation.a','libloom_miniz.a'):
        path=BUILD/name
        assert path.stat().st_size>0,path
        record={'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)}
        if path.suffix=='.a': record['elf_members']=archive_members(path)
        else:
            with path.open('rb') as f: assert f.read(4)==b'\x7fELF'
            record['elf']=True
        binary_records[name]=record
    MANIFEST['native_binaries']=binary_records
    rows=json.loads((BUILD/'compile_commands.json').read_text())
    source_records={}
    for row in rows:
        source=Path(row['file']).resolve()
        rel=source.relative_to(ROOT).as_posix()
        expected=git('show',PIN+':'+rel)
        actual=source.read_bytes()
        assert actual==expected,rel
        source_records[rel]={'sha256':hashlib.sha256(actual).hexdigest(),'git_equal':True}
    for ref in ('origin/gpt/chat-selector-2026-10-04','origin/gpt/native-graph-packet-2026-10-04'):
        paths=git('diff','--name-only','origin/main...'+ref).decode().splitlines()
        for rel in paths:
            if not rel.startswith('loom/') or '/evidence/' in rel: continue
            path=ROOT/rel
            assert path.exists(),rel
            actual=path.read_bytes()
            expected=git('show',PIN+':'+rel)
            assert actual==expected,rel
            source_records[rel]={'sha256':hashlib.sha256(actual).hexdigest(),'git_equal':True}
    MANIFEST['source_files']=source_records
    MANIFEST['source_files_verified']=len(source_records)
    symbols=subprocess.check_output(['nm','-D','--defined-only',str(BUILD/'libloom.so.0.1.0')],text=True)
    (OUT/'exported-symbols.txt').write_text(symbols)
    for name in ('loom_init_ex','loom_packet','loom_graph_packet_store','loom_free_string','loom_shutdown'):
        assert any(line.split()[-1]==name for line in symbols.splitlines()),name
    MANIFEST['required_exports']=['loom_init_ex','loom_packet','loom_graph_packet_store','loom_free_string','loom_shutdown']
    MANIFEST['preflight_passed']=True
    save()
    print('Preflight PASS: real nonempty ELF archive members/shared ABI; exact candidate source binding',flush=True)
except Exception:
    MANIFEST['preflight_passed']=False
    MANIFEST['preflight_error']=traceback.format_exc()
    save()
    raise

def run(name,argv):
    start=time.monotonic()
    row={'name':name,'argv':list(map(str,argv)),'cwd':str(ROOT),
         'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    MANIFEST['steps'].append(row);save()
    (OUT/(name+'-command.json')).write_text(json.dumps(row,indent=2)+'\n')
    print('START '+name+': '+shlex.join(row['argv']),flush=True)
    stdout=OUT/(name+'-stdout.log');stderr=OUT/(name+'-stderr.log')
    with stdout.open('wb') as out,stderr.open('wb') as err:
        result=subprocess.run(row['argv'],cwd=ROOT,stdout=out,stderr=err)
    row.update({'exit_code':result.returncode,'seconds':time.monotonic()-start,
                'stdout':str(stdout),'stdout_sha256':digest(stdout),
                'stderr':str(stderr),'stderr_sha256':digest(stderr)})
    (OUT/(name+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');save()
    print('DONE '+name+' exit='+str(result.returncode)+' seconds='+str(round(row['seconds'],2)),flush=True)
    if result.returncode:
        print('Failure retained: '+str(stdout)+' '+str(stderr),flush=True)
    return result.returncode

artifact=OUT/'w3-actual.json'
run('w3-runner',['python3',ROOT/'loom/src/chat/verify_selector.py',BUILD,
    '--usage-policy-ref',PIN,'--packet-ref',PIN,'--jobs','1','--method-graph-artifact',artifact])
canonical=ROOT/'docs/reports/chat-selector-2026-10-04-evidence/golden-consumer/input.json'
MANIFEST['canonical_input']={'path':str(canonical),'sha256':digest(canonical)}
run('canonical-consumer',['python3',ROOT/'loom/src/packet/tests/verify_method_graph_artifact.py',
    '--library',BUILD/'libloom.so.0.1.0','--artifact',canonical,'--evidence-dir',OUT/'native-canonical'])
if artifact.exists():
    MANIFEST['fresh_producer_input']={'path':str(artifact),'sha256':digest(artifact)};save()
    run('fresh-consumer',['python3',ROOT/'loom/src/packet/tests/verify_method_graph_artifact.py',
        '--library',BUILD/'libloom.so.0.1.0','--artifact',artifact,'--evidence-dir',OUT/'native-fresh'])
else:
    MANIFEST['fresh_consumer_blocked']='producer did not write artifact';save()
run('registry-variants',['python3',ROOT/'loom/src/packet/tests/reproduce_method_registry_variants.py',
    '--build-dir',BUILD,'--evidence-dir',OUT/'registry-variants'])
row=next(row for row in rows if row['file'].endswith('/src/context/context_engine.cpp'))
flags=list(row['arguments']) if 'arguments' in row else shlex.split(row['command'])
flags.remove('-c');flags.remove(row['file'])
i=flags.index('-o');del flags[i:i+2]
source=ROOT/'loom/src/kb/tests/pack_window.verify.cc'
obj=OUT/'pack-window.o';executable=OUT/'pack-window.verify'
if run('kb-window-compile',flags+['-c',source,'-o',obj])==0:
    link=[flags[0],'-fuse-ld=gold','-Wl,--no-map-whole-files',str(obj),'-o',str(executable),
          str(BUILD/'libloom_core.a'),str(BUILD/'libloom_sqlite3_amalgamation.a'),
          str(BUILD/'libloom_miniz.a'),'-lssl','-lcrypto','-pthread','-ldl','-lm']
    if run('kb-window-link',link)==0:
        MANIFEST['kb_window_executable']={'sha256':digest(executable),'bytes':executable.stat().st_size}
        run('kb-window-run',[executable,ROOT/'loom/data'])
# Capture the original runner's own full command/test manifest and logs. Its
# exact generated path is preserved by stdout and the copy below.
for line in (OUT/'w3-runner-stdout.log').read_text(errors='replace').splitlines():
    if line.startswith('W3 verification evidence: '):
        folder=Path(line.removeprefix('W3 verification evidence: '))
        MANIFEST['w3_original_evidence']=str(folder)
        for name in ('manifest.json','link.log','tests.log'):
            path=folder/name
            if path.exists(): (OUT/('w3-original-'+name)).write_bytes(path.read_bytes())
        break
# Ensure root build/source outputs used by every step did not change during run.
MANIFEST['source_files_unchanged_after']=all(digest(ROOT/rel)==record['sha256']
    for rel,record in source_records.items())
MANIFEST['native_binaries_unchanged_after']=all(digest(Path(record['path']))==record['sha256']
    for record in binary_records.values())
MANIFEST['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
MANIFEST['passed']=bool(MANIFEST['source_files_unchanged_after'] and
    MANIFEST['native_binaries_unchanged_after'] and len(MANIFEST['steps'])==7 and
    all(row['exit_code']==0 for row in MANIFEST['steps']))
save()
print('FINAL supplemental passed='+str(MANIFEST['passed']),flush=True)
raise SystemExit(0 if MANIFEST['passed'] else 1)
