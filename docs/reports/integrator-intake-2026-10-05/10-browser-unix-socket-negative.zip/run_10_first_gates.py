#!/usr/bin/env python3
"""Sequential offline UI gates for the selected first W10 increment only."""
from pathlib import Path
import argparse
import json
import sys
import traceback

from prepared_gate_common import Receipt, build_snapshot, digest, dump, require_source_manifest

HERE = Path(__file__).resolve().parent
FIXTURE_MARKERS = (
    '[harness-lifecycle] 11/11 groups passed',
    '[source-views] 8/8 groups passed',
    '[chat-settings-state] 8/8 passed;',
    '[profile-view-geometry] 9/9 passed;',
    '[workflow-snapshot] 13 groups passed;',
    '[workflow-checkpoint] 9/9 passed;',
    '[operations-panel] 7/7 groups passed;',
    '[usage-policy-ui] 1/1 group passed:',
    '[graph-reply-ui] 14/14 groups passed;',
    '[resource-controls] 4/4 groups passed:',
)
NATIVE_MARKERS = (
    '[interface-2-native] 8/8 groups passed',
    '[operations-panel] 8/8 groups passed',
    '[usage-policy-native] 4/4 groups passed',
    '[interface-2-native-runner] 3/3 suites complete; 20/20 declared groups',
)


def selected_source(path):
    # W9 may rewrite integration reports. E2E replaces its screenshot artifacts.
    return path.startswith(('loom/server/', 'loom/web/')) and '/e2e/screenshots/' not in path


def tree_hashes(root):
    return {str(path.relative_to(root)): digest(path)
            for path in sorted(root.rglob('*')) if path.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--allowlist', type=Path, default=HERE / '10-stage-selection.json')
    args = parser.parse_args()
    receipt = Receipt(args.evidence, 'loom.integrator_w10_first_ui_gates/1', args.repo, args.build)
    try:
        selected = json.loads(args.allowlist.read_text())
        receipt.data['source_ref'] = selected['source_ref']
        receipt.data['production_compile'] = 'web bundle only; no native production compilation'
        receipt.data['scope'] = 'First positive W10 increment only. Full native build/CTest must be accepted separately on this same mixed source tree.'
        receipt.data['source_verified'] = require_source_manifest(receipt.repo, selected, selected_source)
        selected_paths = [row['path'] for row in receipt.data['source_verified']]
        server = receipt.build / 'server/loom-server'
        hardcoded_server = receipt.repo / 'loom/build/dev/server/loom-server'
        if digest(server) != digest(hardcoded_server):
            raise RuntimeError('Existing E2E hardcodes build/dev/server/loom-server; it must be the same mixed binary')
        receipt.data['hardcoded_e2e_server_proof'] = {'configured': str(server),
            'hardcoded': str(hardcoded_server), 'sha256': digest(server), 'byte_hash_equal': True}
        fixture = receipt.repo / 'loom/src/packet/tests/reply-fixtures.json'
        reference = json.loads(fixture.read_text()).get('reference_source_sha256')
        if reference != '50fffaffbf1abcbb2de1b626ae51f270a5842cd3e023c1dc3cee8011a401a903':
            raise RuntimeError('W4 reference fixture changed; review fixture equivalence before accepting old W10 evidence')
        receipt.data['graph_reply_fixture'] = {'path': str(fixture), 'sha256': digest(fixture),
            'reference_source_sha256': reference}
        selected_paths.append('loom/src/packet/tests/reply-fixtures.json')
        binaries = ['loom_tests', 'libloom_core.a', 'server/loom-server']
        before = build_snapshot(receipt.repo, receipt.build, selected_paths, binaries)
        dump(receipt.out / 'inputs-before.json', before)
        web = receipt.repo / 'loom/web'
        environment = {'LOOM_SERVER_BIN': str(server)}
        environments = {
            'INTERFACE_2_EVIDENCE_DIR': 'interface-native',
            'USAGE_POLICY_EVIDENCE_DIR': 'usage-native',
            'CHAT_CONTEXT_EVIDENCE_DIR': 'chat-context',
            'APPLICATION_PROFILE_EVIDENCE_DIR': 'profiles-browser',
            'APPLICATION_PROFILE_GRAPH_EVIDENCE_DIR': 'profile-graph',
            'WORKSPACE_EVIDENCE_DIR': 'workspace',
            'CHAT_SETTINGS_EVIDENCE_DIR': 'chat-settings',
            'PROFILE_GEOMETRY_EVIDENCE_DIR': 'geometry',
            'WORKFLOW_CHECKPOINT_EVIDENCE_DIR': 'checkpoint',
        }
        environment.update({key: str(receipt.out / value) for key, value in environments.items()})
        receipt.run('web-build', ['npm', 'run', 'build'], cwd=web, env=environment)
        bundle = tree_hashes(web / 'dist')
        if not bundle or 'index.html' not in bundle:
            raise RuntimeError('Web build did not produce its complete bundle')
        receipt.data['bundle_before_ui'] = bundle
        receipt.save()
        receipt.run('w10-fixtures', ['npm', 'run', 'test:interface-2'], cwd=web, env=environment, markers=FIXTURE_MARKERS)
        receipt.run('w10-native', ['npm', 'run', 'test:interface-2-native'], cwd=web, env=environment, markers=NATIVE_MARKERS)
        receipt.run('e2e', ['npm', 'run', 'e2e'], cwd=web, env=environment, markers=('[e2e] 16/16 steps passed',))
        receipt.run('chat-context', ['npm', 'run', 'test:chat-context'], cwd=web, env=environment,
                    markers=('[chat-context] PASS:',))
        receipt.run('profiles-browser', ['npm', 'run', 'test:application-profiles-browser'], cwd=web, env=environment,
                    markers=('[application-profiles] 15/15 groups passed',))
        receipt.run('profile-graph', ['npm', 'run', 'test:application-profile-graph'], cwd=web, env=environment,
                    markers=('[application-profile-graph] 11/11 groups passed',))
        receipt.run('imported-native', ['npm', 'run', 'test:imported-message-content-native'], cwd=web, env=environment,
                    markers=('[imported-message-content-native] 4/4 groups passed',))
        receipt.run('workspace', ['npm', 'run', 'test:workspace'], cwd=web, env=environment,
                    markers=('[workspace-state] 8/8 groups passed', '[workspace] 10/10 scenarios passed'))
        after = build_snapshot(receipt.repo, receipt.build, selected_paths, binaries)
        dump(receipt.out / 'inputs-after.json', after)
        # Existing E2E deliberately refreshes screenshots; sources and binaries stay frozen.
        if before['files'] != after['files'] or before['head'] != after['head']:
            raise RuntimeError('Mixed source/build inputs changed during first-increment UI gates')
        if bundle != tree_hashes(web / 'dist'):
            raise RuntimeError('Production bundle changed during UI gates')
        receipt.data['inputs_unchanged'] = True
        receipt.data['bundle_unchanged'] = True
        receipt.data['expected_groups'] = {'fixtures': 84, 'native_ui': 20, 'e2e': 16}
        receipt.data['e2e_artifact_note'] = 'Existing e2e/run.mjs writes tracked screenshot artifacts; before/after git status retained. W9 reviews or restores those artifacts separately.'
        receipt.finish(True)
        return 0
    except Exception as exc:
        receipt.data['traceback'] = traceback.format_exc()
        receipt.finish(False, exc)
        raise


if __name__ == '__main__':
    sys.exit(main())
