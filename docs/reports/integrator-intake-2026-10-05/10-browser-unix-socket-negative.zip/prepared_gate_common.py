"""Scratch-only helpers for sequential, offline integrator receipts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shlex
import subprocess
import time


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()


def cache_value(build, key):
    for line in (build / 'CMakeCache.txt').read_text().splitlines():
        if line.startswith(key + ':'):
            return line.split('=', 1)[1]
    raise RuntimeError('CMake cache lacks ' + key)


def build_snapshot(repo, build, selected_paths, binaries):
    inputs = set((repo / p).resolve() for p in selected_paths)
    for folder in (repo / 'loom/include', repo / 'loom/src'):
        for path in folder.rglob('*'):
            if path.is_file() and path.suffix in ('.h', '.hpp', '.inc'):
                inputs.add(path.resolve())
    database = build / 'compile_commands.json'
    if database.exists():
        for row in json.loads(database.read_text()):
            file = Path(row['file'])
            if not file.is_absolute():
                file = Path(row['directory']) / file
            inputs.add(file.resolve())
    inputs.add(build / 'CMakeCache.txt')
    inputs.add(database)
    binary_paths = {(build / name).resolve() for name in binaries}
    inputs.update(binary_paths)
    rows = {}
    for path in sorted(inputs):
        if not path.is_file():
            raise RuntimeError('Missing mixed build input: ' + str(path))
        if path in binary_paths and path.stat().st_size == 0:
            raise RuntimeError('Empty mixed native binary: ' + str(path))
        rows[str(path)] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    return {'head': git(repo, 'rev-parse', 'HEAD'),
            'status': git(repo, 'status', '--short'), 'files': rows}


def require_source_manifest(repo, manifest, include=lambda path: True):
    verified = []
    for row in manifest['files']:
        path = row['path']
        if not include(path):
            continue
        expected = row.get('rebased_sha256', row.get('source_sha256', row.get('source_blob_sha256')))
        actual = digest(repo / path)
        if actual != expected:
            raise RuntimeError('Selected source drift: ' + path)
        verified.append({'path': path, 'sha256': actual})
    return verified


class Receipt:
    def __init__(self, evidence, schema, repo, build):
        self.out = evidence.resolve()
        self.out.mkdir(parents=True, exist_ok=False)
        self.repo = repo.resolve()
        self.build = build.resolve()
        self.data = {'schema': schema, 'repo': str(self.repo), 'build': str(self.build),
                     'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     'steps': [], 'paid_calls': 0, 'production_compile': False,
                     'status': 'running'}
        self.save()

    def save(self):
        dump(self.out / 'RESULTS.json', self.data)

    def run(self, name, argv, cwd=None, env=None, markers=()):
        cwd = Path(cwd or self.repo)
        argv = list(map(str, argv))
        row = {'name': name, 'argv': argv, 'cwd': str(cwd),
               'environment_overrides': env or {},
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        self.data['steps'].append(row)
        self.save()
        print('START ' + name + ': ' + shlex.join(argv), flush=True)
        started = time.monotonic()
        log = self.out / (name + '.log')
        with log.open('wb') as stream:
            result = subprocess.run(argv, cwd=cwd, env={**os.environ, **(env or {})},
                                    stdout=stream, stderr=subprocess.STDOUT)
        row.update({'exit_code': result.returncode, 'seconds': time.monotonic() - started,
                    'log': str(log), 'log_sha256': digest(log)})
        output = log.read_text(errors='replace')
        row['missing_markers'] = [marker for marker in markers if marker not in output]
        self.save()
        print('DONE ' + name + ' exit=' + str(result.returncode), flush=True)
        if result.returncode or row['missing_markers']:
            raise RuntimeError('Gate failed; original output retained: ' + str(log))
        return output

    def finish(self, passed, error=None):
        self.data['status'] = 'passed' if passed else 'failed'
        self.data['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if error:
            self.data['error'] = str(error)
        self.save()
