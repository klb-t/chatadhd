#!/usr/bin/env python3
"""Measure unchanged public replay runners; no kernel rebuild or network."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/2fbae43b23fa')
REPO=ROOT/'chatadhd'
BUILD=REPO/'loom/build/dev'
OUT=ROOT/'evidence-2026-10-05/5-replays'
ASSETS=ROOT/'evidence-2026-10-05/5-replay-assets'
COMMIT='66da570d3b5379492e128d940ad474467082c59f'
name=sys.argv[1]
assert name in ('ocr','checkpoint')
runner=ASSETS/name/('replay_acceptance.py' if name=='ocr' else 'verify_checkpoint_replay.py')
command=['python3',str(runner),'--repo',str(REPO),'--build-dir',str(BUILD),'--source-commit',COMMIT,'--out-dir',str(OUT/name)]
if name=='ocr':command+=['--expected-core-sha256','80df4818b27c966ac31cb53499771eb8d810f84b0d8f0b34c38334b86c26324d']
log=OUT/(name+'-runner-output.txt')
start=time.monotonic();epoch=time.time()
with log.open('wb') as f:
 p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT)
 _,status,usage=os.wait4(p.pid,0)
 p.returncode=os.waitstatus_to_exitcode(status)
receipt={'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),'runner_unchanged':True,'command':command,'source_commit':COMMIT,'epoch_start':epoch,'wall_seconds':time.monotonic()-start,'cpu_seconds':usage.ru_utime+usage.ru_stime,'peak_child_rss_kib':usage.ru_maxrss,'exit_code':p.returncode,'stdout_log':str(log),'stdout_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'outer_runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'production_translation_units_compiled':0,'live_provider_calls':0}
(OUT/(name+'-launch-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(p.returncode)
