#!/usr/bin/env python3
"""Read-only source and ELF archive/object binding for actual mixed W5 replay."""
from collections import Counter
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/2fbae43b23fa')
REPO=ROOT/'chatadhd'
BUILD=REPO/'loom/build/dev'
ASSETS=ROOT/'evidence-2026-10-05/5-replay-assets'
COMMIT='66da570d3b5379492e128d940ad474467082c59f'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def ident(path):
 s=path.stat()
 return {'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':digest(path)}
def archive(path):
 members=[]
 with path.open('rb') as f:
  assert f.read(8)==b'!<arch>\n',str(path)
  names=b''
  while True:
   header=f.read(60)
   if not header:break
   assert len(header)==60 and header[-2:]==b'`\n',(str(path),'ar header')
   size=int(header[48:58]); raw=header[:16].rstrip().decode()
   if raw in ('/','/SYM64/'):
    f.seek(size,1)
   elif raw=='//':names=f.read(size)
   else:
    if raw.startswith('/'):
     off=int(raw[1:]);end=names.find(b'/\n',off);assert end>=0
     name=names[off:end].decode()
    else:name=raw.rstrip('/')
    h=hashlib.sha256();left=size;first=True
    while left:
     block=f.read(min(left,1<<20));assert block
     if first:assert block[:4]==b'\x7fELF',(str(path),name,'not ELF')
     first=False;h.update(block);left-=len(block)
    members.append({'name':name,'bytes':size,'sha256':h.hexdigest()})
   if size%2:assert len(f.read(1))==1
 assert members
 return members
head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
assert head==COMMIT,(head,COMMIT)
status=subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True)
assert not status,status
cache=(BUILD/'CMakeCache.txt').read_text()
home=next(Path(x.split('=',1)[1]) for x in cache.splitlines() if x.startswith('CMAKE_HOME_DIRECTORY:'))
assert home==REPO/'loom',str(home)
source={}
for entry in subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','-z',COMMIT,'loom/src','loom/include']).split(b'\0'):
 if not entry:continue
 info,name=entry.split(b'\t',1);name=name.decode();p=REPO/name;raw=p.read_bytes()
 expected=info.split()[2].decode();actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert expected==actual,name
 source[name]={'git_blob':actual,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
asset_manifest=json.loads((ASSETS/'SHA256.json').read_text())
for name,expected in asset_manifest.items():
 p=ASSETS/name
 assert p.stat().st_size==expected['bytes'] and digest(p)==expected['sha256'],name
objects={}
for p in sorted((BUILD/'CMakeFiles/loom_core.dir').rglob('*.o')):
 with p.open('rb') as f:assert f.read(4)==b'\x7fELF',str(p)
 objects[str(p.relative_to(BUILD))]=ident(p)
libraries={}
for name in ('libloom_core.a','libloom_sqlite3_amalgamation.a','libloom_miniz.a'):
 p=BUILD/name;members=archive(p)
 libraries[name]={**ident(p),'elf_members':len(members),'members':members}
core=libraries['libloom_core.a']['members']
obj_counter=Counter((Path(p).name,d['bytes'],d['sha256']) for p,d in objects.items())
ar_counter=Counter((d['name'],d['bytes'],d['sha256']) for d in core)
assert obj_counter==ar_counter,{'missing':list((obj_counter-ar_counter).elements()),'extra':list((ar_counter-obj_counter).elements())}
receipt={'utc_epoch_seconds':time.time(),'expected_commit':COMMIT,'actual_head':head,'status':status,'cmake_home':str(home),'cmake_cache':ident(BUILD/'CMakeCache.txt'),'source_files':source,'source_files_total':len(source),'core_objects':objects,'core_objects_total':len(objects),'libraries':libraries,'asset_manifest_sha256':digest(ASSETS/'SHA256.json'),'assets_verified':len(asset_manifest),'all_objects_and_members_elf':True,'archive_members_equal_objects':True,'production_edits':0,'production_translation_units_compiled':0}
out=Path(sys.argv[1]);out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out),'head':head,'source_files':len(source),'core_objects':len(objects),'libraries':{n:{k:v for k,v in d.items() if k!='members'} for n,d in libraries.items()},'assets_verified':len(asset_manifest),'elf':True,'core_members_match_actual_objects':True},indent=2))
