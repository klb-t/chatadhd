# W5 pinned replay assets for integrator, 2026-10-05

All nine input/runner files are exact public Git bytes from `5f0abd20dd83e5c0e7f43e84c333d5e23a5e681f`; measured code `4e8c3dec29bb3aa1e343e09bee00b7768f0fc0f2`, base `30ad7d37337d6641cb7714b03e9feff0e6e25d25`. SOURCE_BINDINGS.json binds source paths, Git blobs and SHA256. Neither original runner nor probe was edited. The two checkpoint originals were copied from the older tracked native/probes/original location because the newly published runner expects a sibling original directory not present at its current Git path.

Preparation only: no build, execution, live provider or paid call. Await the integrator's completed W5+W2+W3/W4 source and library. commands.json contains argument arrays; replace placeholders with that actual checkout/build/commit and a fresh output directory. Expected OCR 3/3 MIME,22/22 controls; checkpoint 2/2 scenarios,31/31 controls. Do not bind the merged build to historical W5 SHA if its source tree also contains other accepted changes.

```bash
W5_REPO=/path/to/actual/merged/source
W5_BUILD=/path/to/completed/merged-build
W5_COMMIT=$(git -C "$W5_REPO" rev-parse HEAD)
W5_OUTPUT=$(mktemp -d /tmp/w5-merged-replay.XXXXXX)
python3 /workspace/scratch/2fbae43b23fa/evidence-2026-10-05/5-replay-assets/ocr/replay_acceptance.py --repo "$W5_REPO" --build-dir "$W5_BUILD" --source-commit "$W5_COMMIT" --out-dir "$W5_OUTPUT/ocr"
python3 /workspace/scratch/2fbae43b23fa/evidence-2026-10-05/5-replay-assets/checkpoint/verify_checkpoint_replay.py --repo "$W5_REPO" --build-dir "$W5_BUILD" --source-commit "$W5_COMMIT" --out-dir "$W5_OUTPUT/checkpoint"
```

Only tiny probes compile when these commands are explicitly run. Production source trees and objects are not edited or recompiled by these runners. Actual completed-build provenance is required; source/hash observations alone do not prove prior object compilation. The OCR synthetic key is obviously fake and its transport is scripted.
