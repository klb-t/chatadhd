# Independent W5 replay on actual mixed kernel

Source: `66da570d3b5379492e128d940ad474467082c59f` (integrator mixed W2/W3/W4/W5 tree). The original public W5 runners and probes were used unchanged. The checkpoint probes retain the previously documented single-line `options.resume = true;` adaptation; unadapted original probes and adaptation hashes are included. Original files were staged from their published tracked paths because the checkpoint runner expects an `original/` sibling directory absent from the author's latest evidence subdirectory. Source bindings are in `assets/SOURCE_BINDINGS.json`.

Results: OCR 3/3 MIME routes, 22/22 acceptance checks; checkpoint malformed auxiliary member 17/17 and transient link failure/recovery 14/14, total 31/31. Zero live/provider calls and zero production translation units compiled. Three tiny probes compiled serially against the actual already-built kernel, SQLite and miniz libraries. All data and the scripted HTTP key are synthetic. Full CTest is separate and is not asserted by this bundle.

Preflight before and after matches HEAD, 274 tracked source/header byte hashes, 143 ELF kernel objects and all 143 ELF archive members. The archive members equal the object basename/size/SHA multiset. All source, object, library and CMake-cache bytes and object/library mtimes remained unchanged. Actual core: 381068852 bytes, SHA256 `80df4818b27c966ac31cb53499771eb8d810f84b0d8f0b34c38334b86c26324d`. The checkpoint runner's broader source/dependency manifest contains 284 files. OCR outer elapsed 11.49 seconds, peak child RSS 342988 KiB; checkpoint 38.44 seconds, peak child RSS 351160 KiB.

Complete commands, compiler version, logs, raw results, captured HTTP requests, synthetic PNG/tiny ZIPs/databases, source manifests and receipts are retained under `actual-mixed-build/`. Native binaries and production objects/libraries are omitted; their hashes remain in receipts and the preflight manifest. Previous negative evidence is preserved separately, not replaced by this positive replay.

## Portable replay

Use a fresh public Git checkout of the exact source revision and a completed native CMake build whose `CMAKE_HOME_DIRECTORY` resolves to that checkout's `loom/` directory. These commands compile only the probe programs; they do not configure or rebuild the kernel. The output directories must be fresh. Change `TASK_COMMIT` only when intentionally verifying a different actual merged build; each runner checks actual source/header bytes against that exact Git revision and records actual library hashes before and after.

```sh
TASK_REPO=/absolute/path/to/public/checkout
TASK_BUILD=/absolute/path/to/completed/native/build
TASK_EVIDENCE=/absolute/path/to/extracted/bundle
TASK_OUT=/absolute/path/to/fresh/replay-output
TASK_COMMIT=66da570d3b5379492e128d940ad474467082c59f
python3 "$TASK_EVIDENCE/assets/ocr/replay_acceptance.py" --repo "$TASK_REPO" --build-dir "$TASK_BUILD" --source-commit "$TASK_COMMIT" --out-dir "$TASK_OUT/ocr"
python3 "$TASK_EVIDENCE/assets/checkpoint/verify_checkpoint_replay.py" --repo "$TASK_REPO" --build-dir "$TASK_BUILD" --source-commit "$TASK_COMMIT" --out-dir "$TASK_OUT/checkpoint"
```

`actual-mixed-build/preflight.py` and `run_original.py` are historical launch/preflight helpers with the original workspace paths; portable replay uses the unchanged parameterized runners above. `SHA256.json` hashes every bundled file except itself.
