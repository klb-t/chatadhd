import argparse,hashlib,json,shlex,subprocess,time
from pathlib import Path
R=Path('/workspace/scratch/2fbae43b23fa/chatadhd');E=R.parent/'evidence-2026-10-05';B=R/'loom/build/dev';N='/root/.local/bin/ninja';C='/root/.local/bin/cmake'
p=argparse.ArgumentParser();p.add_argument('lane');p.add_argument('--build-only',action='store_true');a=p.parse_args();out=E/(a.lane+'-build');out.mkdir(exist_ok=False);records=[]
def run(cmd,name,cwd=R,shell=False):
 t=time.monotonic()
 with (out/name).open('w') as f:r=subprocess.run(cmd,cwd=cwd,shell=shell,stdout=f,stderr=subprocess.STDOUT)
 rec={'argv':cmd,'cwd':str(cwd),'exit_code':r.returncode,'seconds':time.monotonic()-t,'log_sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()};records.append(rec);return r.returncode
if not (B/'build.ninja').exists():
 assert run([C,'-S',str(R/'loom'),'-B',str(B),'-G','Ninja','-DCMAKE_MAKE_PROGRAM='+N,'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-O0 -g0','-DCMAKE_C_FLAGS_DEBUG=-O0 -g0','-DLOOM_USE_SYSTEM_SQLITE=OFF','-DLOOM_SHARED=ON','-DLOOM_BUILD_TESTS=ON','-DLOOM_BUILD_CLI=ON','-DLOOM_BUILD_SERVER=ON','-DLOOM_WERROR=ON'],'configure.txt')==0
initial=run([C,'--build',str(B),'--parallel','3'],'build.txt')
commands=json.loads((B/'compile_commands.json').read_text());repairs=[];iteration=0;code=initial
while True:
 bad=[]
 for obj in sorted((B/'CMakeFiles').rglob('*.o')):
  with obj.open('rb') as f:h=f.read(4)
  if h!=b'\x7fELF':bad.append(obj)
 if not bad:
  if code:raise RuntimeError('Build failed without a malformed object; inspect original log')
  break
 for obj in bad:
  old={'path':str(obj.relative_to(B)),'bytes':obj.stat().st_size,'sha256':hashlib.sha256(obj.read_bytes()).hexdigest()}
  name=str(obj.relative_to(B));cmd=next(x for x in commands if '-o '+name+' ' in x['command'])
  assert run(cmd['command'],'object-repair-'+str(len(repairs))+'.txt',Path(cmd['directory']),True)==0
  assert obj.read_bytes()[:4]==b'\x7fELF';old['after_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest();old['after_bytes']=obj.stat().st_size;repairs.append(old)
 iteration+=1;code=run([C,'--build',str(B),'--parallel','3'],'build-repeat-'+str(iteration)+'.txt')
names=['libloom_core.a','libloom_miniz.a','libloom_sqlite3_amalgamation.a','libloom.so.0.1.0','loom_tests','loom_compat_tool','loom_candidate_graph_native_tool','cli/loom','server/loom-server'];binaryrepairs=[]
for name in names:
 q=B/name
 with q.open('rb') as f:h=f.read(8)
 good=h==b'!<arch>\n' if name.endswith('.a') else h[:4]==b'\x7fELF'
 if good:continue
 rec={'path':name,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
 cmd=subprocess.check_output([N,'-C',str(B),'-t','commands',name],text=True).splitlines()[-1]
 assert run(cmd,'binary-repair-'+str(len(binaryrepairs))+'.txt',B,True)==0
 rec['after_sha256']=hashlib.sha256(q.read_bytes()).hexdigest();binaryrepairs.append(rec)
for q in (B/'CMakeFiles').rglob('*.o'):assert q.read_bytes()[:4]==b'\x7fELF',str(q)
for name in names:
 q=B/name;h=q.read_bytes()[:8];assert h==b'!<arch>\n' if name.endswith('.a') else h[:4]==b'\x7fELF',name
receipt={'schema':'loom.integrator_build/1','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'commands':records,'initial_build_exit':initial,'object_repairs':repairs,'binary_repairs':binaryrepairs,'all_objects':len(list((B/'CMakeFiles').rglob('*.o'))),'validation':'nonempty ELF objects and valid ELF/archive binaries'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'source':receipt['source_commit'],'objects':receipt['all_objects'],'object_repairs':len(repairs),'binary_repairs':len(binaryrepairs),'initial_exit':initial}),flush=True)
if not a.build_only:raise SystemExit(subprocess.run(['python3',str(R.parent/'integrator_gate.py'),a.lane]).returncode)
