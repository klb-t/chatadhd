#!/bin/bash
# usage: gate.sh <label>   (run from repo root; builds loom/build/dev, runs ctest+guard+web)
set -u
LABEL=$1; S=/tmp/claude-0/-home-user-chatadhd/f7746154-a4ac-59c6-b92b-895f7dff6770/scratchpad/gate
OUT=$S/$LABEL; rm -rf $OUT; mkdir -p $OUT
cd /home/user/chatadhd
git rev-parse HEAD > $OUT/commit.txt
B=loom/build/dev
cmake -S loom -B $B -G Ninja -DCMAKE_BUILD_TYPE=Debug -DLOOM_USE_SYSTEM_SQLITE=OFF -DLOOM_BUILD_SERVER=ON > $OUT/configure.txt 2>&1 || { echo CONFIGURE_FAIL; exit 1; }
flock /tmp/claude-0/-home-user-chatadhd/f7746154-a4ac-59c6-b92b-895f7dff6770/scratchpad/gate/build.lock cmake --build $B --parallel 4 > $OUT/build.txt 2>&1 || { echo BUILD_FAIL; tail -40 $OUT/build.txt; exit 1; }
ctest --test-dir $B --show-only=json-v1 > $OUT/manifest.json
ctest --test-dir $B --parallel 4 --output-on-failure --test-output-size-passed 0 --test-output-size-failed 0 --output-junit $OUT/ctest.xml > $OUT/ctest.txt 2>&1; CT=$?
python3 $S/verify_ctest.py --manifest $OUT/manifest.json --junit $OUT/ctest.xml --preset dev --output $OUT/cases.json > $OUT/guard.txt 2>&1; GD=$?
(cd loom/web && npm run build) > $OUT/web.txt 2>&1; WB=$?
echo "ctest=$CT guard=$GD web=$WB"; grep -E 'tests passed|tests failed' $OUT/ctest.txt; grep -A30 'The following tests FAILED' $OUT/ctest.txt | head -30; tail -5 $OUT/guard.txt
