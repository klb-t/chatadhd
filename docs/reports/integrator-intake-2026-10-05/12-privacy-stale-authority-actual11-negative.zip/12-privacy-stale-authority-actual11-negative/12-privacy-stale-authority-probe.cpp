#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <string>
#include "loom/db.h"
#include "loom/onboarding_store.h"
#include "loom/util/json.h"

using namespace loom;
using namespace loom::onboarding;
template<class T> T get(Result<T>&& value) {
  if (!value) throw std::runtime_error(value.error().to_string());
  return std::move(value).value();
}
Json apply(OnboardingStore& store, Json state, const Json& action) {
  return get(store.apply(state.at("user_id").get<std::string>(), state.at("revision").get<std::int64_t>(), action));
}
Json suppress(const char* key) {return Json{{"target","layers"},{"op","disable"},{"key",key}};}
Json choose_privacy(const Json& value) {
  return Json{{"target","layers"},{"op","override"},{"key","onboarding.privacy"},{"value",value},
              {"time","2000-01-01T00:00:00Z"},{"provenance","user_stated"},
              {"source_refs",Json::array({"synthetic/explicit-owner-privacy-choice"})}};
}
Json run_case(const std::filesystem::path& root, const std::string& name, const std::string& operation,
              bool disable_settings_before, bool disable_settings_after, bool disable_privacy) {
  DbOptions options; options.enable_fts=false;
  auto db=get(Database::open(root/(name+".db"),options));
  OnboardingStore store(*db);
  const auto user="synthetic/w12-stale-privacy/"+name;
  auto state=get(store.open(user));
  auto initial=state.at("profile").at("privacy");
  // The inference scenario starts with an explicit synthetic user allowance.
  // Its subsequent explicit denial must take precedence; no provider is used.
  if (operation=="infer") {
    initial["rules"][0]["infer"]=true;
    initial["rules"][0]["explicit_only"]=false;
    state=apply(store,state,choose_privacy(initial));
  }
  Json request{{"op",operation},{"category",state.at("profile").at("fields").at("communication.style").at("category")},
               {"field","communication.style"},{"provenance","user_stated"}};
  auto before=get(store.policy_decision(user,request));
  auto denied=initial;
  denied["rules"][0][operation]=false;
  if (operation=="infer") denied["rules"][0]["explicit_only"]=true;
  if (disable_settings_before) state=apply(store,state,suppress("onboarding.settings"));
  if (!disable_privacy) state=apply(store,state,choose_privacy(denied));
  if (disable_settings_after) state=apply(store,state,suppress("onboarding.settings"));
  if (disable_privacy) state=apply(store,state,suppress("onboarding.privacy"));
  auto result=get(store.policy_decision(user,request));
  auto persisted=get(store.read(user));
  OnboardingStore restarted(*db);
  auto restarted_result=get(restarted.policy_decision(user,request));
  bool correct=result.at("allowed")==false && restarted_result.at("allowed")==false;
  return Json{{"case",name},{"operation",operation},{"expected_allowed",false},{"correct",correct},
    {"before",before},{"request",request},{"actual",result},{"restart_actual",restarted_result},
    {"profile_privacy",persisted.at("profile").at("privacy")},
    {"effective_privacy",persisted.at("effective_privacy")},
    {"stored_profile_is_requested_privacy",disable_privacy?Json(nullptr):Json(persisted.at("profile").at("privacy")==denied)}};
}
int main(int argc,char** argv) {
  Json report{{"schema","loom.integrator_w12_privacy_stale_authority_probe/1"},
    {"paid_or_live_calls",0},{"provider_transport_constructed",false},
    {"boundary","Policy-decision API only; no claim that a model request or provider dispatch executed."},
    {"cases",Json::array()}};
  try {
    if(argc!=2) throw std::runtime_error("Supply exactly one new empty /tmp database directory");
    const std::filesystem::path root(argv[1]);
    if(!std::filesystem::create_directory(root)) throw std::runtime_error("Refusing existing fixture database directory");
    report["cases"].push_back(run_case(root,"control_direct_owner_store_denial","store",false,false,false));
    report["cases"].push_back(run_case(root,"owner_store_denial_after_unrelated_settings_disabled","store",true,false,false));
    report["cases"].push_back(run_case(root,"owner_infer_denial_after_unrelated_settings_disabled","infer",true,false,false));
    report["cases"].push_back(run_case(root,"control_existing_owner_denial_survives_settings_disabled","store",false,true,false));
    report["cases"].push_back(run_case(root,"control_disabled_privacy_denies_retained_rules","store",false,false,true));
    int passed=0;for(const auto& row:report["cases"]) passed+=row.at("correct").get<bool>()?1:0;
    report["passed"]=passed;report["total"]=5;report["confirmed_stale_permit"]=false;
    for(const auto& row:report["cases"]) {
      if(row.at("case").get<std::string>().starts_with("owner_") && row.at("actual").at("allowed")==true &&
         row.at("actual").at("resolution").at("status")=="effective" &&
         row.at("actual").at("resolution").at("layer")=="user") report["confirmed_stale_permit"]=true;
    }
    std::cout<<report.dump(2)<<'\n';return passed==5?0:1;
  } catch(const std::exception& e) {
    report["fixture_error"]=e.what();std::cout<<report.dump(2)<<'\n';return 2;
  }
}
