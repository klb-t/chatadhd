#!/usr/bin/env python3
"""Compile only the tiny offline probe, after explicit actual W11 build-ready signal."""
from pathlib import Path
import argparse, hashlib, json, subprocess, tempfile

ap=argparse.ArgumentParser(description=__doc__)
for name in ('repo','build-dir','out'):ap.add_argument('--'+name,type=Path,required=True)
ap.add_argument('--expected-head',required=True)
args=ap.parse_args();repo,build,out=args.repo.resolve(),args.build_dir.resolve(),args.out.resolve()
source=Path(__file__).with_name('12-privacy-stale-authority-probe.cpp')
if out.exists():raise SystemExit('Refusing to overwrite any first probe outputs')
def identity(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return {'bytes':Path(path).stat().st_size,'sha256':h.hexdigest()}
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z','loom/src','loom/include','loom/data'],cwd=repo).decode().split('\0')
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
  'sources':{n:identity(repo/n) for n in names if n},
  'libraries':{str(p):identity(p) for p in libraries},'fixture':identity(source)}
def execute(command,name):
 p=subprocess.run(command,cwd=repo,text=True,capture_output=True)
 a,b=out/(name+'.stdout'),out/(name+'.stderr');a.write_text(p.stdout);b.write_text(p.stderr)
 return {'argv':command,'exit_code':p.returncode,'stdout':str(a),'stdout_identity':identity(a),'stderr':str(b),'stderr_identity':identity(b)}
libraries=[build/p for p in ('libloom_core.a','libloom_sqlite3_amalgamation.a','libloom_miniz.a')]
if not (repo/'loom/include/loom/runtime_profile.h').is_file():raise SystemExit('Actual W11 header absent; wait for completed actual W11 normal build')
before=snapshot()
if before['head']!=args.expected_head:raise SystemExit('Frozen actual build HEAD does not match explicit ready pin')
out.mkdir(parents=True)
(out/'source-binary-before.json').write_text(json.dumps(before,indent=2)+'\n')
receipt={'schema':'loom.integrator_w12_policy_probe_execution/1','paid_or_live_calls':0,'head':before['head'],
 'link_mode':'Tiny public fixture linked directly against completed actual normal core; no production compilation or foreign objects/header overrides.',
 'result_boundary':'Public native policy decisions only, not a provider dispatch; first outputs remain unchanged.'}
binary=Path(tempfile.mkdtemp(prefix='integrator-w12-policy-probe-bin-'))/'probe'
includes=['-I'+str(repo/'loom/include'),'-I'+str(repo/'loom/src'),'-isystem',str(repo/'loom/third_party/nlohmann'),'-I'+str(repo/'loom/third_party/miniz')]
receipt['compile']=execute(['c++','-std=c++20','-O0','-g0','-Wall','-Wextra','-Werror',*includes,str(source),*map(str,libraries),'-pthread','-ldl','-lm','-lssl','-lcrypto','-Wl,--no-keep-memory,--reduce-memory-overheads','-o',str(binary)],'compile')
if receipt['compile']['exit_code']==0:
 receipt['binary']=identity(binary)
 tmp=Path(tempfile.mkdtemp(prefix='integrator-w12-policy-probe-db-'))
 receipt['run']=execute([str(binary),str(tmp/'cases')],'run')
 try:receipt['observed']=json.loads((out/'run.stdout').read_text())
 except ValueError:receipt['output_parse_failed']=True
after=snapshot();(out/'source-binary-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt['source_binary_stable']=before==after
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out/'receipt.json'),'compile_exit':receipt['compile']['exit_code'],'run_exit':receipt.get('run',{}).get('exit_code'),'source_binary_stable':before==after}))
raise SystemExit(receipt.get('run',receipt['compile'])['exit_code'])
