# Archived negative W12 privacy policy regression

First unmodified actual normal-core execution at215563c8fddca0187f99f16ce8c2894459dbc53e compiled the tiny5case publicfixture with-Werror, exit0, then ran exit1. Three controls passed; two latestownerdenials returnedallowed:true from the publicnativepolicy API. The effective userlayer records the denial while the storedprofile retains older permissive rules. A newly constructed OnboardingStore on the same open persistedDatabase reproduced the response; this is not a separateprocess/database-reopen claim. No models, providertransport, dispatch, paidcalls or privatearchive were used.

All first rawstdout/stderr and receipts/hashbindings remain unchanged. Source/HEAD and3normalarchives were frozen before/after. No DB/ELF files are included. This result does not alter the unchanged fullCTest gate; it is an independent missing regression routed toW12. The W12store/layers/adapter source is byteidentical to3c0bc36, and the Unavailable branch precedes W11adapter use; no before11binarycomparison was run and no measuredworseningbyW11 is claimed.

Reproduce only after completed normal W11/W12 build:

```sh
python3 run_12_privacy_probe.py --repo /path/to/chatadhd --build-dir /path/to/normal/build --out /tmp/fresh-w12-policy-evidence --expected-head 215563c8fddca0187f99f16ce8c2894459dbc53e
```
