#!/usr/bin/env python3
"""Run existing W12 supplements on the selected mixed tree; never build production."""
from pathlib import Path
import argparse
import copy
import json
import re
import shlex
import sys
import traceback
import xml.etree.ElementTree as ET

from prepared_gate_common import Receipt, build_snapshot, cache_value, digest, dump, require_source_manifest

HERE = Path(__file__).resolve().parent
SOURCE = '3c0bc36552ef9851f1174946cfb108549aae3228'
SUITES = {'unit.test_onboarding': (18, 228),
          'unit.test_onboarding_graph': (11, 2139),
          'unit.test_onboarding_layers': (8, 51),
          'unit.test_onboarding_store': (14, 286)}
REGEX = r'^unit\.test_onboarding(_graph|_layers|_store)?$'


def count_from_full_junit(receipt, full_junit, guard):
    """Derive the four W12 results from root's full gate, without rerunning CTest."""
    original = ET.parse(full_junit).getroot()
    for suite in original.iter():
        if suite.tag in ('testsuite', 'testsuites'):
            for attribute in ('failures', 'errors', 'skipped', 'disabled'):
                if int(suite.get(attribute, '0')):
                    raise RuntimeError('Root full JUnit is not a passed full gate: ' + attribute)
    cases = list(original.iter('testcase'))
    if any(any(case.find(tag) is not None for tag in ('failure', 'error', 'skipped')) for case in cases):
        raise RuntimeError('Root full JUnit contains a failed/skipped entry')
    selected = [case for case in cases if case.get('name') in SUITES]
    names = [case.get('name') for case in selected]
    if sorted(names) != sorted(SUITES):
        raise RuntimeError('Root full gate does not contain exactly the four W12 entries')
    subset = ET.Element('testsuite', name='root-full-gate-W12-projection', tests='4', failures='0', errors='0', skipped='0')
    for case in selected:
        subset.append(copy.deepcopy(case))
    subset_path = receipt.out / 'native-from-full.xml'
    ET.ElementTree(subset).write(subset_path, encoding='utf-8', xml_declaration=True)
    manifest = {'kind': 'ctestInfo', 'tests': [{'name': name} for name in sorted(SUITES)]}
    dump(receipt.out / 'native-from-full-inventory.json', manifest)
    receipt.run('native-case-guard', [sys.executable, guard, '--manifest', receipt.out / 'native-from-full-inventory.json',
                '--junit', subset_path, '--output', receipt.out / 'native-counts.json', '--preset', 'dev'])
    counts = json.loads((receipt.out / 'native-counts.json').read_text())
    observed = {row['name']: (row.get('cases'), row.get('assertions')) for row in counts['entries']}
    if observed != SUITES or counts['executed_entries'] != 4:
        raise RuntimeError('Original W12 case/assertion denominator drift: ' + repr(observed))
    receipt.data['native_from_full_gate'] = {'original_junit': str(full_junit.resolve()),
        'original_junit_sha256': digest(full_junit), 'original_outer_entries': len(cases),
        'derived_subset': str(subset_path), 'rerun': False, 'counts': counts}


def method_bridge(receipt):
    """Compile only the original offline fixture against the already-built mixed core."""
    original = HERE / '12-prepared/original-w3-method-bridge.cpp'
    source_record = json.loads((HERE / '12-prepared/fixture-source.json').read_text())
    if digest(original) != source_record['sha256']:
        raise RuntimeError('Original public bridge fixture hash drift')
    folder = receipt.out / 'method-bridge'
    folder.mkdir()
    output_folder = folder / 'outputs'
    output_folder.mkdir()
    old = 'static const std::filesystem::path evidence = "/tmp/onboarding-verification-2026-10-04/w3-method-contract-final";'
    text = original.read_text()
    if text.count(old) != 1:
        raise RuntimeError('Original fixture evidence path declaration changed')
    changed = text.replace(old, 'static const std::filesystem::path evidence = ' + json.dumps(str(output_folder)) + ';')
    source = folder / 'runner.cpp'
    source.write_text(changed)
    receipt.data['method_bridge'] = {'original_fixture': source_record,
        'reproduction_source': str(source), 'reproduction_sha256': digest(source),
        'mechanical_edit': 'Only fixed historical evidence output path redirected to the fresh receipt folder.',
        'scope': 'Actual W3 load/resolve of W12 definitions; zero providers and zero actual method executions.'}
    rows = json.loads((receipt.build / 'compile_commands.json').read_text())
    row = next(row for row in rows if row['file'].endswith('/tests/test_onboarding_graph.cpp'))
    compile_command = list(row['arguments']) if 'arguments' in row else shlex.split(row['command'])
    compile_command.remove('-c')
    compile_command.remove(row['file'])
    index = compile_command.index('-o')
    del compile_command[index:index + 2]
    obj = folder / 'runner.o'
    executable = folder / 'runner'
    compile_command += ['-I' + str(receipt.repo / 'loom/src/context'), '-c', str(source), '-o', str(obj)]
    receipt.run('bridge-fixture-compile', compile_command, cwd=row['directory'])
    if cache_value(receipt.build, 'CMAKE_GENERATOR') != 'Ninja':
        raise RuntimeError('Optional bridge needs the actual Ninja link command; no guessed dependency flags')
    ninja = cache_value(receipt.build, 'CMAKE_MAKE_PROGRAM')
    link_commands = receipt.run('bridge-link-command-query', [ninja, '-C', receipt.build, '-t', 'commands', 'loom_tests'])
    links = [line for line in link_commands.splitlines() if re.search(r'\s-o\s+loom_tests(?:\s|$)', line)]
    if len(links) != 1:
        raise RuntimeError('Cannot identify unique actual loom_tests link command')
    tokens = shlex.split(links[0])
    if tokens[:2] == [':', '&&']:
        tokens = tokens[2:]
    if tokens[-2:] == ['&&', ':']:
        tokens = tokens[:-2]
    if any(token in ('&&', ';', '|') for token in tokens):
        raise RuntimeError('Unsupported mixed link command; retain evidence and ask integrator to adapt mechanically')
    tokens = [token for token in tokens if not token.endswith(('.o', '.obj'))]
    index = tokens.index('-o')
    tokens[index + 1] = str(executable)
    tokens.insert(1, str(obj))
    receipt.run('bridge-fixture-link', tokens, cwd=receipt.build)
    receipt.run('bridge-fixture-run', [executable], markers=('PASS: actual W3 load/resolve accepted W12 definitions',))
    verification = json.loads((output_folder / 'verification.json').read_text())
    required = ('method_registry_load', 'absent_host_method_visible', 'advertised_host_available',
                'tampered_source_rejected', 'same_method_multiversion_load_resolve',
                'native_saved_receipt_fixture_projected')
    if verification.get('status') != 'passed' or not all(verification.get(key) is True for key in required):
        raise RuntimeError('Bridge fixture incomplete or failed')
    if verification.get('provider_calls') != 0 or verification.get('actual_method_executions') != 0:
        raise RuntimeError('Fixture scope no longer offline declarations only')
    receipt.data['method_bridge']['verification'] = verification


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--with-method-bridge', action='store_true')
    parser.add_argument('--full-junit', type=Path, help='Read four W12 results from root full passed gate; never rerun them')
    parser.add_argument('--allowlist', type=Path, default=HERE / '12-source-only-allowlist.json')
    parser.add_argument('--guard', type=Path, default=HERE / 'verify_ctest.py')
    args = parser.parse_args()
    receipt = Receipt(args.evidence, 'loom.integrator_w12_supplements/1', args.repo, args.build)
    try:
        selected = json.loads(args.allowlist.read_text())
        receipt.data['source_ref'] = SOURCE
        receipt.data['selected_source_verified'] = require_source_manifest(receipt.repo, selected)
        binaries = ['loom_tests', 'libloom_core.a']
        before = build_snapshot(receipt.repo, receipt.build, selected['positive_paths'], binaries)
        dump(receipt.out / 'inputs-before.json', before)
        receipt.run('generator', [sys.executable, 'loom/src/onboarding/gen_onboarding_pack.py', '--check'])
        controller = receipt.run('controller', ['node', '--test', 'loom/web/src/onboarding/controller.test.mjs'])
        if not re.search(r'^# tests 17\s*$', controller, re.MULTILINE) or not re.search(r'^# fail 0\s*$', controller, re.MULTILINE):
            raise RuntimeError('Controller must execute all 17 original tests, not merely return exit0')
        if args.full_junit:
            count_from_full_junit(receipt, args.full_junit, args.guard)
        else:
            receipt.data['native_from_full_gate'] = {'status': 'not_supplied', 'rerun': False,
                'note': 'Full root CTest is a separate acceptance gate; original W12 suites expect 51 cases/2704 assertions.'}
        if args.with_method_bridge:
            method_bridge(receipt)
        else:
            receipt.data['method_bridge'] = {'status': 'not_run', 'optional': True}
        after = build_snapshot(receipt.repo, receipt.build, selected['positive_paths'], binaries)
        dump(receipt.out / 'inputs-after.json', after)
        if before != after:
            raise RuntimeError('Mixed source/build inputs changed during supplements')
        receipt.data['inputs_unchanged'] = True
        receipt.finish(True)
        return 0
    except Exception as exc:
        receipt.data['traceback'] = traceback.format_exc()
        receipt.finish(False, exc)
        raise


if __name__ == '__main__':
    sys.exit(main())
