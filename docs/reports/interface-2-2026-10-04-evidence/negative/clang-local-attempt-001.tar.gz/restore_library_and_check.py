#!/usr/bin/env python3
"""Restore verified package bytes and run both TU checks in one process tree.

Usage: python3 restore_library_and_check.py --out /absolute/fresh/evidence-dir
All downloaded packages and runtime files are local; this writes no repo files.
"""
import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--out", required=True)
options = parser.parse_args()
base = Path("/workspace/scratch/308e2340bae7/clang18-local-4gyTMc")
package = base / "libclang-cpp18_1%3a18.1.3-1ubuntu1_amd64.deb"
expected_package = "e91eda104813ee0468d145d010a4a4e142401f3f17f9a65596c66d416298d018"
assert hashlib.sha256(package.read_bytes()).hexdigest() == expected_package
library = base / "local-root/usr/lib/llvm-18/lib/libclang-cpp.so.18.1"
process = subprocess.Popen(["dpkg-deb", "--fsys-tarfile", str(package)], stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout, mode="r|") as archive:
    for member in archive:
        if member.name != "./usr/lib/llvm-18/lib/libclang-cpp.so.18.1":
            continue
        payload = archive.extractfile(member).read()
        assert hashlib.sha256(payload).hexdigest() == "b9592746f7f8ff1156680fb1fad5faf5486df7a67aca8327cc959463416c6718"
        library.write_bytes(payload)
        library.chmod(member.mode)
assert process.wait() == 0
environment = {**os.environ, "LD_LIBRARY_PATH": str(base / "local-root/usr/lib/llvm-18/lib")}
script = Path(__file__).with_name("check_app_clang.py")
completed = subprocess.run([sys.executable, str(script), "--repo", "/workspace/scratch/308e2340bae7/chatadhd",
    "--compile-commands", "/workspace/scratch/308e2340bae7/chatadhd/loom/build/dev/compile_commands.json",
    "--clang", str(base / "local-root/usr/lib/llvm-18/bin/clang++"), "--out", options.out], env=environment)
sys.exit(completed.returncode)
