#!/usr/bin/env python3
"""Synthetic W5 checkpoint replay probe; builds changed sources over an existing base static library."""
import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else pathlib.Path('/workspace/scratch/2fbae43b23fa/chatadhd')
BASE = pathlib.Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else ROOT / 'loom/build/dev'
HERE = pathlib.Path(__file__).resolve().parent
RECEIPT = 'c7972252a23cb13c54797f6b57df24de903c5296'
TREE = HERE / 'source'
TREE.mkdir(exist_ok=True)
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])
paths = git('ls-tree', '-r', '--name-only', RECEIPT, 'loom/include', 'loom/src').decode().splitlines()
hashes = {}
for path in paths:
    content = git('show', RECEIPT + ':' + path)
    target = TREE / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    hashes[path] = hashlib.sha256(content).hexdigest()
sources = sorted((TREE / 'loom/src/import').glob('*.cpp'))
sources += [TREE / 'loom/src/db/db.cpp', TREE / 'loom/src/db/annotations.cpp']
include = ['-I' + str(TREE / 'loom/include'), '-I' + str(TREE / 'loom/src')]
for third_party in ('nlohmann', 'miniz', 'sqlite', 'cpp-httplib'):
    include += ['-isystem', str(ROOT / 'loom/third_party' / third_party)]
flags = ['-std=c++20', '-O0', '-g0', '-pthread', '-DLOOM_HAVE_OPENSSL=1', '-DCPPHTTPLIB_OPENSSL_SUPPORT=1', '-DJSON_USE_IMPLICIT_CONVERSIONS=1'] + include
objects = HERE / 'objects'
objects.mkdir(exist_ok=True)
def compile_one(source):
    output = objects / (source.name + '.o')
    subprocess.run(['c++', *flags, '-c', str(source), '-o', str(output)], check=True)
    return output
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    compiled = list(pool.map(compile_one, sources))
for stem, run_dir in [('probe', 'run'), ('probe_link_failure', 'run-link-failure')]:
    binary = HERE / stem
    subprocess.run(['c++', *flags, str(HERE / (stem + '.cpp')), *map(str, compiled), str(BASE / 'libloom_core.a'),
        str(BASE / 'libloom_sqlite3_amalgamation.a'), str(BASE / 'libloom_miniz.a'), '-ldl', '-lm', '-lssl', '-lcrypto',
        '-Wl,--no-keep-memory', '-Wl,--reduce-memory-overheads', '-o', str(binary)], check=True)
    if (HERE / run_dir).exists():
        raise RuntimeError('use a fresh copy of the runner directory; replay receipts must not be overwritten')
    subprocess.run([str(binary), str(HERE / run_dir)], check=True)
manifest = {'reviewed_commit': RECEIPT, 'w5_source_hashes': hashes, 'overlay_sources': [str(p.relative_to(TREE)) for p in sources],
    'base_libraries': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (BASE / 'libloom_core.a', BASE / 'libloom_sqlite3_amalgamation.a', BASE / 'libloom_miniz.a')},
    'evidence': {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (
        HERE / 'probe.cpp', HERE / 'probe_link_failure.cpp', HERE / 'reproduce.py',
        HERE / 'run/source.zip', HERE / 'run/results.json', HERE / 'run-link-failure/source.zip', HERE / 'run-link-failure/results.json')}}
(HERE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for run_dir in ('run', 'run-link-failure'):
    result = json.loads((HERE / run_dir / 'results.json').read_text())
    print(json.dumps({'scenario': run_dir, 'first_partial': result['first']['export_report']['partial'],
        'second_partial': result['second']['export_report']['partial'], 'third_cached': result['third']['already_imported'],
        'counts': result['counts'], 'final_source_status': result['final_source_metadata']['import_status']}))
