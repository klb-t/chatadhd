#!/usr/bin/env python3
"""Independent exact two-scenario replay against the actual completed W5 archive."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SCRIPT_ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True, help='public clone containing the reviewed Git receipt')
parser.add_argument('--build-dir', type=Path, required=True, help='completed native build with static libraries and CMakeCache.txt')
parser.add_argument('--out-dir', type=Path, required=True, help='new external output directory; must not already exist')
parser.add_argument('--original-dir', type=Path, default=SCRIPT_ROOT / 'original', help='packed original probes; default: beside this script')
parser.add_argument('--source-commit', default='03cd52e33e5902ffb90d33ec0084cea2bf60feaa', help='Git receipt to check against the actual CMake source tree')
parser.add_argument('--expected-core-sha256', help='optional exact original-binary binding; a fresh environment can legitimately have another archive hash')
args = parser.parse_args()
REPO = args.repo.resolve()
ORIGINAL = args.original_dir.resolve()
BUILD = args.build_dir.resolve()
HERE = args.out_dir.resolve()
RECEIPT = args.source_commit
if HERE.exists():
    parser.error('--out-dir must be a fresh directory; preserve prior receipts')
HERE.mkdir(parents=True)
(HERE / 'replay-used.py').write_bytes(Path(__file__).read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    cache = (BUILD / 'CMakeCache.txt').read_text()
    source = next(Path(line.split('=', 1)[1]).parent for line in cache.splitlines()
                  if line.startswith('CMAKE_HOME_DIRECTORY:'))
    listed = subprocess.check_output(['git', '-C', str(REPO), 'ls-tree', '-r', '-z', RECEIPT,
                                     'loom/include', 'loom/src']).split(b'\0')
    files = {}
    mismatches = []
    for entry in listed:
        if not entry:
            continue
        info, raw_name = entry.split(b'\t', 1)
        name = raw_name.decode()
        expected = info.split()[2].decode()
        content = (source / name).read_bytes()
        git_hash = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
        files[name] = {'git_blob': git_hash, 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
        if git_hash != expected:
            mismatches.append(name)
    if mismatches:
        raise RuntimeError('source mismatch against reviewed commit: ' + repr(mismatches))
    libraries = {name: {'bytes': (BUILD / name).stat().st_size, 'sha256': sha(BUILD / name)}
                 for name in ('libloom_core.a', 'libloom_sqlite3_amalgamation.a', 'libloom_miniz.a')}
    return {'source_root': str(source), 'files': files, 'libraries': libraries,
            'cmake_cache_sha256': sha(BUILD / 'CMakeCache.txt')}

def require(value, name):
    if not value:
        raise AssertionError(name)

def run_measured(command, logfile):
    begin = time.monotonic()
    with logfile.open('w') as log:
        process = subprocess.Popen(command, stdout=log, stderr=log)
        _, status, usage = os.wait4(process.pid, 0)
        process.returncode = os.waitstatus_to_exitcode(status)
    measurement = {'command': command, 'seconds': time.monotonic() - begin,
                   'exit_code': process.returncode, 'process_cpu_seconds': usage.ru_utime + usage.ru_stime,
                   'peak_child_rss_kib': usage.ru_maxrss, 'log': str(logfile.relative_to(HERE))}
    commands.append(measurement)
    if process.returncode:
        raise RuntimeError('child failed: ' + repr(measurement))
    return measurement

before = snapshot()
if args.expected_core_sha256:
    require(before['libraries']['libloom_core.a']['sha256'] == args.expected_core_sha256,
            'caller-bound actual measured W5 core')
(HERE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
source = Path(before['source_root'])
flags = ['-std=c++20', '-O0', '-g0', '-pthread', '-DLOOM_HAVE_OPENSSL=1',
         '-DCPPHTTPLIB_OPENSSL_SUPPORT=1', '-DJSON_USE_IMPLICIT_CONVERSIONS=1',
         '-I' + str(source / 'loom/include'), '-I' + str(source / 'loom/src')]
for name in ('nlohmann', 'miniz', 'sqlite', 'cpp-httplib'):
    flags += ['-isystem', str(source / 'loom/third_party' / name)]
commands = []
results = {}
for stem, malformed in [('probe', True), ('probe_link_failure', False)]:
    original = (ORIGINAL / (stem + '.cpp')).read_bytes()
    originals = HERE / 'original'
    originals.mkdir(exist_ok=True)
    (originals / (stem + '.cpp')).write_bytes(original)
    old = b'  ImportOptions options;\n'
    new = old + b'  options.resume = true;\n'
    require(original.count(old) == 1, 'one explicit compatibility adaptation')
    adapted = original.replace(old, new)
    require(adapted.replace(new, old) == original, 'only adaptation is resume=true')
    cpp = HERE / (stem + '.cpp')
    cpp.write_bytes(adapted)
    binary = HERE / stem
    command = ['c++', *flags, str(cpp), str(BUILD / 'libloom_core.a'),
               str(BUILD / 'libloom_sqlite3_amalgamation.a'), str(BUILD / 'libloom_miniz.a'),
               '-ldl', '-lm', '-lssl', '-lcrypto', '-Wl,--no-keep-memory',
               '-Wl,--reduce-memory-overheads', '-o', str(binary)]
    run_measured(command, HERE / (stem + '-compile.txt'))
    run_dir = HERE / (stem + '-data')
    if run_dir.exists():
        raise RuntimeError('fresh replay output required')
    run_measured([str(binary), str(run_dir)], HERE / (stem + '-run.txt'))
    data = json.loads((run_dir / 'results.json').read_text())
    first, second, third = [data[k] for k in ('first', 'second', 'third')]
    checks = {}
    checks['first_partial'] = first['export_report']['partial'] is True
    checks['first_has_errors'] = bool(first['export_report']['errors'])
    checks['source_ids_preserved'] = first['source_id'] == second['source_id'] == third['source_id']
    checks['conversation_ids_preserved'] = first['conversations'][0]['id'] == second['conversations'][0]['id'] == third['conversations'][0]['id']
    checks['second_resumed'] = second['resumed'] is True
    checks['one_raw_node_retained'] = data['counts']['unknown_member_nodes'] == 1
    checks['phase_checkpoint_separate'] = data['project_checkpoint'] is None if malformed else data['project_checkpoint']['kind'] == 'member'
    if malformed:
        checks['all_attempts_partial'] = all(d['export_report']['partial'] is True for d in (first, second, third))
        checks['all_attempts_have_errors'] = all(bool(d['export_report']['errors']) for d in (first, second, third))
        checks['no_completed_cache_hit'] = all(d['already_imported'] is False for d in (first, second, third))
        checks['no_project_nodes'] = data['counts']['project_nodes'] == 0
        checks['source_not_complete'] = data['final_source_metadata']['import_status'] == 'partial'
    else:
        checks['second_complete'] = second['export_report']['partial'] is False and not second['export_report']['errors']
        checks['third_complete_cache_hit'] = third['already_imported'] is True and third['export_report']['partial'] is False
        checks['project_restored'] = data['counts']['project_nodes'] == 1
        checks['source_complete'] = data['final_source_metadata']['import_status'] == 'complete'
    import sqlite3
    with sqlite3.connect((run_dir / 'probe.db').as_uri() + '?mode=ro', uri=True) as db:
        checks['database_integrity'] = db.execute('PRAGMA quick_check').fetchone()[0] == 'ok' and db.execute('PRAGMA foreign_key_check').fetchall() == []
        project_documents = db.execute("SELECT COUNT(*) FROM nodes WHERE kind='export:project_doc'").fetchone()[0]
        links = db.execute("SELECT COUNT(*) FROM links l JOIN nodes d ON d.id=l.src JOIN nodes p ON p.id=l.dst WHERE l.link_type='part_of' AND d.kind='export:project_doc' AND p.kind='export:project'").fetchone()[0]
        checks['document_count'] = project_documents == (0 if malformed else 1)
        checks['link_count'] = links == (0 if malformed else 1)
    for label, value in checks.items():
        require(value, stem + ': ' + label)
    results[stem] = {'checks': checks, 'passed': len(checks), 'original_sha256': hashlib.sha256(original).hexdigest(),
                     'adapted_sha256': sha(cpp), 'binary_sha256': sha(binary),
                     'source_zip_sha256': sha(run_dir / 'source.zip'), 'result_sha256': sha(run_dir / 'results.json')}
after = snapshot()
require(before == after, 'actual sources and libraries stable across independent replay')
(HERE / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt = {'reviewed_commit': RECEIPT, 'actual_core_sha256': before['libraries']['libloom_core.a']['sha256'],
           'provider_calls': 0, 'source_files_compared': len(before['files']), 'sources_libraries_stable': before == after,
           'adaptation': 'Exactly one added options.resume = true line in each original negative-case probe.',
           'production_translation_units_compiled': 0, 'commands': commands, 'results': results,
           'cases_passed': len(results), 'checks_passed': sum(r['passed'] for r in results.values())}
(HERE / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'cases_passed': receipt['cases_passed'], 'checks_passed': receipt['checks_passed'],
                  'actual_core_sha256': receipt['actual_core_sha256'], 'source_stable': before == after}, indent=2))
