#!/usr/bin/env python3
"""Offline W2+W4 unresolved-usage replay probe, outside the repository.

Usage: python packet_replay_repro.py /absolute/path/to/libloom.so
       python packet_replay_repro.py /absolute/path/to/libloom.so --expect fixed

Only synthetic stateless `capabilities` calls. A fresh temporary database is
deleted afterward. No provider, network or repository mutation occurs.
"""
import argparse
import ctypes
import json
import sqlite3
import tempfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("library", type=Path)
    parser.add_argument("--expect", choices=("bug", "fixed"), default="bug")
    args = parser.parse_args()
    lib = ctypes.CDLL(str(args.library.resolve()))
    lib.loom_init_ex.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.loom_init_ex.restype = ctypes.c_void_p
    lib.loom_shutdown.argtypes = [ctypes.c_void_p]
    lib.loom_packet.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.loom_packet.restype = ctypes.c_void_p
    lib.loom_free_string.argtypes = [ctypes.c_void_p]

    def take(pointer):
        assert pointer, "C ABI returned a null pointer"
        try:
            return json.loads(ctypes.string_at(pointer))
        finally:
            lib.loom_free_string(pointer)

    with tempfile.TemporaryDirectory(prefix="packet-unresolved-replay-") as tmp:
        error = ctypes.c_void_p()
        context = lib.loom_init_ex(
            json.dumps({"data_dir": tmp, "start_workers": False}).encode(),
            ctypes.byref(error),
        )
        if not context:
            raise AssertionError(take(error.value) if error.value else "runtime initialization failed")
        try:
            command = {
                "operation": "capabilities",
                "usage_estimate": {
                    "operation_id": "synthetic-unresolved-replay",
                    "baseline_key": "synthetic-packet-capabilities",
                    "resources": {"calls": 1, "gpu_seconds": None},
                },
            }
            encoded = json.dumps(command).encode()
            first = take(lib.loom_packet(context, encoded))
            second = take(lib.loom_packet(context, encoded))
            ledger = Path(tmp) / "usage-policy.sqlite"
            with sqlite3.connect(f"file:{ledger}?mode=ro", uri=True) as connection:
                samples = connection.execute(
                    "SELECT resource,value FROM usage_samples WHERE operation_id=? ORDER BY resource",
                    (command["usage_estimate"]["operation_id"],),
                ).fetchall()
                record = json.loads(connection.execute(
                    "SELECT record FROM usage_operations WHERE id=?",
                    (command["usage_estimate"]["operation_id"],),
                ).fetchone()[0])
            observed = {
                "first_executed": first.get("executed"),
                "first_settlement_status": first.get("usage_settlement", {}).get("status"),
                "second_executed": second.get("executed"),
                "second_settlement_status": second.get("usage_settlement", {}).get("status"),
                "second_error": second.get("error"),
                "calls_samples": [value for resource, value in samples if resource == "calls"],
                "ledger_status": record["status"],
                "ledger_actual_calls": record["actual"]["calls"]["value"],
                "ledger_remaining": record["remaining"],
            }
            print(json.dumps(observed, indent=2, sort_keys=True))
            assert first.get("executed") is True, first
            assert first["usage_settlement"]["status"] == "unresolved", first
            assert observed["calls_samples"] == [1.0], observed
            assert observed["ledger_actual_calls"] == 1, observed
            if args.expect == "bug":
                assert second.get("executed") is True, second
                assert second["usage_settlement"]["status"] == "unresolved", second
                print("REPRODUCED: two executed packet calls, one immutable calls=1 measurement")
            else:
                assert second.get("executed") is not True, second
                assert second.get("executed") is False or "error" in second, second
                print("FIX VERIFIED: unresolved accounting does not authorize a second execution")
        finally:
            lib.loom_shutdown(context)


if __name__ == "__main__":
    main()
