# Independent negative: screenshot MIME lost by immutable-source routing

Reviewed commit: `03cd52e33e5902ffb90d33ec0084cea2bf60feaa`.
Actual W5 static library SHA256: `f2002cbe0a527039bf9b1c03753c4707f5a85d0667da70b2cee805233f83a9c0`.
All 211 tracked source/header files match the commit by Git blob hash before/after; all three libraries remain identical. No production translation unit was compiled.

Three scenarios used the same synthetic 1x1 PNG and real production importer/OCR provider code, with `net::ScriptedTransport` replacing all HTTP transport. No live provider/network/paid call. The string `SYNTHETIC_ONLY_NOT_A_REAL_KEY` is an obvious dummy, set in memory and never saved as a secrets file.

| Scenario | Expected PNG MIME | Actual data URI |
|---|---|---|
| No provenance `import_file`, control | preserved | `data:image/png;base64,...` |
| Provenance `import_file` | lost | `data:image/;base64,...` |
| Provenance direct `import_screenshot` | lost | `data:image/;base64,...` |

**MIME preservation: 1/3; two reproduced negative routes.** The mock returns a fixed OCR success without validating MIME; import success in the receipt does not prove a real service accepts the malformed request. **11/11 diagnostic checks** establish the reproduction and identical PNG bytes; they are not 11 acceptance checks. Complete encoded outbound request bodies are in `data/results.json` and `run.txt`.

Static causal chain, exact reviewed source:
- `loom/src/import/importer_core.cpp:354–364` and `493–514` route non-SQLite reads to the immutable blob.
- `loom/src/core/provenance.cpp:66–70` names that blob solely with its hash, without extension.
- `loom/src/import/importer_text.cpp:336–342` passes the resulting path to `MediaProviders::ocr`.
- `loom/src/media/media_providers.cpp:392–402` dispatches the path; `280–283` reads bytes and derives format from `lower_ext(image_path)`; `23–28` derives only `path.extension()`.
- `media_providers.cpp:211–213` formats the outgoing data URI from that empty format. No fallback uses SourceCtx original filename, BlobStore MIME or content signature.

To thread 5: preserve original declared image format separately while reading the immutable bytes. Do not revert to a mutable original file solely to recover its extension. Add offline provenance-enabled screenshot regressions for both outer `import_file` and direct `import_screenshot`; a strict mock should verify request MIME. Additional image extensions should also retain format.

Resource receipt: probe compile/link 6.408 s, 343040 KiB peak; run 0.025 s, 12880 KiB. Only one tiny probe compiled/linked against existing actual build; no production source overlays. This is not an import memory benchmark.

`replay-executed.py` is exactly the executed host-path runner. Portable `replay.py` exposes repo/build/output arguments and does not enforce the old host's library hash unless requested. It verifies CMake's actual source/header tree against the selected public commit and hashes all libraries before/after. A fresh completed build must independently bind objects to those sources; mismatching source bytes stop replay. The portable variant received syntax/help checks only; it was not counted as another execution.

```sh
python3 replay.py --repo /path/to/public/chatadhd --build-dir /path/to/completed/W5-build --out-dir /path/to/new-output --source-commit 03cd52e33e5902ffb90d33ec0084cea2bf60feaa
```

No production objects, compiled binary or database is included. SHA256.json binds all packaged members. The positive two-scenario checkpoint replay remains a separate immutable package.

The seven complete, unmodified causal production source/header files are retained under `production-source/loom/`, with exact Git blob/SHA256 binding in `production-source/SOURCE_BINDINGS.json`. They are diagnostic snapshots, not an implementation patch.
