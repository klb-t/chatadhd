#!/usr/bin/env python3
"""Independent exact two-scenario replay against the actual completed W5 archive."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2fbae43b23fa/chatadhd')
ORIGINAL = Path('/workspace/scratch/2fbae43b23fa/review-w5-checkpoint')
BUILD = Path('/dev/shm/chatadhd-thread5/baseline-build')
RECEIPT = '03cd52e33e5902ffb90d33ec0084cea2bf60feaa'

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()

def snapshot():
    cache = (BUILD / 'CMakeCache.txt').read_text()
    source = next(Path(line.split('=', 1)[1]).parent for line in cache.splitlines()
                  if line.startswith('CMAKE_HOME_DIRECTORY:'))
    listed = subprocess.check_output(['git', '-C', str(REPO), 'ls-tree', '-r', '-z', RECEIPT,
                                     'loom/include', 'loom/src']).split(b'\0')
    files = {}
    mismatches = []
    for entry in listed:
        if not entry:
            continue
        info, raw_name = entry.split(b'\t', 1)
        name = raw_name.decode()
        expected = info.split()[2].decode()
        content = (source / name).read_bytes()
        git_hash = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
        files[name] = {'git_blob': git_hash, 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
        if git_hash != expected:
            mismatches.append(name)
    if mismatches:
        raise RuntimeError('source mismatch against reviewed commit: ' + repr(mismatches))
    libraries = {name: {'bytes': (BUILD / name).stat().st_size, 'sha256': sha(BUILD / name)}
                 for name in ('libloom_core.a', 'libloom_sqlite3_amalgamation.a', 'libloom_miniz.a')}
    return {'source_root': str(source), 'files': files, 'libraries': libraries,
            'cmake_cache_sha256': sha(BUILD / 'CMakeCache.txt')}

def require(value, name):
    if not value:
        raise AssertionError(name)

def run_measured(command, logfile):
    begin = time.monotonic()
    with logfile.open('w') as log:
        process = subprocess.Popen(command, stdout=log, stderr=log)
        _, status, usage = os.wait4(process.pid, 0)
        process.returncode = os.waitstatus_to_exitcode(status)
    measurement = {'command': command, 'seconds': time.monotonic() - begin,
                   'exit_code': process.returncode, 'process_cpu_seconds': usage.ru_utime + usage.ru_stime,
                   'peak_child_rss_kib': usage.ru_maxrss, 'log': str(logfile.relative_to(HERE))}
    commands.append(measurement)
    if process.returncode:
        raise RuntimeError('child failed: ' + repr(measurement))
    return measurement

before = snapshot()
require(before['libraries']['libloom_core.a']['sha256'] == 'f2002cbe0a527039bf9b1c03753c4707f5a85d0667da70b2cee805233f83a9c0', 'actual W5 library identity')
(HERE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
source = Path(before['source_root'])
commands = []
flags = ['-std=c++20', '-O0', '-g0', '-pthread', '-DLOOM_HAVE_OPENSSL=1', '-DCPPHTTPLIB_OPENSSL_SUPPORT=1', '-DJSON_USE_IMPLICIT_CONVERSIONS=1', '-I' + str(source / 'loom/include'), '-I' + str(source / 'loom/src')]
for name in ('nlohmann', 'miniz', 'sqlite', 'cpp-httplib'):
    flags += ['-isystem', str(source / 'loom/third_party' / name)]
binary = HERE / 'probe'
command = ['c++', *flags, str(HERE / 'probe.cpp'), str(BUILD / 'libloom_core.a'), str(BUILD / 'libloom_sqlite3_amalgamation.a'), str(BUILD / 'libloom_miniz.a'), '-ldl', '-lm', '-lssl', '-lcrypto', '-Wl,--no-keep-memory', '-Wl,--reduce-memory-overheads', '-o', str(binary)]
run_measured(command, HERE / 'compile.txt')
run_measured([str(binary), str(HERE / 'data'), str(HERE / 'synthetic.png')], HERE / 'run.txt')
data = json.loads((HERE / 'data/results.json').read_text())
checks = {}
for index, scenario in enumerate(data):
    prefix = scenario['scenario'] + ':'
    checks[prefix + 'mock_one_request'] = scenario['mock_requests'] == 1
    checks[prefix + 'mock_import_succeeded'] = scenario['import_succeeded_against_nonvalidating_mock'] is True
    checks[prefix + 'uri_diagnostic_matches_static_proof'] = scenario['expected_png_uri_present'] is (index == 0) and scenario['empty_format_uri_present'] is (index != 0)
    if index:
        checks[prefix + 'extensionless_blob_retains_same_bytes'] = scenario['blob_extension'] == '' and scenario['blob_bytes_match_source'] is True
for label, value in checks.items():
    require(value, label)
after = snapshot()
require(before == after, 'actual sources and libraries remain stable')
(HERE / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt = {'reviewed_commit': RECEIPT, 'source_files_compared': len(before['files']), 'actual_core_sha256': before['libraries']['libloom_core.a']['sha256'], 'live_provider_calls': 0, 'production_translation_units_compiled': 0, 'source_libraries_stable': True, 'commands': commands, 'diagnostic_checks': checks, 'diagnostic_checks_passed': len(checks), 'mime_preservation_checks': {'passed': 1, 'total': 3, 'negative_routes': 2}, 'probe_sha256': sha(HERE / 'probe.cpp'), 'binary_sha256': sha(binary), 'synthetic_png_sha256': sha(HERE / 'synthetic.png'), 'result_sha256': sha(HERE / 'data/results.json')}
(HERE / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
