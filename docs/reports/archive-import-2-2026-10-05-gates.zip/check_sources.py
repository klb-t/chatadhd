#!/usr/bin/env python3
import hashlib,json,pathlib,sys
proof=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path(sys.argv[1]).resolve()
record=json.loads((proof/'source-sha256-final.json').read_text())
errors=[]
for name,expected in record['files'].items():
 path=repo/name
 if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:errors.append(name)
if errors:raise SystemExit('source differs from frozen156a820: '+', '.join(errors))
print('matched '+str(len(record['files']))+' frozen code/data/test files')
