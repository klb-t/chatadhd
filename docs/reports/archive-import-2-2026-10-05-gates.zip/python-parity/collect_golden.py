#!/usr/bin/env python3
"""Collect complete default/explicit audit outputs on a public synthetic fixture."""
import argparse
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import tempfile


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--module', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    spec = importlib.util.spec_from_file_location('measured_archive_cost', args.module.resolve())
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory() as directory:
        db = Path(directory) / 'synthetic.db'
        with sqlite3.connect(db) as con:
            con.execute('CREATE TABLE messages(id TEXT,conv_id TEXT,role TEXT,text TEXT,status TEXT)')
            con.executemany('INSERT INTO messages VALUES(?,?,?,?,?)', [
                ('m1','c1','user','a'*1200,'active'),
                ('m2','c1','assistant','b'*2400,'active'),
                ('m3','c1','user','c'*600,'version'),
                ('m4','c2','user','d'*1200,'active'),
                ('m5','c2','assistant','e'*999,'excluded'),
                ('m6','c2','assistant','f'*5000,'deleted'),
                ('m7','c3','user','ą\x00🙂','active'),
                ('m8','c3','tool','tools','excluded'),
                ('m9','c3','assistant','saved','version'),
                ('m10','c4','user','gone','deleted'),
                ('m11','c5','function','call','active'),
                ('m12','c6',None,'future','new'),
                ('m13','c7',None,None,None),
            ])
        stats = module.archive_stats(db)
        pricing = json.loads(module.PRICING.read_text())
        result = {
            'archive_stats_default': stats,
            'project_stats_default': module.project_stats(stats),
            'estimate_default_no_pricing': module.estimate(stats),
            'estimate_default_historical_pricing': module.estimate(stats, pricing),
            'estimate_explicit': module.estimate(stats, pricing, fraction=.5, include_versions=False),
        }
        scenarios = {
            'cli_default_text': [],
            'cli_default_json': ['--json'],
            'cli_legacy': ['--scope','legacy','--json'],
            'cli_active': ['--scope','active','--json'],
            'cli_explicit': ['--scope','active','--no-tools','--input-price','2','--output-price','10',
                             '--chars-per-token-low','5','--chars-per-token-high','2','--prefix-tokens','4','--json'],
            'cli_explicit_prefix': ['--input-price','2','--output-price','10','--prefix-price','.2',
                                    '--prefix-tokens','4','--fraction','.5','--json'],
            'cli_historical_pricing': ['--pricing',str(module.PRICING),'--json'],
            'cli_status_overrides': ['--scope','all','--no-versions','--no-unknown-status',
                                     '--no-include-excluded','--no-include-deleted','--json'],
        }
        for name, flags in scenarios.items():
            with contextlib.redirect_stdout(io.StringIO()) as capture:
                code = module.main(['--db',str(db),*flags])
            result[name] = {'exit_code': code, 'stdout': capture.getvalue()}
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print('golden scenarios:', len(result))


if __name__ == '__main__':
    main()
