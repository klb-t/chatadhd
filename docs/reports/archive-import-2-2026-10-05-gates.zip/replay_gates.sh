#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd -- "$1" && pwd)"
proof_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
build_dir="$2"
result_dir="$3"
mkdir -p -- "$result_dir/tmp"
export TMPDIR="$result_dir/tmp"
python3 "$proof_dir/check_sources.py" "$repo_root"
cmake --fresh -S "$repo_root/loom" -B "$build_dir" -G Ninja \
  -DCMAKE_MAKE_PROGRAM="$(command -v ninja)" -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_FLAGS_RELEASE='-O0 -DNDEBUG' -DCMAKE_CXX_FLAGS_RELEASE='-O0 -DNDEBUG' \
  -DLOOM_WERROR=ON -DLOOM_USE_SYSTEM_SQLITE=OFF -DLOOM_BUILD_TESTS=ON \
  -DLOOM_BUILD_CLI=ON -DLOOM_BUILD_SERVER=ON -DLOOM_SHARED=ON \
  > "$result_dir/configure.txt" 2>&1
cmake --build "$build_dir" --parallel 2 > "$result_dir/build.txt" 2>&1
ctest --test-dir "$build_dir" --show-only=json-v1 > "$result_dir/manifest.json"
ctest --test-dir "$build_dir" -j 2 --output-on-failure --no-tests=error \
  --test-output-size-passed 10485760 --test-output-size-failed 10485760 \
  --output-junit "$result_dir/junit.xml" > "$result_dir/ctest.txt" 2>&1
python3 "$proof_dir/guard/.github/scripts/verify_ctest.py" --preset vendored \
  --policy "$proof_dir/guard/.github/ctest-evidence-policy.json" \
  --manifest "$result_dir/manifest.json" --junit "$result_dir/junit.xml" \
  --output "$result_dir/executed-cases.json"
cd -- "$repo_root/loom/web"
npm ci --offline > "$result_dir/npm-ci.txt" 2>&1
npm run build > "$result_dir/web-build.txt" 2>&1
python3 "$proof_dir/check_sources.py" "$repo_root"
