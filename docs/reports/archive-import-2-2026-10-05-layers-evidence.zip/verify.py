#!/usr/bin/env python3
"""Replay exact isolated W12 DefaultLayers × W5 import preset inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--out-dir', type=Path, required=True)
parser.add_argument('--cxx', default='c++')
args = parser.parse_args()
evidence = Path(__file__).resolve().parent
repo = args.repo.resolve()
out = args.out_dir.resolve()
out.mkdir(parents=True, exist_ok=False)
observed = json.loads((evidence / 'dependencies-after.json').read_text())
for value in observed['entries'].values():
    if value['origin'] != 'root-public-156a820':
        continue
    path = repo / value['relative_path']
    if hashlib.sha256(path.read_bytes()).hexdigest() != value['sha256']:
        raise SystemExit('Repository header differs from measured input: ' + value['relative_path'])
root = evidence / 'root-inputs'
w12 = evidence / 'w12-source'
command = [args.cxx, '-std=c++20', '-O0', '-g0', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
           '-ffunction-sections', '-fdata-sections', '-pthread', '-DJSON_USE_IMPLICIT_CONVERSIONS=1',
           '-I' + str(w12 / 'loom/include'), '-I' + str(root / 'loom/include'), '-I' + str(repo / 'loom/include'),
           '-I' + str(root / 'loom/src'), '-I' + str(repo / 'loom/src'),
           '-isystem', str(repo / 'loom/third_party/nlohmann'), '-isystem', str(repo / 'loom/third_party/sqlite'),
           str(evidence / 'runner.cpp'), str(w12 / 'loom/src/onboarding/layers.cpp'),
           str(root / 'loom/src/import/import_preset.cpp'), str(root / 'loom/src/util/json.cpp'),
           str(root / 'loom/src/util/sha256.cpp'), str(root / 'loom/src/util/utf8.cpp'),
           str(root / 'loom/src/util/result.cpp'), '-Wl,--gc-sections', '-o', str(out / 'runner')]
commands = []
def run(argv, log):
    start = time.monotonic()
    with (out / log).open('w') as stream:
        child = subprocess.run(argv, stdout=stream, stderr=stream)
    commands.append({'argv': argv, 'exit_code': child.returncode, 'seconds': time.monotonic() - start, 'log': log})
    (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if child.returncode:
        raise SystemExit(child.returncode)
run(command, 'compile.txt')
run([str(out / 'runner'), str(root / 'loom/data/presets/import_layers.pack'),
     str(root / 'loom/data/presets/import_layers.spec.pack'), str(root / 'loom/data/presets/import.pack')], 'run.txt')
result = json.loads((out / 'run.txt').read_text())
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'passed': result['passed'], 'total': result['total']}, indent=2))
if result['status'] != 'passed' or not result['total']:
    raise SystemExit(1)
