# Independent W12 × W5 final preset-ID replay

**Before: 55/55 explicit controls at `86d9d046`. After: 55/55 at
`156a82080a7abb8a68d249747dfa167b3045effe`.** All **25/25 canonical entries** pass.
The same 10,234-byte runner is byte-identical (SHA-256
`3d6f78543cb7ae5d94c7540c873070081a5b74a994d8bfc27db68451b9e9c7c8`),
and the full result objects match. These are isolated runner controls, not
individual doctest cases or a full CTest result. Zero live/paid provider calls.

This fresh execution followed the R42 change allowing a nonempty data-defined
preset identity instead of a fixed name. Of twelve frozen W5 primary inputs,
only `import_preset.cpp` changed from the prior proof; default data, generated
resources and all other primary files are unchanged. Inputs are exact Git bytes
from the final commit, copied before compiling. The real W12 header and `layers.cpp`
remain pinned to `3c0bc36552ef9851f1174946cfb108549aae3228`.
All fourteen primary inputs match those published commits after execution.
Shared project headers are hashed before and after and match the published W5
revision. Observed working-tree HEAD is recorded separately, never used as the
identity of pinned inputs. Generator and Python behavior are outside this native proof.

The actual W12 DefaultLayers implementation and W5 complete-values decoder run
without stubs. Controls cover all values/types/source identities; complete native
decoding; disable/exclude suppressions; missing/null rejection; atomic failed
application without builtin resurrection; explained overrides; pack/entry revision
conflicts; exclusion surviving upgrades, removal and reappearance; proposals,
explicit acceptance/direct mode and reenable; and audit default suppression.

**Boundary: one matching standalone pack/state.** DefaultLayers pins one pack ID.
W12 must compose these stable entries into its authoritative existing pack or
provide the common composition API. This evidence does not claim production
onboarding installation, RuntimeProfile bridging, graph persistence or privacy
integration, and introduces no alternate persistent exclusion store.

The original proof directory and its `evidence.zip` were preserved unchanged.
`prior-proof-binding.json` and `prior-proof-preserved.json` distinguish both runs.
`receipt.json` records new measured commands, timings, binary/log hashes and scope;
`source-before.json` and `source-after.json` bind the exact source bytes.
The public archive contains source, manifests and logs, not binaries or databases.
The replay helper is AST checked only; this recorded execution used the separate
compile/run commands. Replay into a fresh output directory:

```sh
python3 verify.py --repo /path/to/chatadhd --out-dir /path/to/fresh-output
```
