#include <algorithm>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>

#include "loom/onboarding_layers.h"
#include "import/import_preset.h"

using namespace loom;
using loom::onboarding::DefaultLayers;

template<class T> T must(Result<T> value) {
  if (!value) throw std::runtime_error(value.error().to_string());
  return std::move(value).value();
}
Json read(const std::string& path) {
  std::ifstream input(path, std::ios::binary);
  if (!input) throw std::runtime_error("cannot read fixture: " + path);
  return Json::parse(std::string(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()));
}
Json projected_options(const ImportOptions& o) {
  return Json{{"stream_threshold_bytes", o.stream_threshold_bytes}, {"json_read_chunk_bytes", o.json_read_chunk_bytes},
    {"json_max_depth", o.json_max_depth}, {"json_inline_threshold_bytes", o.json_inline_threshold_bytes},
    {"generic_inference_max_bytes", o.generic_inference_max_bytes}};
}
Json resolved_values(const DefaultLayers& layers, const Json& spec, std::string_view resource) {
  Json out = Json::object();
  for (const auto& binding : spec.at("entries")) {
    if (binding.at("resource") != resource) continue;
    const auto found = must(layers.resolve(binding.at("key").get<std::string>()));
    if (found.at("status") == "effective") out[binding.at("field").get<std::string>()] = found.at("value");
  }
  return out;
}
int main(int argc, char** argv) {
  if (argc != 4) return 2;
  Json checks = Json::object();
  auto check = [&](std::string name, bool passed) { checks[name] = passed; };
  try {
    const auto pack = read(argv[1]);
    const auto spec = read(argv[2]);
    const auto import = read(argv[3]);
    auto base = must(DefaultLayers::create(pack));
    check("generated_pack_has_25_entries", pack.at("entries").size() == 25);
    check("shared_layer_catalog_preserves_all_25_identities", base.snapshot().at("catalog").size() == 25);
    for (const auto& entry : pack.at("entries")) {
      const auto key = entry.at("key").get<std::string>();
      const auto value = must(base.resolve(key));
      check("builtin_resolve:" + key, value.at("status") == "effective" && value.at("layer") == "builtin" &&
          value.at("value") == entry.at("value") && value.at("value").type() == entry.at("value").type() &&
          value.at("id") == entry.at("id") && value.at("source").at("pack_id") == pack.at("pack_id"));
    }
    const auto baseline = resolved_values(base, spec, "import");
    check("five_import_values_come_from_real_layer_resolver", baseline == import.at("values") && baseline.size() == 5);
    auto baseline_decoded = import_preset_from_values(baseline);
    check("native_complete_import_decoder_accepts_resolved_values", static_cast<bool>(baseline_decoded));
    ImportOptions options;
    check("native_aggregate_defaults_equal_canonical_source", projected_options(options) == baseline);

    const std::string key = "import.json_max_depth";
    auto disabled = must(DefaultLayers::create(pack, must(base.dispatch(Json{{"op","disable"},{"key",key}}))));
    const auto disabled_value = must(disabled.resolve(key));
    check("disabled_default_has_no_effective_value", disabled_value.at("status") == "disabled" && !disabled_value.contains("value"));
    const auto absent = resolved_values(disabled, spec, "import");
    auto missing = import_preset_from_values(absent);
    check("native_decoder_rejects_layer_suppressed_missing_field", !missing && missing.error().code == Errc::InvalidArgument);
    const auto options_before = projected_options(options);
    auto failed_apply = apply_import_preset_values(options, absent);
    check("native_failed_apply_is_atomic_no_builtin_resurrection", !failed_apply && projected_options(options) == options_before);
    auto null_values = baseline; null_values["json_max_depth"] = nullptr;
    auto null_result = import_preset_from_values(null_values);
    check("native_decoder_rejects_null_without_fallback", !null_result && null_result.error().code == Errc::InvalidArgument);
    check("immutable_original_still_effective_after_disable", must(base.resolve(key)).at("status") == "effective");

    auto overridden = must(DefaultLayers::create(pack, must(base.dispatch(Json{{"op","override"},{"key",key},{"value",17}}))));
    const auto override_value = must(overridden.resolve(key));
    check("user_override_is_effective_and_explained", override_value.at("status") == "effective" && override_value.at("layer") == "user" && override_value.at("value") == 17);
    auto override_decoded = must(import_preset_from_values(resolved_values(overridden, spec, "import")));
    check("native_decoder_consumes_actual_override", override_decoded.json_max_depth == 17);
    check("override_does_not_mutate_builtin_layer", must(base.resolve(key)).at("value") == baseline.at("json_max_depth"));

    auto excluded = must(DefaultLayers::create(pack, must(base.dispatch(Json{{"op","exclude"},{"key",key}}))));
    const auto excluded_value = must(excluded.resolve(key));
    check("excluded_default_has_no_effective_value", excluded_value.at("status") == "excluded" && !excluded_value.contains("value"));
    auto forbidden_override = excluded.dispatch(Json{{"op","override"},{"key",key},{"value",23}});
    check("override_cannot_silently_reenable_permanent_exclusion", !forbidden_override && forbidden_override.error().code == Errc::Conflict);
    auto excluded_decoded = import_preset_from_values(resolved_values(excluded, spec, "import"));
    check("native_decoder_rejects_excluded_required_field", !excluded_decoded);

    Json changed = pack;
    for (auto& entry : changed["entries"]) if (entry["key"] == key) entry["value"] = 513;
    auto same_revision = excluded.update_pack(changed);
    check("changed_pack_without_revision_bump_conflicts", !same_revision && same_revision.error().code == Errc::Conflict);
    changed["revision"] = pack.at("revision").get<std::uint64_t>() + 1;
    auto unchanged_entry_revision = excluded.update_pack(changed);
    check("changed_entry_without_revision_bump_conflicts", !unchanged_entry_revision && unchanged_entry_revision.error().code == Errc::Conflict);
    for (auto& entry : changed["entries"]) if (entry["key"] == key) entry["revision"] = entry["revision"].get<std::uint64_t>() + 1;
    changed["entries"].push_back(Json{{"id","offline.new.import.setting"},{"key","import.offline_new"},{"area","import.execution"},{"revision",1},{"value",29}});
    auto updated = must(DefaultLayers::create(changed, must(excluded.update_pack(changed))));
    const auto old_effective = must(updated.resolve(key));
    const auto new_effective = must(updated.resolve("import.offline_new"));
    check("original_identity_exclusion_survives_changed_default_revision", old_effective.at("status") == "excluded" && !old_effective.contains("value"));
    check("new_default_in_excluded_area_is_proposal_without_value", new_effective.at("status") == "proposal" && !new_effective.contains("value"));
    check("default_area_policy_came_from_data", updated.snapshot().at("areas").at("import.execution").at("new_defaults_mode") == pack.at("policy").at("excluded_area_new_defaults"));
    auto accepted = must(DefaultLayers::create(changed, must(updated.dispatch(Json{{"op","accept_proposal"},{"key","import.offline_new"}}))));
    check("explicit_acceptance_makes_new_identity_effective", must(accepted.resolve("import.offline_new")).at("value") == 29);
    check("acceptance_of_new_identity_does_not_clear_original_exclusion", must(accepted.resolve(key)).at("status") == "excluded");
    auto direct = must(DefaultLayers::create(changed, must(updated.dispatch(Json{{"op","set_area_mode"},{"area","import.execution"},{"mode","direct"}}))));
    check("explicit_direct_mode_activates_new_default", must(direct.resolve("import.offline_new")).at("status") == "effective");
    check("direct_mode_never_resurrects_excluded_identity", must(direct.resolve(key)).at("status") == "excluded");

    Json removed = changed;
    Json surviving = Json::array();
    for (const auto& entry : removed["entries"]) if (entry["key"] != key) surviving.push_back(entry);
    removed["entries"] = surviving; removed["revision"] = 3;
    auto after_remove = must(DefaultLayers::create(removed, must(updated.update_pack(removed))));
    check("excluded_identity_survives_pack_disappearance", must(after_remove.resolve(key)).at("status") == "excluded");
    Json restored = changed; restored["revision"] = 4;
    auto after_restore = must(DefaultLayers::create(restored, must(after_remove.update_pack(restored))));
    check("excluded_identity_survives_pack_reappearance", must(after_restore.resolve(key)).at("status") == "excluded");
    auto reopened = must(DefaultLayers::create(restored, must(after_restore.dispatch(Json{{"op","reenable"},{"key",key}}))));
    check("explicit_reenable_restores_new_default", must(reopened.resolve(key)).at("status") == "effective" && must(reopened.resolve(key)).at("value") == 513);
    check("native_decoder_accepts_explicit_reenabled_complete_values", static_cast<bool>(import_preset_from_values(resolved_values(reopened, spec, "import"))));
    auto audit_disabled = must(DefaultLayers::create(pack, must(base.dispatch(Json{{"op","disable"},{"key","import.audit.sqlite_cache_kib"}}))));
    const auto audit_value = must(audit_disabled.resolve("import.audit.sqlite_cache_kib"));
    check("same_common_layer_resolver_suppresses_audit_defaults", audit_value.at("status") == "disabled" && !audit_value.contains("value"));

    std::size_t passed = 0;
    for (const auto& entry : checks.items()) if (entry.value() == true) ++passed;
    Json result{{"status", passed == checks.size() ? "passed" : "failed"}, {"checks",checks},
      {"passed",passed},{"total",checks.size()},{"data_entries",pack.at("entries").size()},
      {"live_provider_calls",0},{"runtime_profile_bridge_executed",false},{"graph_persistence_executed",false}};
    std::cout << result.dump(2) << '\n';
    return passed == checks.size() ? 0 : 1;
  } catch (const std::exception& e) {
    std::cout << Json{{"status","failed"},{"error",e.what()},{"checks",checks},{"live_provider_calls",0}}.dump(2) << '\n';
    return 1;
  }
}
