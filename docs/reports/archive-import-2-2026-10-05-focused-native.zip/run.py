#!/usr/bin/env python3
import hashlib
import json
import os
import pathlib
import re
import shlex
import subprocess

ROOT = pathlib.Path('/workspace/scratch/943af489e102/chatadhd')
BUILD = pathlib.Path('/workspace/scratch/943af489e102/archive-import-2-build-after')
OUT = pathlib.Path('/dev/shm/archive-import-2-focused-native')

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
source_paths = ['loom/src', 'loom/include', 'loom/CMakeLists.txt', 'loom/CMakePresets.json',
                'loom/data/presets', 'loom/data/policy/usage_policy.pack', 'loom/tests/main.cpp',
                'loom/tests/test_import_presets.cpp', 'loom/tests/test_import_presets_binding.cpp',
                'loom/tests/test_import_audit_presets.cpp']
source_entries = subprocess.check_output(['git', 'ls-tree', '-r', '-z', head, '--', *source_paths], cwd=ROOT)
source_hashes = {}
for entry in source_entries.split(b'\0'):
    if not entry:
        continue
    metadata, path = entry.split(b'\t', 1)
    name = os.fsdecode(path)
    data = (ROOT / name).read_bytes()
    blob_hash = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert blob_hash == metadata.split()[2].decode(), name
    source_hashes[name] = hashlib.sha256(data).hexdigest()

names = ['main.cpp.o', 'test_import_presets.cpp.o', 'test_import_presets_binding.cpp.o',
         'test_import_audit_presets.cpp.o']
objects = [BUILD / 'CMakeFiles/loom_tests.dir/tests' / name for name in names]
graph = (BUILD / 'build.ninja').read_text().splitlines()
start = next(i for i, line in enumerate(graph) if line.startswith('build loom_tests:'))
fields = {}
for line in graph[start + 1:]:
    if not line.startswith('  '):
        break
    key, value = line.strip().split(' = ', 1)
    fields[key] = value
libraries = [str(BUILD / value) if value.startswith('libloom') else value
             for value in shlex.split(fields['LINK_LIBRARIES'])]
tracked_inputs = [*objects, BUILD / 'libloom_core.a', BUILD / 'libloom_sqlite3_amalgamation.a',
                  BUILD / 'libloom_miniz.a', pathlib.Path('/usr/lib/x86_64-linux-gnu/libssl.so'),
                  pathlib.Path('/usr/lib/x86_64-linux-gnu/libcrypto.so'), BUILD / 'build.ninja',
                  BUILD / 'CMakeCache.txt', BUILD / 'CMakeFiles/rules.ninja']
input_hashes = {str(path): sha(path) for path in tracked_inputs}
receipt = {'schema': 'loom.focused_fresh_native_tests/1', 'kind': 'existing freshly built test objects and real after-build libraries; no patch objects or source compilation',
           'source_commit': head, 'source_files_sha256': source_hashes,
           'source_files_match_commit': True, 'input_sha256': input_hashes,
           'ninja_flags': fields['FLAGS'], 'ninja_link_flags': fields['LINK_FLAGS'],
           'ninja_link_libraries': fields['LINK_LIBRARIES'],
           'deviations': ['Only the requested four existing objects are linked.',
                          'Linker dependency file and output are relocated to this scratch directory.',
                          '-pthread is explicit as requested; Ninja otherwise has the same libraries.',
                          'TMPDIR points to tmpfs because the overlay reported zero free space.'],
           'commands': []}

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def run(command, name, env=None):
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / (name + '.log')).write_bytes(result.stdout)
    receipt['commands'].append({'name': name, 'argv': command, 'exit_code': result.returncode})
    save()
    print(name, 'exit', result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode('utf-8', 'backslashreplace')[-10000:], flush=True)
        raise SystemExit(result.returncode)
    return result.stdout.decode('utf-8', 'backslashreplace')

binary = OUT / 'focused-native-tests'
run(['/usr/bin/c++', *shlex.split(fields['FLAGS']),
     '-Wl,--dependency-file=' + str(OUT / 'link.d'), *map(str, objects), '-o', str(binary),
     *libraries, '-pthread'], 'link')
receipt['binary'] = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary)}
temporary = OUT / 'tmp'
temporary.mkdir(exist_ok=True)
env = os.environ.copy()
env['TMPDIR'] = str(temporary)
receipt['test_environment'] = {'TMPDIR': str(temporary)}
text = run([str(binary), '--no-intro=true', '--success=true'], 'tests', env)
receipt['summary'] = '\n'.join(line for line in text.splitlines() if '[doctest]' in line)
cases = re.search(r'test cases:\s*(\d+)\s*\|\s*(\d+) passed\s*\|\s*(\d+) failed\s*\|\s*(\d+) skipped', text)
assert cases and list(map(int, cases.groups())) == [15, 15, 0, 0], receipt['summary']
assertions = re.search(r'assertions:\s*(\d+)\s*\|\s*(\d+) passed\s*\|\s*(\d+) failed', text)
assert assertions and assertions.group(1) == assertions.group(2) and assertions.group(3) == '0'
receipt['cases'] = {'executed': 15, 'passed': 15, 'failed': 0, 'skipped': 0,
                    'assertions': int(assertions.group(1))}
receipt['inputs_stable'] = all(sha(path) == input_hashes[str(path)] for path in tracked_inputs)
receipt['sources_stable'] = all(sha(ROOT / path) == expected for path, expected in source_hashes.items())
receipt['binary_stable'] = sha(binary) == receipt['binary']['sha256']
assert receipt['inputs_stable'] and receipt['sources_stable'] and receipt['binary_stable']
receipt['status'] = 'passed'
save()
print(receipt['summary'], flush=True)
print('Binary bytes:', receipt['binary']['bytes'], flush=True)
