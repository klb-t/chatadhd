# W5 focused native proof

Production sources: 156a82080a7abb8a68d249747dfa167b3045effe. Actual freshly compiled objects from the final full vendored GCC build, linked with the actual core and unchanged support libraries. Run:15 cases/442 assertions, no skipped cases. This is a focused execution; it does not substitute for full CTest. `run.py`, original receipt, linker dependency file and untruncated logs preserve exact inputs, commands and hashes. The executable is omitted; reproduce it using the runner and the recorded build. Temporary DBs used only synthetic fixtures.
