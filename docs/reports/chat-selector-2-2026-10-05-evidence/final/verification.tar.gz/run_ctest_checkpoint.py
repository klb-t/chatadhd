from pathlib import Path
import subprocess, json, hashlib, shutil, datetime

repo=Path('/workspace/scratch/f98faad71b9c/chatadhd')
source=Path('/tmp/w3-selector-2-baseline')
build=Path('/tmp/w3-selector-2-baseline-build')
output=Path('/tmp/w3-full-ctest-equality-2026-10-05')
output.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):(output/name).write_text(json.dumps(obj,indent=2)+'\n')
prior=json.loads(Path('/tmp/w3-full-ctest-2026-10-05/source-overlay.json').read_text())
hashes={}
for name in prior['files']:
    assert (repo/name).read_bytes()==(source/name).read_bytes(),name
    hashes[name]=sha(repo/name)
overlay={**prior,'files':hashes,'selected_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()}
save('source-overlay.json',overlay)
record=json.loads(Path('/dev/shm/w3-equality-incorporated-core-cleanup.json').read_text())
core=build/'libloom_core.a'
assert sha(core)==record['core_sha256']
save('owned-core-members.json',record)
cache=(build/'CMakeCache.txt').read_text()
assert 'CMAKE_BUILD_TYPE:STRING=Debug' in cache
assert 'CMAKE_CXX_FLAGS_DEBUG:STRING=-O0 -g0' in cache
assert 'LOOM_WERROR:BOOL=ON' in cache
assert 'LOOM_USE_SYSTEM_SQLITE:BOOL=OFF' in cache
manifest_command=['/root/.local/bin/ctest','--test-dir',str(build),'--show-only=json-v1']
manifest=json.loads(subprocess.check_output(manifest_command,text=True));save('ctest-manifest.json',manifest)
receipt={'schema':'loom.w3_full_ctest_receipt/1','source_commit':overlay['selected_source_commit'],'base_commit':prior['selected_base'],'compiled_source_base':prior['base'],'source_base_delta':prior['base_delta'],'owned_source_overlay_matches':True,'core_sha256_before':sha(core),'core_bytes':core.stat().st_size,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_command':manifest_command,'test_entries':len(manifest['tests']),'server_executable_built':False,'werror':True,'debug_assertions':True,'sqlite':'vendored','parallel_jobs':2,'external_provider_calls':0,'paid_calls':0}
command=['/root/.local/bin/ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-j2','--output-junit',str(output/'ctest.xml'),'--output-log',str(output/'ctest.log'),'--test-output-size-passed','10485760','--test-output-size-failed','10485760']
receipt['ctest_command']=command;save('receipt.json',receipt)
with (output/'run.log').open('wb') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
receipt['ctest_exit_code']=result.returncode
receipt['core_sha256_after']=sha(core);receipt['core_before_after_matches']=receipt['core_sha256_after']==receipt['core_sha256_before']
for name,p in [('CMakeCache.txt',build/'CMakeCache.txt'),('compile_commands.json',build/'compile_commands.json'),('LastTest.log',build/'Testing/Temporary/LastTest.log'),('build.log',Path('/tmp/w3-selector-2-equality-build.log')),('storage-relocation.json',Path('/tmp/w3-build-storage-relocation.json')),('obsolete-output-cleanup.json',Path('/dev/shm/w3-equality-obsolete-output-cleanup.json'))]:shutil.copy2(p,output/name)
checker=Path('/tmp/w3-ctest-case-guard/.github/scripts/verify_ctest.py')
pin=json.loads(Path('/tmp/w3-ctest-case-guard/pin.json').read_text())
for name,want in pin['files'].items():assert sha(Path('/tmp/w3-ctest-case-guard')/name)==want,name
receipt['case_guard_pin']=pin
guard=['python3',str(checker),'--manifest',str(output/'ctest-manifest.json'),'--junit',str(output/'ctest.xml'),'--output',str(output/'coverage.json'),'--preset','dev','--policy','/tmp/w3-ctest-case-guard/.github/ctest-evidence-policy.json']
receipt['guard_command']=guard
with (output/'guard.log').open('wb') as log: checked=subprocess.run(guard,stdout=log,stderr=subprocess.STDOUT)
receipt['guard_exit_code']=checked.returncode;receipt['guard']=json.loads((output/'coverage.json').read_text())
receipt['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['evidence_sha256']={p.name:sha(p) for p in output.iterdir() if p.is_file() and p.name!='receipt.json'}
save('receipt.json',receipt)
print(json.dumps({'ctest_exit':result.returncode,'guard_exit':checked.returncode,'core_stable':receipt['core_before_after_matches'],'guard':receipt['guard']},indent=2))
raise SystemExit(result.returncode or checked.returncode or not receipt['core_before_after_matches'])
