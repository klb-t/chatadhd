import hashlib,importlib.util,json,pathlib,shutil,subprocess
root=pathlib.Path('/workspace/scratch/f98faad71b9c/chatadhd')
previous=pathlib.Path('/tmp/w3-runtime-preset-actual-2026-10-05-second')
final=pathlib.Path('/tmp/w3-runtime-preset-actual-2026-10-05-equality')
final.mkdir()
old=json.loads((previous/'manifest.json').read_text())
spec=importlib.util.spec_from_file_location('actual_runner',root/'loom/src/context/tests/run_runtime_preset_test.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
m={'schema':'loom.runtime_preset_verification/1','mode':'both','link_scope':'actual_utility_dependencies','core_sha256':None,'core_build_started':False,'source_sha256':{},'dependencies':old['dependencies'],'commands':[],'variants':{},'objects':{},'reused_components':[],'passed':False}
try:
    for name,original_sha in old['source_sha256'].items():
        source=root/name
        if name.startswith('loom/src/util/'):
            assert runner.sha(source)==original_sha,name
        m['source_sha256'][name]=runner.sha(source)
        target=final/'source/checkout'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    for dependency in old['dependencies'].values():
        for name,want in dependency['files'].items():
            assert runner.sha(previous/'source'/name)==want,name
    snapshot=final/'source/checkout'
    runner.execute(['python3',str(snapshot/'loom/src/context/gen_runtime_presets.py'),'--check'],final/'generated_check.log',m,root)
    for mode in ('base','layers'):
        dest=final/mode;dest.mkdir()
        compile_command=next(c for c in old['commands'] if '-c' in c and c[-1]==str(previous/mode/'runtime_preset_test.o'))
        link_command=next(c for c in old['commands'] if '-c' not in c and c[-1]==str(previous/mode/'runtime_preset_test'))
        compile_command=[str(snapshot/'loom/src/context/tests/runtime_preset_test.cpp') if x==str(root/'loom/src/context/tests/runtime_preset_test.cpp') else str(dest/'runtime_preset_test.o') if x==str(previous/mode/'runtime_preset_test.o') else x for x in compile_command]
        # Actual snapshot headers precede the live root's private headers;
        # actual W11/W12 overlay includes keep their existing precedence.
        index=compile_command.index(str(root/'loom/src'))-1
        compile_command[index:index]=['-I',str(snapshot/'loom/src')]
        runner.execute(compile_command,dest/'compile.log',m,root)
        m['objects'][str(dest/'runtime_preset_test.o')]=runner.sha(dest/'runtime_preset_test.o')
        for obj in sorted((previous/mode).glob('native_*.o')):
            m['reused_components'].append({'object':str(obj),'sha256':runner.sha(obj),'original_manifest_sha256':runner.sha(previous/'manifest.json'),'source_scope':'actual utility/W11/W12 units; source SHA unchanged and pinned headers/embedded include verified'})
        link_command=[str(dest/'runtime_preset_test.o') if x==str(previous/mode/'runtime_preset_test.o') else str(dest/'runtime_preset_test') if x==str(previous/mode/'runtime_preset_test') else x for x in link_command]
        runner.execute(link_command,dest/'link.log',m,root)
        text=runner.execute([str(dest/'runtime_preset_test'),'--no-intro=true','--no-colors=true'],dest/'tests.log',m,root)
        m['variants'][mode]={'counts':runner.check_counts(text,mode),'executable_sha256':runner.sha(dest/'runtime_preset_test'),'provider_calls':0,'paid_calls':0}
        print(text,flush=True)
        if mode=='base':
            generator_flags=compile_command[:]
            source_index=generator_flags.index('-c')
            generator_flags=generator_flags[:source_index]
            runner.generator_regression(snapshot,final,generator_flags,link_command[2:link_command.index('-fuse-ld=gold')],m)
    # Recompile every real dependency TU against the latest real public class
    # layouts. Only unchanged root utility objects are reused.
    latest_dest=final/'layers_latest';latest_dest.mkdir()
    latest_evidence=final/'latest';latest_evidence.mkdir()
    latest_sources=runner.extract(root,latest_evidence,'22873e047abe6b56808dd2fbc4fe41188ee0e7a8',[
        'loom/include/loom/runtime_profile.h','loom/src/model/runtime_profile.cpp',
        'loom/src/model/runtime_profiles_embedded.inc'],'W11_latest',m)
    latest_sources+=runner.extract(root,latest_evidence,'5115477fda183572acb901cfd2ea98979fb0f45d',[
        'loom/include/loom/onboarding_layers.h','loom/src/onboarding/layers.cpp',
        'loom/src/onboarding/runtime_adapter.h','loom/src/onboarding/runtime_adapter.cpp',
        'loom/include/loom/onboarding_presentation.h','loom/include/loom/onboarding.h',
        'loom/include/loom/onboarding_store.h','loom/src/onboarding/presentation.cpp',
        'loom/src/onboarding/store.cpp','loom/src/onboarding/builtin.inc'],'W12_latest',m)
    old_flags=next(c for c in old['commands'] if '-c' in c and c[-1]==str(previous/'layers/runtime_preset_test.o'))
    latest_flags=old_flags[:old_flags.index('-c')]
    latest_flags=[str(latest_evidence/'source/loom/include') if x==str(previous/'source/loom/include')
        else str(latest_evidence/'source/loom/src') if x==str(previous/'source/loom/src') else x for x in latest_flags]
    latest_flags=[x for x in latest_flags if x!='-DLOOM_RUNTIME_PRESET_TEST_MAIN=1']
    index=latest_flags.index(str(root/'loom/src'))-1
    latest_flags[index:index]=['-I',str(snapshot/'loom/src')]
    latest_flags+=['-ffunction-sections','-fdata-sections']
    latest_objects=[]
    for index,unit in enumerate(latest_sources):
        obj=latest_dest/f'dependency_{index}.o'
        runner.execute(latest_flags+['-c',str(unit),'-o',str(obj)],latest_dest/f'dependency_{index}.log',m,root)
        m['objects'][str(obj)]=runner.sha(obj);latest_objects.append(str(obj))
    latest_test=latest_dest/'runtime_preset_test.o'
    runner.execute(latest_flags+['-DLOOM_RUNTIME_PRESET_TEST_MAIN=1','-c',str(snapshot/'loom/src/context/tests/runtime_preset_test.cpp'),'-o',str(latest_test)],latest_dest/'compile.log',m,root)
    m['objects'][str(latest_test)]=runner.sha(latest_test)
    old_link=next(c for c in old['commands'] if '-c' not in c and c[-1]==str(previous/'layers/runtime_preset_test'))
    latest_link=[str(latest_test) if x==str(previous/'layers/runtime_preset_test.o')
        else str(latest_dest/'runtime_preset_test') if x==str(previous/'layers/runtime_preset_test') else x for x in old_link
        if x not in {str(previous/'layers'/f'native_{index}.o') for index in range(3)}]
    latest_link[2:2]=latest_objects
    latest_link.append('-Wl,--gc-sections')
    runner.execute(latest_link,latest_dest/'link.log',m,root)
    text=runner.execute([str(latest_dest/'runtime_preset_test'),'--no-intro=true','--no-colors=true'],latest_dest/'tests.log',m,root)
    m['variants']['layers_latest']={'counts':runner.check_counts(text,'layers'),'executable_sha256':runner.sha(latest_dest/'runtime_preset_test'),'provider_calls':0,'paid_calls':0}
    m['W12_latest_presentation_dependency']={'actual_store_translation_unit':True,'unused_store_database_sections_discarded':True}
    print(text,flush=True)
    for name,want in m['source_sha256'].items():assert runner.sha(root/name)==want,name
    m['source_before_after_matches']=True;m['compiled_private_source_snapshot']=True;m['passed']=True
finally:
    (final/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
