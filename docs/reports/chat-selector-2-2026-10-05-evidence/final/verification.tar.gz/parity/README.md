# W3 actual public-API parity evidence

This directory retains every original before-run evidence file unchanged, including full output matrices, original command arrays in manifest.json, compile/link/run logs and dependency files. Fixture source bytes match the original source hashes. Cues runner bytes match its original runner hash. The historical chat manifest did not record a runner hash; source/ retains the actual current committed runner snapshot, without claiming a retroactive hash measurement.

Original before core SHA256: `5866f62485fb94e5445c0db7d2949b195b49eb2bcbb7e948ecdea9facb1fbf99`.
Chat output: 1248 actual rows; 309980 bytes; SHA256 `27937894889b65e141440830d9500bb861896b8b52179b6a4dda73fc68a0a4da`.
Cues output: 26 actual rows (24 successful goals and 2 expected errors); 34879 bytes; SHA256 `63d9c93d85929e525b8987ae54579073bb7a45a437f9cb064845b0ec73b19031`.
Both original executions recorded zero provider calls. The full matrix is preserved; no classifier or expected payload implementation is copied into the fixture.

`selected-files.json` hashes each selected file and states its provenance role. `before/core-integrity.json` records the archive hash before and after both original runners. Temporary executable/object files were removed after hashing to release space; their hashes and exact rebuilding commands remain in the original manifests. Current consumer/data snapshots in current-inputs/ are explicitly current inputs, not original before sources. The original worktree base revision was observed as `66da570d3b5379492e128d940ad474467082c59f`; it now contains the current source overlay, so its present files cannot attest the earlier archive's sources.

## Replay

First build the chosen complete revision in a separate directory. To recreate the before behavior, use the declared baseline revision above and the fixture snapshots here. To validate the final migrated behavior, use the selected current revision in selected-files.json. Match the recorded toolchain/flags in before/*/manifest.json as appropriate: C++20, Debug `-O0 -g0`, vendored SQLite, OpenSSL, Werror, tests enabled, server disabled. A fresh configured CMake build must expose compile_commands.json and the loom_candidate_graph_native_tool link recipe. Build dependencies before executing the runners. Do not run their Ninja introspection concurrently with any Ninja/CMake operation in the same build directory. Rebuilt archive/binary hashes can differ by toolchain/build paths; retain the newly observed hashes and compare actual output bytes.

Set the following variables to the evidence directory, an already completed stable current build and NEW output directories. These commands do not configure or build core; they compile only the saved fixtures and link the actual configured dependencies:

```sh
PARITY_EVIDENCE=/absolute/path/to/parity
PARITY_BUILD=/absolute/path/to/completed-build
PARITY_RUN=/absolute/path/to/new-replay-output
python3 "$PARITY_EVIDENCE/source/loom/src/chat/tests/run_chat_preset_parity.py" --build-dir "$PARITY_BUILD" --output-dir "$PARITY_RUN/chat" --baseline "$PARITY_EVIDENCE/before/chat/outputs.json"
python3 "$PARITY_EVIDENCE/source/loom/src/context/tests/goal_cues_parity.py" --build-dir "$PARITY_BUILD" --output-dir "$PARITY_RUN/cues" --baseline "$PARITY_EVIDENCE/before/cues/outputs.json"
cmp "$PARITY_EVIDENCE/before/chat/outputs.json" "$PARITY_RUN/chat/outputs.json"
cmp "$PARITY_EVIDENCE/before/cues/outputs.json" "$PARITY_RUN/cues/outputs.json"
```

Each runner retains all per-row differences in comparison.json. Both compile/link/run exit codes and observed hashes are in each newly produced manifest. Record the current core hash before and after the sequential pair and confirm it is unchanged. No provider credentials or paid calls are required.

Final AFTER measurements executed serially after the full single-writer build completed and the coordinator released core SHA256 `bff3d69e0dfc3647296e66e9d1f11da6fafe94c78996e1d2efc3727719a5b6c3` at source commit `ec34a67b379dd1397d64ff728033c3b502778e41`. Core and fixture/runner hashes remained unchanged across both measurements. `after/chat` preserves 1248/1248 equal rows and `after/cues` preserves 26/26 equal rows: zero changed rows, full output bytes equal in both cases, zero provider calls. Both final manifests retain actual compile/link/run commands and binary/output hashes. `after/core-integrity.json` records the exact released core and both observed hash snapshots. Earlier after receipts remain in their original directories and are not relabeled as final evidence.
