import provided from "./provided.json" with { type: "json" };
import { resolvePresentation } from "./presentation.mjs";
try { resolvePresentation(provided); console.error("UNEXPECTED_SUCCESS"); process.exitCode=2; } catch(error) { console.error(error.stack); process.exitCode=1; }
