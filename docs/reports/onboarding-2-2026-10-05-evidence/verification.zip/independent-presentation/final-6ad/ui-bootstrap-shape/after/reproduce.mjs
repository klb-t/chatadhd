import assert from "node:assert/strict";
import provided from "./provided.json" with { type: "json" };
import { errorPresentation, PresentationError, resolvePresentation } from "./presentation.mjs";
let failure;
try { resolvePresentation(provided); } catch (error) { failure=error; }
assert.ok(failure instanceof PresentationError);
assert.equal(failure.code, "error.presentation_invalid");
assert.equal(failure.message, "error.presentation_invalid");
assert.equal(failure.machineOnly, true);
assert.deepEqual(errorPresentation(failure), { text: "error.presentation_invalid", details: "error.presentation_invalid" });
console.log(JSON.stringify({ name: failure.name, code: failure.code, message: failure.message, machineOnly: failure.machineOnly }));
