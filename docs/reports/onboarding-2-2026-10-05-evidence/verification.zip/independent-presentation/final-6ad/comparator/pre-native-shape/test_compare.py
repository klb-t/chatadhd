"""Adversarial unit checks for parity accounting, independent of real probe runs.

Fixtures are synthetic comparator inputs, never evidence of kernel behavior.
"""
from copy import deepcopy
import unittest

from compare import Comparison, PRESENTATION_AREA, PRESENTATION_ID, PRESENTATION_KEY, canonical, compare, sha, stable


def capture(member, value):
    text = canonical(value)
    locator = {"source": "sha256:" + sha(text), "member": member, "byte_start": 0, "byte_len": len(text.encode())}
    unit = stable("un_", locator["source"], canonical(locator))
    return {"id": stable("ob_", unit, canonical(locator), sha(text)), "unit": unit, "kind": "field", "text": text,
            "locator": locator, "date": "", "attrs": {"capture_scope": "record_bytes_only", "provenance": "effective_layer_resolution"}}


def entity(kind, identity, label, attrs):
    key = "\x1f".join(("onboarding", "synthetic/test-user", kind, identity))
    return {"id": stable("e_", kind, key), "kind": kind, "canonical_key": key, "label": label, "attrs": attrs,
            "origin": "system", "evidence_class": "derived", "labels": {}, "aliases": [], "parent": "",
            "first_seen": "", "last_seen": "", "confidence": None, "status": "active"}


def claim(subject, predicate, observation, obj="", value=None):
    qualifiers = {"extra": {"confidence_scope": "structure_only"}}
    identity = stable("cl_", subject, predicate, "o:" + obj if obj else "v:" + canonical(value), canonical(qualifiers))
    return {"id": identity, "subject": subject, "predicate": predicate, "object": obj, "value": value,
            "qualifiers": qualifiers, "assessment": {"origin": "system", "evidence_class": "derived", "confidence": 1.0,
            "support": [{"observation": observation["id"], "locator": observation["locator"], "quote": observation["text"],
                         "method": "onboarding.project_graph@1", "weight": 1.0}]}}


def fixture():
    old_entry = {"id": "settings/v1", "key": "onboarding.settings", "area": "onboarding/settings", "revision": 1,
                 "value": {"preference_mode": "ask", "custom": {"pack_revision": 1}}}
    entry = {"id": PRESENTATION_ID, "key": PRESENTATION_KEY, "area": PRESENTATION_AREA, "revision": 2,
             "value": {"schema": "loom.onboarding.presentation/1", "default_locale": "en", "locales": {"en": {"layer.builtin": "preset"}}}}
    pack = {"revision": 1, "pack_id": "synthetic/pack", "entries": [old_entry], "runtime_definition": {"defaults": {"settings": old_entry["value"]}},
            "vocabulary": {"kinds": {"default": "default", "layer": "layer", "exclusion": "exclusion"},
                           "predicates": {name: name for name in ("has_default", "has_state", "has_value", "from_layer")}}}
    new_pack = deepcopy(pack)
    new_pack["revision"] = 3
    new_pack["entries"].append(entry)
    new_pack["presentation_key"] = PRESENTATION_KEY

    def resolution(item, revision):
        return {"key": item["key"], "id": item["id"], "area": item["area"], "revision": item["revision"], "status": "effective", "layer": "builtin",
                "value": item["value"], "entity": {key: value for key, value in item.items() if key != "value"}, "explanation": "preset",
                "source": {"pack_revision": revision, "pack_id": "synthetic/pack", "entry_id": item["id"], "entry_revision": item["revision"]}}

    def snapshot(which_pack):
        revision = which_pack["revision"]
        defaults = [resolution(item, revision) for item in which_pack["entries"]]
        layers = {"schema": "loom.default_layers_state/1", "pack_revision": revision, "pack_fingerprint": sha(which_pack),
                  "catalog": {item["id"]: {"entry": item, "first_pack_revision": revision} for item in which_pack["entries"]},
                  "disabled": {}, "exclusions": {}, "areas": {}, "proposals": {}, "overrides": {}, "history": []}
        result = {"pack": which_pack, "layers": layers, "profile": {"fields": {"synthetic": {"status": "unknown"}}},
                  "effectiveDefaults": defaults, "effective_privacy": defaults[0], "revision": 1}
        if revision == 3:
            result["presentation"] = {"available": True, "status": "effective", "value": entry["value"], "resolution": defaults[-1]}
        return result

    def graph(state):
        profile = entity("profile", "profile", "profile", {})
        layer = entity("layer", "builtin", "Built-in defaults", {"layer": "builtin", "pack_revision": state["pack"]["revision"]})
        result = {"entities": [profile, layer], "claims": [], "observations": []}
        for default in state["effectiveDefaults"]:
            node = entity("default", default["id"], default["key"], default)
            source = capture("defaults/" + default["key"], default)
            result["entities"].append(node)
            result["observations"].append(source)
            result["claims"].extend((claim(profile["id"], "has_default", source, obj=node["id"]),
                                     claim(node["id"], "has_state", source, value="effective"),
                                     claim(node["id"], "has_value", source, value=default["value"]),
                                     claim(node["id"], "from_layer", source, obj=layer["id"])))
        return result

    def report(which_pack):
        state = snapshot(which_pack)
        return {"schema": "loom.onboarding_source_parity/1", "synthetic_only": True, "model_calls": 0, "pack": which_pack,
                "scenario": {"synthetic": True}, "session": {"default": {"snapshot_bytes": '{"status":"unknown"}'}},
                "native": {"default": {"snapshot": state, "request": {"ok": True, "value": {"prompt": "unchanged"}},
                    "request_bytes": '{"prompt":"unchanged"}', "profile_bytes": canonical(state["profile"]), "stored_graph": graph(state),
                    "policy": [{"result": {"ok": True, "value": {"allowed": False, "resolution": state["effective_privacy"]}}}]}},
                "within_run_invariants": {"synthetic": True}}
    return report(pack), report(new_pack)


class ComparatorTests(unittest.TestCase):
    def setUp(self):
        self.before, self.after = fixture()

    def rejected(self):
        with self.assertRaises((AssertionError, KeyError, StopIteration)):
            compare(self.before, self.after)

    def test_exact_old_payload_with_attributed_presentation_addition_passes(self):
        result = compare(self.before, self.after)
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["graph_comparisons"][0]["raw_graph_bytes_equal"])
        self.assertEqual(len(result["graph_comparisons"][0]["added_claim_ids"]), 4)

    def test_changed_profile_fails(self):
        self.after["native"]["default"]["snapshot"]["profile"]["fields"]["synthetic"]["status"] = "never"
        self.rejected()

    def test_changed_prompt_fails(self):
        self.after["native"]["default"]["request"]["value"]["prompt"] = "changed"
        self.rejected()

    def test_session_byte_change_fails(self):
        self.after["session"]["default"]["snapshot_bytes"] += " "
        self.rejected()

    def test_extra_snapshot_metadata_fails(self):
        self.after["native"]["default"]["snapshot"]["unexplained"] = True
        self.rejected()

    def test_extra_presentation_resolution_metadata_fails(self):
        self.after["native"]["default"]["snapshot"]["effectiveDefaults"][-1]["unexplained"] = True
        self.rejected()

    def test_extra_presentation_pack_entry_metadata_fails(self):
        self.after["pack"]["entries"][-1]["unexplained"] = True
        self.rejected()

    def test_changed_policy_fails(self):
        self.after["native"]["default"]["policy"][0]["result"]["value"]["allowed"] = True
        self.rejected()

    def test_arbitrary_nested_business_pack_revision_is_not_normalized(self):
        self.after["native"]["default"]["snapshot"]["effectiveDefaults"][0]["value"]["custom"]["pack_revision"] = 2
        self.rejected()

    def test_arbitrary_user_override_pack_revision_is_not_normalized(self):
        old = deepcopy(self.before["native"]["default"]["snapshot"]["layers"])
        new = deepcopy(self.after["native"]["default"]["snapshot"]["layers"])
        old["overrides"]["synthetic"] = {"value": {"pack_revision": 1}}
        new["overrides"]["synthetic"] = {"value": {"pack_revision": 2}}
        with self.assertRaises(AssertionError):
            Comparison(self.before, self.after).layers(old, new, "/unit/layers")

    def test_extra_native_entity_fails(self):
        self.after["native"]["default"]["stored_graph"]["entities"].append(entity("default", "unknown", "unknown", {}))
        self.rejected()

    def test_duplicate_native_entity_fails(self):
        rows = self.after["native"]["default"]["stored_graph"]["entities"]
        rows.append(deepcopy(rows[0]))
        self.rejected()

    def test_duplicate_native_claim_fails(self):
        rows = self.after["native"]["default"]["stored_graph"]["claims"]
        rows.append(deepcopy(rows[0]))
        self.rejected()

    def test_duplicate_native_observation_fails(self):
        rows = self.after["native"]["default"]["stored_graph"]["observations"]
        rows.append(deepcopy(rows[0]))
        self.rejected()

    def test_unknown_report_keys_even_on_both_sides_fail(self):
        self.before["unexpected"] = {"x": 1}
        self.after["unexpected"] = {"x": 2}
        self.rejected()

    def test_unknown_graph_table_fails(self):
        self.after["native"]["default"]["stored_graph"]["unexpected"] = []
        self.rejected()

    def test_old_native_entity_business_change_fails(self):
        self.after["native"]["default"]["stored_graph"]["entities"][0]["attrs"]["unknown"] = "changed"
        self.rejected()

    def test_added_entity_extra_payload_fails(self):
        self.after["native"]["default"]["stored_graph"]["entities"][-1]["private"] = "unattributed"
        self.rejected()

    def test_added_claim_wrong_target_fails(self):
        self.after["native"]["default"]["stored_graph"]["claims"][-1]["object"] = "forged-target"
        self.rejected()

    def test_added_claim_wrong_support_quote_fails(self):
        self.after["native"]["default"]["stored_graph"]["claims"][-1]["assessment"]["support"][0]["quote"] = "forged"
        self.rejected()

    def test_native_source_hash_forgery_fails(self):
        self.after["native"]["default"]["stored_graph"]["observations"][0]["text"] += " "
        self.rejected()

    def test_native_observation_identity_forgery_fails(self):
        self.after["native"]["default"]["stored_graph"]["observations"][0]["id"] = "forged"
        self.rejected()

    def test_boolean_number_substitution_fails(self):
        self.after["native"]["default"]["snapshot"]["profile"]["fields"]["synthetic"]["numeric"] = False
        self.before["native"]["default"]["snapshot"]["profile"]["fields"]["synthetic"]["numeric"] = 0
        self.rejected()


if __name__ == "__main__":
    unittest.main()
