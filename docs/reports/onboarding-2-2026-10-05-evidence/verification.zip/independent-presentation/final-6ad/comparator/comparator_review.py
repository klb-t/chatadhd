from pathlib import Path
from copy import deepcopy
import sys,json,hashlib
path=Path(sys.argv[1]).resolve();sys.path.insert(0,str(path))
from test_compare import fixture
from compare import compare
cases=[]
for kind in ('entities','claims','observations'):
 before,after=fixture();after['native']['default']['stored_graph'][kind].append(deepcopy(after['native']['default']['stored_graph'][kind][0]))
 try:status=compare(before,after)['status']
 except Exception as error:status='REJECTED:'+type(error).__name__
 cases.append({'mutation':'duplicate old '+kind,'observed_comparator_status':status})
before,after=fixture();before['unexpected']={'x':1};after['unexpected']={'x':2}
try:status=compare(before,after)['status']
except Exception as error:status='REJECTED:'+type(error).__name__
cases.append({'mutation':'uncompared extra top-level field changed','observed_comparator_status':status})
before,after=fixture();before['native']['default']['stored_graph']['unexpected']=[];after['native']['default']['stored_graph']['unexpected']=[]
try:status=compare(before,after)['status']
except Exception as error:status='REJECTED:'+type(error).__name__
cases.append({'mutation':'unlisted native graph collection','observed_comparator_status':status})
out={'synthetic_only':True,'scope':'Independent comparator rejection checks only, no actual native probe run','compare_source_sha256':hashlib.sha256((path/'compare.py').read_bytes()).hexdigest(),'results':cases,'verdict':'PASS' if all(x['observed_comparator_status'].startswith('REJECTED:') for x in cases) else 'FAIL'}
print(json.dumps(out,indent=2))
if out['verdict']!='PASS':raise SystemExit(1)
