from pathlib import Path
from copy import deepcopy
import hashlib,json,sys,gc
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
from compare import compare
source_before=hashlib.sha256((root/'compare.py').read_bytes()).hexdigest()
trace_paths={'before':root/'before/trace.json','after':root/'after-final-pack3/trace.json'}
trace_hashes={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in trace_paths.items()}
before=json.loads(trace_paths['before'].read_text());after=json.loads(trace_paths['after'].read_text())
# Reduce to an unchanged actual stage for synthetic adversarial inputs; this is
# an accounting-tool test, not a new execution of native behavior.
stage=next(iter(before['native']))
before['native']={stage:before['native'][stage]};after['native']={stage:after['native'][stage]};gc.collect()
control=compare(before,after)
cases=[]
for mutation in ['duplicate entity','duplicate claim','duplicate observation','unknown report key','unknown graph table','old entity label changed','old support quote changed','profile business pack_revision added','default business pack_revision added','observation identity forged']:
 b=deepcopy(before);a=deepcopy(after);g=a['native'][stage]['stored_graph']
 if mutation.startswith('duplicate '):
  table={'entity':'entities','claim':'claims','observation':'observations'}[mutation.split()[1]];g[table].append(deepcopy(g[table][0]))
 elif mutation=='unknown report key':b['unlisted']={'x':1};a['unlisted']={'x':2}
 elif mutation=='unknown graph table':g['unlisted']=[]
 elif mutation=='old entity label changed':g['entities'][0]['label']='synthetic mutated label'
 elif mutation=='old support quote changed':
  old_ids={row['id'] for row in b['native'][stage]['stored_graph']['claims']}
  claim=next(row for row in g['claims'] if row['id'] in old_ids and row['assessment']['basis']['support'])
  claim['assessment']['basis']['support'][0]['quote']='synthetic mutated source quote'
 elif mutation=='profile business pack_revision added':a['native'][stage]['snapshot']['profile']['synthetic_business']={'pack_revision':a['pack']['revision']}
 elif mutation=='default business pack_revision added':
  old_ids={row['id'] for row in b['native'][stage]['stored_graph']['entities']}
  entity=next(row for row in g['entities'] if row['id'] in old_ids and isinstance(row.get('attrs',{}).get('value'),dict))
  entity['attrs']['value']['pack_revision']=a['pack']['revision']
 elif mutation=='observation identity forged':g['observations'][0]['id']='ob_synthetic_forged'
 try:
  result=compare(b,a);cases.append({'mutation':mutation,'status':result['status']})
 except Exception as error:cases.append({'mutation':mutation,'status':'REJECTED','error_type':type(error).__name__,'reason':str(error)[:200]})
 del b,a;gc.collect()
source_after=hashlib.sha256((root/'compare.py').read_bytes()).hexdigest()
out={'schema':'w12.independent.actual_trace_accounting/1','scope':'Synthetic modifications derived from one actual persisted native stage only. No compilation, model calls or new native behavior execution. Separate from framework25 and prior independent5-mutation denominators.','compare_source_sha256_before':source_before,'compare_source_sha256_after':source_after,'actual_trace_files_sha256':trace_hashes,'actual_native_stage':stage,'unmodified_single_stage_control_status':control['status'],'mutations':cases,'verdict':'PASS' if source_before==source_after and control['status']=='PASS' and all(x['status']=='REJECTED' for x in cases) else 'FAIL'}
print(json.dumps(out,indent=2))
if out['verdict']!='PASS':raise SystemExit(1)
