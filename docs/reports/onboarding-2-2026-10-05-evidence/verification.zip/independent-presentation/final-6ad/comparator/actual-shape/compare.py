"""Strict business parity with enumerated presentation/pack-lineage additions.

The complete raw graphs remain in trace.json. We do not claim graph-byte parity:
adding a presentation default changes native nodes and pack-revision source bytes.
Every retained old row is compared after ONLY the documented lineage transform.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path

PRESENTATION_ID = "onboarding.presentation/v1"
PRESENTATION_KEY = "presentation.onboarding"
PRESENTATION_AREA = "onboarding/presentation"


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha(value):
    return hashlib.sha256((value if isinstance(value, str) else canonical(value)).encode()).hexdigest()


def stable(prefix, *parts):
    return prefix + hashlib.sha256("\x1f".join(parts).encode()).hexdigest()[:16]


def first_diff(a, b, path=""):
    if type(a) is not type(b):
        return path, a, b
    if isinstance(a, dict):
        if a.keys() != b.keys():
            return path + "/keys", sorted(a), sorted(b)
        for key in sorted(a):
            if a[key] != b[key]:
                return first_diff(a[key], b[key], path + "/" + key)
    elif isinstance(a, list):
        if len(a) != len(b):
            return path + "/length", len(a), len(b)
        for i, (left, right) in enumerate(zip(a, b)):
            if left != right:
                return first_diff(left, right, path + "/" + str(i))
    return path, a, b


def same(a, b, context):
    if type(a) is not type(b) or a != b or (isinstance(a, (dict, list)) and canonical(a) != canonical(b)):
        path, left, right = first_diff(a, b)
        raise AssertionError(f"{context}{path}: BEFORE={str(left)[:180]!r}; AFTER={str(right)[:180]!r}")


class Comparison:
    def __init__(self, before, after):
        self.before, self.after = before, after
        self.old_revision = before["pack"]["revision"]
        self.new_revision = after["pack"]["revision"]
        self.changes = []
        self.graphs = []
        self.exact_checks = []
        self.new_entry = next(entry for entry in after["pack"]["entries"] if entry["id"] == PRESENTATION_ID)

    def revision_record(self, value, path, keys):
        result = deepcopy(value)
        for key in keys:
            if key in result and result[key] == self.new_revision:
                result[key] = self.old_revision
                self.changes.append({"category": "pack_revision_lineage", "path": path + "/" + key,
                                     "before": self.old_revision, "after": self.new_revision})
        return result

    def resolution(self, value, path):
        result = deepcopy(value)
        # Never touch user values or arbitrary nested keys named pack_revision.
        if result.get("layer") in {"builtin", "user_exclusion", "user_disabled", "pack_proposal"} and "source" in result:
            result["source"] = self.revision_record(result["source"], path + "/source", {"pack_revision", "created_pack_revision"})
        return result

    def pack(self):
        before, after = self.before["pack"], deepcopy(self.after["pack"])
        same(before["revision"], 1, "pinned pack revision")
        same(after["revision"], 3, "additive pack revision")
        same(self.new_entry["key"], PRESENTATION_KEY, "presentation key")
        same(self.new_entry["area"], PRESENTATION_AREA, "presentation area")
        same(self.new_entry["revision"], 2, "presentation entry revision")
        same(set(self.new_entry), {"id", "key", "area", "revision", "value"}, "presentation entry shape")
        same(self.new_entry["value"]["schema"], "loom.onboarding.presentation/1", "presentation catalog schema")
        same(after.pop("presentation_key"), PRESENTATION_KEY, "pack presentation binding")
        after["entries"] = [entry for entry in after["entries"] if entry["id"] != PRESENTATION_ID]
        after["revision"] = before["revision"]
        same(before, after, "old pack payload")
        self.changes.append({"category": "additive_presentation_default", "id": PRESENTATION_ID,
                             "key": PRESENTATION_KEY, "area": PRESENTATION_AREA,
                             "value_sha256": sha(self.new_entry["value"])})

    def layers(self, before, after, path):
        normalized = deepcopy(after)
        same(normalized["pack_fingerprint"], sha(self.after["pack"]), path + "/pack_fingerprint integrity")
        same(before["pack_fingerprint"], sha(self.before["pack"]), path + "/old pack_fingerprint integrity")
        record = normalized["catalog"].pop(PRESENTATION_ID)
        same(record, {"entry": self.new_entry, "first_pack_revision": self.new_revision}, path + "/presentation catalog row")
        normalized["pack_fingerprint"] = before["pack_fingerprint"]
        self.changes.append({"category": "pack_fingerprint", "path": path + "/pack_fingerprint",
                             "before": before["pack_fingerprint"], "after": after["pack_fingerprint"]})
        normalized = self.revision_record(normalized, path, {"pack_revision"})
        for map_name, revision_key in (("catalog", "first_pack_revision"), ("disabled", "pack_revision"),
                                      ("exclusions", "pack_revision"), ("areas", "excluded_at_pack_revision"),
                                      ("proposals", "created_pack_revision")):
            for identity, record in normalized.get(map_name, {}).items():
                normalized[map_name][identity] = self.revision_record(record, path + "/" + map_name + "/" + identity, {revision_key})
        same(before, normalized, path)

    def snapshot(self, before, after, path):
        normalized = deepcopy(after)
        same(before["pack"], self.before["pack"], path + "/baseline pack installed")
        same(after["pack"], self.after["pack"], path + "/after pack installed")
        self.layers(before["layers"], after["layers"], path + "/layers")
        normalized["layers"] = before["layers"]
        normalized["pack"] = before["pack"]
        added = [row for row in normalized["effectiveDefaults"] if row["key"] == PRESENTATION_KEY]
        same(len(added), 1, path + "/new effective default count")
        expected = deepcopy(next(row for row in before["effectiveDefaults"] if row["status"] == "effective" and row["layer"] == "builtin"))
        for key in ("id", "key", "area", "revision", "value"):
            expected[key] = self.new_entry[key]
        expected["entity"] = {key: value for key, value in self.new_entry.items() if key != "value"}
        expected["source"]["pack_revision"] = self.new_revision
        expected["source"]["entry_id"] = PRESENTATION_ID
        expected["source"]["entry_revision"] = self.new_entry["revision"]
        same(added[0], expected, path + "/new complete native default resolution")
        presentation = normalized.pop("presentation")
        same(presentation, {"available": True, "status": "effective", "resolution": added[0], "value": self.new_entry["value"]},
             path + "/presentation inspection envelope")
        normalized["effectiveDefaults"] = [row for row in normalized["effectiveDefaults"] if row["key"] != PRESENTATION_KEY]
        normalized["effectiveDefaults"] = [self.resolution(row, path + "/effectiveDefaults/" + row["key"])
                                            for row in normalized["effectiveDefaults"]]
        normalized["effective_privacy"]["resolution"] = self.resolution(normalized["effective_privacy"]["resolution"], path + "/effective_privacy/resolution")
        same(before, normalized, path)
        self.exact_checks.append({"category": "native_snapshot_business_payload", "path": path,
                                  "profile_sha256": sha(before["profile"]), "after_profile_sha256": sha(after["profile"])})

    def observation(self, row, path):
        result = deepcopy(row)
        locator = row["locator"]
        same(locator["source"], "sha256:" + sha(row["text"]), path + "/captured bytes hash")
        same(locator["byte_start"], 0, path + "/capture start")
        same(locator["byte_len"], len(row["text"].encode()), path + "/capture byte length")
        expected_unit = stable("un_", locator["source"], canonical(locator))
        same(row["unit"], expected_unit, path + "/native unit identity")
        same(row["id"], stable("ob_", expected_unit, canonical(locator), sha(row["text"])), path + "/native observation identity")
        if locator["member"].startswith("defaults/") or locator["member"] == "method/default-origin":
            content = json.loads(row["text"])
            same(isinstance(content, dict) and {"key", "status", "layer"}.issubset(content), True, path + "/resolution source shape")
            result["text"] = canonical(self.resolution(content, path + "/captured_resolution"))
        result["locator"]["source"] = "sha256:" + sha(result["text"])
        result["locator"]["byte_len"] = len(result["text"].encode())
        result["unit"] = stable("un_", result["locator"]["source"], canonical(result["locator"]))
        result["id"] = stable("ob_", result["unit"], canonical(result["locator"]), sha(result["text"]))
        return result

    def graph(self, before, after, path, snapshot):
        for label, graph in (("before", before), ("after", after)):
            same(set(graph), {"entities", "claims", "observations"}, path + "/" + label + " graph shape")
            for table, rows in graph.items():
                same(len(rows), len({row["id"] for row in rows}), path + "/" + label + "/" + table + " unique identities")
        old_entities = {row["id"]: row for row in before["entities"]}
        new_entities = {row["id"]: row for row in after["entities"]}
        added = set(new_entities) - set(old_entities)
        same(len(added), 1, path + "/additive entity count")
        identity = next(iter(added))
        entity = new_entities[identity]
        same(entity["kind"], self.after["pack"]["vocabulary"]["kinds"]["default"], path + "/presentation entity kind")
        same(entity["label"], PRESENTATION_KEY, path + "/presentation entity label")
        expected_resolution = next(row for row in snapshot["effectiveDefaults"] if row["key"] == PRESENTATION_KEY)
        same(entity["attrs"], expected_resolution, path + "/presentation entity payload")
        exemplar = next(row for row in before["entities"] if row["kind"] == entity["kind"] and
                        row["attrs"].get("status") == "effective" and row["attrs"].get("layer") == "builtin")
        expected_entity = deepcopy(exemplar)
        expected_entity["canonical_key"] = exemplar["canonical_key"].rsplit("\x1f", 1)[0] + "\x1f" + PRESENTATION_ID
        expected_entity["id"] = stable("e_", entity["kind"], expected_entity["canonical_key"])
        expected_entity["label"] = PRESENTATION_KEY
        expected_entity["attrs"] = expected_resolution
        same(entity, expected_entity, path + "/presentation complete native entity")
        new_entities.pop(identity)
        same(set(old_entities), set(new_entities), path + "/old entity identity set")
        for eid, row in new_entities.items():
            normalized = deepcopy(row)
            kind = self.after["pack"]["vocabulary"]["kinds"]
            attrs_path = path + "/entities/" + eid + "/attrs"
            if row["kind"] == kind["default"]:
                normalized["attrs"] = self.resolution(row["attrs"], attrs_path)
            elif row["kind"] == kind["layer"] and row["attrs"].get("layer") == "builtin":
                normalized["attrs"] = self.revision_record(row["attrs"], attrs_path, {"pack_revision"})
            elif row["kind"] == kind["exclusion"]:
                normalized["attrs"]["rule"] = self.revision_record(row["attrs"]["rule"], attrs_path + "/rule", {"pack_revision"})
            same(old_entities[eid], normalized, path + "/entities/" + eid)
        old_observations = {row["id"]: row for row in before["observations"]}
        after_observations = {row["id"]: row for row in after["observations"]}
        added_sources = [row for row in after["observations"] if row["locator"]["member"] == "defaults/" + PRESENTATION_KEY]
        same(len(added_sources), 1, path + "/presentation source count")
        same(json.loads(added_sources[0]["text"]), expected_resolution, path + "/presentation source payload")
        self.observation(added_sources[0], path + "/new presentation observation")
        expected_source = deepcopy(next(row for row in before["observations"]
                                        if row["locator"]["member"] == "defaults/" + exemplar["label"]))
        for key in ("id", "unit", "text"):
            expected_source[key] = added_sources[0][key]
        for key in ("source", "member", "byte_len"):
            expected_source["locator"][key] = added_sources[0]["locator"][key]
        same(added_sources[0], expected_source, path + "/presentation complete native source")
        old_normalized = {row["id"]: self.observation(row, path + "/old_sources/" + row["id"]) for row in before["observations"]}
        after_normalized = {row["id"]: self.observation(row, path + "/after_sources/" + row["id"]) for row in after["observations"] if row not in added_sources}
        same(sorted(old_normalized.values(), key=canonical), sorted(after_normalized.values(), key=canonical), path + "/old observations after attributed lineage transform")
        predicates = self.after["pack"]["vocabulary"]["predicates"]
        additions = [row for row in after["claims"] if row["subject"] == identity or row["object"] == identity]
        same(len(additions), 4, path + "/presentation claim count")
        same({row["predicate"] for row in additions}, {predicates[name] for name in ("has_default", "has_state", "has_value", "from_layer")}, path + "/presentation predicate set")
        for claim in additions:
            template = next(row for row in before["claims"] if row["predicate"] == claim["predicate"] and
                            (row["object"] == exemplar["id"] if row["predicate"] == predicates["has_default"]
                             else row["subject"] == exemplar["id"]))
            expected_claim = deepcopy(template)
            if claim["predicate"] == predicates["has_default"]:
                expected_claim["object"] = identity
            else:
                expected_claim["subject"] = identity
            if claim["predicate"] == predicates["has_value"]:
                expected_claim["value"] = self.new_entry["value"]
            for support in expected_claim["assessment"]["basis"]["support"]:
                support["observation"] = added_sources[0]["id"]
                support["quote"] = added_sources[0]["text"]
                support["locator"] = added_sources[0]["locator"]
            obj = "o:" + expected_claim["object"] if expected_claim["object"] else "v:" + canonical(expected_claim["value"])
            expected_claim["id"] = stable("cl_", expected_claim["subject"], expected_claim["predicate"], obj, canonical(expected_claim["qualifiers"]))
            same(claim, expected_claim, path + "/presentation complete native claim")

        def normalized_claims(rows, raw_sources, normalized_sources):
            result = {}
            for row in rows:
                claim = deepcopy(row)
                for support in claim["assessment"]["basis"]["support"]:
                    source = raw_sources[support["observation"]]
                    same(support["quote"], source["text"], path + "/support quote exact captured bytes")
                    same(support["locator"], source["locator"], path + "/support locator exact capture")
                    normalized = normalized_sources[support["observation"]]
                    support["observation"] = normalized["id"]
                    support["quote"] = normalized["text"]
                    support["locator"] = normalized["locator"]
                result[claim["id"]] = claim
            return result
        old_claims = normalized_claims(before["claims"], old_observations, old_normalized)
        new_claims = normalized_claims([row for row in after["claims"] if row not in additions], after_observations, after_normalized)
        same(old_claims, new_claims, path + "/old claims and assessments after source-lineage transform")
        self.graphs.append({"path": path, "raw_graph_bytes_equal": before == after,
                            "before_sha256": sha(before), "after_sha256": sha(after),
                            "added_entity_ids": sorted(added), "added_claim_ids": [row["id"] for row in additions],
                            "added_observation_ids": [row["id"] for row in added_sources],
                            "old_entity_count": len(old_entities), "old_claim_count": len(old_claims),
                            "old_observation_count": len(old_observations), "old_rows_lineage_normalized_equal": True})

    def run(self):
        report_keys = {"schema", "synthetic_only", "model_calls", "pack", "scenario", "session", "native", "within_run_invariants"}
        same(set(self.before), report_keys, "before probe report shape")
        same(set(self.after), report_keys, "after probe report shape")
        same(self.before["schema"], self.after["schema"], "probe schema")
        same(self.before["synthetic_only"], True, "before synthetic inputs")
        same(self.after["synthetic_only"], True, "after synthetic inputs")
        same(self.before["model_calls"], 0, "before model calls")
        same(self.after["model_calls"], 0, "after model calls")
        same(self.before["scenario"], self.after["scenario"], "default interview scenario")
        same(self.before["session"], self.after["session"], "ProfileSession snapshots requests policy exact")
        self.exact_checks.append({"category": "ProfileSession_raw_exact", "stages": len(self.before["session"]),
                                  "before_sha256": sha(self.before["session"]), "after_sha256": sha(self.after["session"])})
        self.pack()
        same(self.before["native"].keys(), self.after["native"].keys(), "native trace stage set")
        for stage, old in self.before["native"].items():
            new = self.after["native"][stage]
            same(old.keys(), new.keys(), "native stage shape " + stage)
            self.snapshot(old["snapshot"], new["snapshot"], "/native/" + stage + "/snapshot")
            same(old["request"], new["request"], "/native/" + stage + "/prepared_request_exact")
            if "policy" in old:
                normalized_policy = deepcopy(new["policy"])
                for i, item in enumerate(normalized_policy):
                    if item["result"]["ok"] and "resolution" in item["result"]["value"]:
                        item["result"]["value"]["resolution"] = self.resolution(item["result"]["value"]["resolution"], "/native/" + stage + "/policy/" + str(i) + "/result/value/resolution")
                same(old["policy"], normalized_policy, "/native/" + stage + "/policy")
            self.graph(old["stored_graph"], new["stored_graph"], "/native/" + stage + "/stored_graph", new["snapshot"])
            for key in set(old) - {"snapshot", "request", "policy", "stored_graph"}:
                same(old[key], new[key], "/native/" + stage + "/" + key + " exact bytes")
        same(self.before["within_run_invariants"], self.after["within_run_invariants"], "within-run native invariants")
        return {"status": "PASS", "scope": "Exact business payload parity; complete raw graphs differ by enumerated presentation entities/claims/sources and pack-lineage metadata.",
                "session_stages": len(self.before["session"]), "native_stages": len(self.before["native"]),
                "prepared_requests": sum("request" in stage for trace in (self.before["session"], self.before["native"]) for stage in trace.values()),
                "privacy_decisions": sum(len(stage.get("policy", [])) for trace in (self.before["session"], self.before["native"]) for stage in trace.values()),
                "allowed_additive_changes": self.changes, "graph_comparisons": self.graphs,
                "exact_payload_checks": self.exact_checks, "canonical_before_sha256": sha(self.before), "canonical_after_sha256": sha(self.after), "model_calls": 0}


def compare(before, after):
    return Comparison(before, after).run()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--before", required=True, type=Path)
    parser.add_argument("--after", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    options = parser.parse_args()
    try:
        result = compare(json.loads(options.before.read_text()), json.loads(options.after.read_text()))
    except (AssertionError, KeyError, StopIteration, ValueError) as error:
        result = {"status": "FAIL", "failure": str(error), "failure_type": type(error).__name__, "model_calls": 0}
    result["trace_files"] = {
        "before_sha256": hashlib.sha256(options.before.read_bytes()).hexdigest(),
        "after_sha256": hashlib.sha256(options.after.read_bytes()).hexdigest(),
    }
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("status", "session_stages", "native_stages", "failure") if key in result}, ensure_ascii=False))
    raise SystemExit(0 if result["status"] == "PASS" else 1)
