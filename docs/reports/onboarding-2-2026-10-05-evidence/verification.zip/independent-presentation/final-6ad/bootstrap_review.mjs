import {readFile,writeFile,mkdir,mkdtemp,copyFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root=process.argv[2];
const source=join(root,'loom/web/src/onboarding');
const raw=await readFile(join(source,'presentation.mjs'));
const canonical=JSON.parse(await readFile(join(source,'generated/ui.json'),'utf8'));
const directory=await mkdtemp(join(tmpdir(),'w12-review-broken-bootstrap-'));
const cases=[];
try {
 await mkdir(join(directory,'generated'));
 await copyFile(join(source,'presentation.mjs'),join(directory,'presentation.mjs'));
 const corrupt=structuredClone(canonical); delete corrupt.locales;
 await writeFile(join(directory,'generated/ui.json'),JSON.stringify(corrupt));
 const api=await import(pathToFileURL(join(directory,'presentation.mjs')).href);
 for (const [name, action] of [['valid supplied catalog with broken embedded bootstrap',()=>api.resolvePresentation(canonical)],['default catalog explicit error',()=>api.resolvePresentation()]]) {
  try { action(); cases.push({name,outcome:'unexpected success'}); }
  catch(error) { cases.push({name,error_name:error.name,code:error.code??null,machineOnly:error.machineOnly??null,message:error.message,typed:error instanceof api.PresentationError}); }
 }
} finally {await rm(directory,{recursive:true,force:true});}
console.log(JSON.stringify({schema:'w12.independent.bootstrap_negative/1',source_root:root,module_sha256:createHash('sha256').update(raw).digest('hex'),catalog_sha256:createHash('sha256').update(JSON.stringify(canonical)).digest('hex'),fault:'Synthetic isolated copy only: remove entire embedded.locales; production source unmodified.',cases,scope:'Pure helper; inferred React render consequence not a ReactDOM test.'},null,2));
