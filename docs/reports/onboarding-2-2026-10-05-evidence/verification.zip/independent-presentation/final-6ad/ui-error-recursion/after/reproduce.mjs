import assert from "node:assert/strict";
import { errorPresentation, formatTemplate, PresentationError } from "./presentation.mjs";
let failure;
try { formatTemplate("{{broken"); } catch (error) { failure = error; }
assert.ok(failure instanceof PresentationError);
assert.equal(failure.code, "error.template_syntax");
assert.equal(failure.message, "error.template_syntax");
assert.equal(failure.machineOnly, true);
assert.deepEqual(errorPresentation(failure), { text: "error.template_syntax", details: "error.template_syntax" });
console.log(JSON.stringify({ name: failure.name, code: failure.code, message: failure.message, machineOnly: failure.machineOnly }));
