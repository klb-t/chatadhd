import { formatTemplate } from "./presentation.mjs";
try { formatTemplate("{{broken"); console.error("UNEXPECTED_SUCCESS"); process.exitCode = 2; } catch (error) { console.error(error.stack); process.exitCode = 1; }
