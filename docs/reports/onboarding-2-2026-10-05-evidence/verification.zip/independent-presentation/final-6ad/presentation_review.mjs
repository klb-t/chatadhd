import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root = process.argv[2];
const paths = ['loom/web/src/onboarding/presentation.mjs','loom/web/src/onboarding/generated/ui.json','loom/data/onboarding/ui.pack'];
const hash = () => Object.fromEntries(paths.map(path => [path,createHash('sha256').update(readFileSync(`${root}/${path}`)).digest('hex')]));
const before = hash();
const api = await import(pathToFileURL(`${root}/loom/web/src/onboarding/presentation.mjs`));
const {resolvePresentation,message,formatTemplate,layerExplanation,errorPresentation,controlOrder,PresentationError} = api;
const canonical = JSON.parse(readFileSync(`${root}/loom/data/onboarding/ui.pack`,'utf8'));
let assertions = 0;
const equal = (a,b) => {assertions++; assert.deepEqual(a,b);};
const throws = (fn,code) => {assertions++; let failure; try {fn();} catch (error) {failure=error;} assert(failure instanceof PresentationError); assert.equal(failure.code,code); return failure;};
const cases=[];
function run(name,fn){const start=assertions;try{fn();cases.push({name,status:'PASS',assertions:assertions-start});}catch(error){cases.push({name,status:'FAIL',error:String(error)});}}
const base=resolvePresentation();
run('generated canonical data is authoritative',()=>{equal(base.pack,canonical);equal(base.locale,'en');equal(Object.keys(canonical.locales.en).sort(),Object.keys(canonical.locales.pl).sort());});
run('six independent English foundation explanations',()=>{
 const old={missing:'No current default or user value exists for this key.',excluded:'A durable user exclusion blocks this stable id across pack updates.',disabled:'The user retained this default but disabled its use.',user:'An explicit user value overrides the built-in graph layer.',proposal:'This new default touches an excluded area and awaits user acceptance.',builtin:'The built-in graph default applies because no user suppression or override exists.'};
 for(const [id,body] of Object.entries(old))equal(message(base,`layer.${id}`),body);
});
run('custom locale without algorithm edit and full resolution template parameters',()=>{
 const pack=structuredClone(canonical);pack.locales.zz=structuredClone(pack.locales.en);pack.default_locale='zz';pack.locales.zz['layer.builtin']='Revision {{revision}}; source={{source}}; previous={{explanation}}; value={{value}}';
 const p=resolvePresentation(pack);const resolution={key:'x',id:'x/v1',area:'example',layer:'builtin',status:'effective',revision:42,source:{z:2,a:1},value:777,explanation:'completed native prose'};
 equal(layerExplanation(p,{key:'x',id:'x/v1',area:'example',layer:'builtin',status:'effective',reason:'completed native prose',resolution}),'Revision 42; source={"a":1,"z":2}; previous=null; value=777');equal(p.locale,'zz');
});
run('disabled excluded missing proposed presentation never restores English',()=>{
 for(const status of ['disabled','excluded','missing','proposal']){
  const failure=throws(()=>resolvePresentation({available:false,status}),'error.presentation');equal(failure.message,'error.presentation');equal(errorPresentation(failure),{text:'error.presentation',details:'error.presentation'});
 }
});
run('explicit missing or broken supplied catalog has no implicit default',()=>{
 throws(()=>resolvePresentation(null),'error.presentation_invalid');throws(()=>resolvePresentation({available:true,status:'effective'}),'error.presentation_invalid');
 const pack=structuredClone(canonical);delete pack.locales.en['field.submit'];throws(()=>resolvePresentation(pack),'error.presentation_invalid');
 equal(resolvePresentation({available:true,status:'effective',value:canonical}).pack,canonical);
});
run('undeclared locale fails and empty locale uses data default',()=>{throws(()=>resolvePresentation(canonical,'undeclared'),'error.presentation_locale');equal(resolvePresentation(canonical,'').locale,'en');});
run('malformed and absent template parameters fail explicitly',()=>{
 for(const template of ['Hi {{field','Hi {{}}','Hi {{a{{b}}'])throws(()=>formatTemplate(template,{field:'x'}),'error.template_syntax');
 throws(()=>formatTemplate('{{absent}}',{}),'error.template_parameter');throws(()=>formatTemplate('{{x}}',[]),'error.template_parameters');
});
run('template replacements are inert canonical JSON and Unicode',()=>{equal(formatTemplate('value={{value}}; json={{json}}; unicode={{unicode}}',{value:'{{neverReparse}}',json:{z:1,a:['α',2]},unicode:'żółw'}),'value={{neverReparse}}; json={"a":["α",2],"z":1}; unicode=żółw');});
run('render presets allow high rows and empty choices without new restrictions',()=>{
 const pack=structuredClone(canonical);pack.defaults.mode='form';pack.defaults.rows.answer=100000;pack.defaults.modes=[];pack.defaults.preference_modes=[];pack.defaults.provider_separator='::';
 const p=resolvePresentation(pack);equal(p.defaults.mode,'form');equal(p.defaults.rows.answer,100000);equal(p.defaults.modes,[]);equal(p.defaults.preference_modes,[]);equal(p.defaults.provider_separator,'::');
});
run('control order is configurable and can remove existing controls',()=>{
 const pack=structuredClone(canonical);pack.defaults.control_order.field_status=['never','unknown'];const p=resolvePresentation(pack);
 equal(controlOrder(p,'field_status',{unknown:'U',declined:'D',never:'N'}),['never','unknown']);pack.defaults.control_order.field_status=[];
 equal(controlOrder(resolvePresentation(pack),'field_status',{unknown:'U'}),[]);
});
run('suppressed explanation remains null despite active UI locale',()=>{equal(layerExplanation(resolvePresentation(canonical,'pl'),{key:'x',reason:null,status:'effective',layer:'builtin'}),null);});
run('ordinary UI translates arbitrary native diagnostics without hidden English fallback',()=>{
 const p=resolvePresentation(canonical,'pl');const native=new Error('private diagnostic provider detail');const result=errorPresentation(native,p);
 equal(result.text,message(p,'error.failure'));equal(result.details,native.message);
 const typed=new PresentationError('error.native_type',{label:'profile',expectedType:'object'});const rendered=errorPresentation(typed,p);
 equal(rendered.text,message(p,'error.native_type',{label:'profile',expected:message(p,'type.object')}));
});
const after=hash();equal(after,before);
const output={schema:'w12.independent.presentation_review/1',source_root:root,synthetic_only:true,network_calls:0,message_counts:Object.fromEntries(Object.entries(canonical.locales).map(([locale,messages])=>[locale,Object.keys(messages).length])),cases,case_count:cases.length,assertions,source_hashes_before:before,source_hashes_after:after,verdict:cases.every(item=>item.status==='PASS')?'PASS':'FAIL',scope:'Pure presentation helpers only; no native core, rendered React DOM or full CTest verdict.'};
console.log(JSON.stringify(output,null,2));if(output.verdict!=='PASS')process.exitCode=1;
