"""Compile one probe against an already-built, frozen real kernel and capture raw JSON."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
PINNED_BASELINE = "3c0bc36552ef9851f1174946cfb108549aae3228"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_inventory(source: Path) -> dict[str, str]:
    result = {}
    for directory in ("loom/src", "loom/include", "loom/data"):
        for path in sorted((source / directory).rglob("*")):
            if path.is_file():
                result[str(path.relative_to(source))] = digest(path)
    return result


def database_inventory(directory: Path) -> dict[str, str]:
    return {str(path.relative_to(directory)): digest(path) for path in sorted(directory.rglob("*")) if path.is_file()}


def run(source: Path, build: Path, destination: Path, baseline: bool = False, production_revision: str | None = None,
        probe_file: str = "probe.cpp", mode: str | None = None, database_fixture: Path | None = None) -> dict:
    probe = HERE / probe_file
    if probe_file not in {"probe.cpp", "migration_probe.cpp"}:
        raise RuntimeError("choose the primary or migration evidence probe")
    if (probe_file == "migration_probe.cpp") != (mode in {"prepare", "migrate"}):
        raise RuntimeError("migration probe requires mode prepare or migrate; primary requires no mode")
    if (mode == "migrate") != (database_fixture is not None):
        raise RuntimeError("migration consumer requires actual retained BEFORE database fixture")
    probe_hash = digest(probe)
    revision = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
    if baseline and revision != PINNED_BASELINE:
        raise RuntimeError(f"baseline must be exact {PINNED_BASELINE}; got {revision}")
    inventory = source_inventory(source)
    if baseline and subprocess.check_output(["git", "-C", str(source), "status", "--porcelain"], text=True).strip():
        raise RuntimeError("pinned baseline source is dirty")
    pinned_production = PINNED_BASELINE if baseline else production_revision
    if not pinned_production:
        raise RuntimeError("provide --production-revision for the actual AFTER production pin")
    pinned_production = subprocess.check_output(["git", "-C", str(source), "rev-parse", pinned_production + "^{commit}"], text=True).strip()
    subprocess.run(["git", "-C", str(source), "merge-base", "--is-ancestor", pinned_production, "HEAD"], check=True, capture_output=True)
    # Later report/tool commits are fine; the actual production tree must still match the pin.
    subprocess.run(["git", "-C", str(source), "diff", "--exit-code", pinned_production, "--", "loom", "CMakeLists.txt"], check=True, capture_output=True)
    libraries = [build / name for name in ("libloom_core.a", "libloom_sqlite3_amalgamation.a", "libloom_miniz.a")]
    for library in libraries:
        if not library.is_file():
            raise RuntimeError(f"build the real kernel before probing: missing {library}")
    library_hashes = {path.name: digest(path) for path in libraries}
    fixture_hashes = database_inventory(database_fixture) if database_fixture else None
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="onboarding-parity-probe-") as temporary:
        executable = Path(temporary) / "probe"
        command = ["g++", "-std=c++20", "-g0", "-O0", "-Wall", "-Wextra", "-Werror",
                   "-I", str(source / "loom/include"), "-I", str(source / "loom/third_party/nlohmann"),
                   str(probe), *(str(path) for path in libraries),
                   "-pthread", "-ldl", "-lm", "-lssl", "-lcrypto", "-o", str(executable)]
        compiled = subprocess.run(command, capture_output=True, text=True)
        if compiled.returncode:
            raise RuntimeError(compiled.stdout + compiled.stderr)
        data_directory = Path(temporary) / "data"
        if database_fixture:
            shutil.copytree(database_fixture, data_directory)
        else:
            data_directory.mkdir()
        arguments = [mode, str(data_directory / "synthetic.db")] if mode else [str(data_directory)]
        completed = subprocess.run([str(executable), *arguments], cwd=temporary, capture_output=True)
        if completed.returncode:
            raise RuntimeError(completed.stderr.decode("utf-8", errors="replace"))
        json.loads(completed.stdout)
        executable_hash = digest(executable)
        if mode:
            if (destination / "database").exists():
                raise RuntimeError("retain the existing migration fixture; choose a new output directory")
            shutil.copytree(data_directory, destination / "database")
    if source_inventory(source) != inventory:
        raise RuntimeError("source changed while the parity probe was compiling/running")
    if digest(probe) != probe_hash:
        raise RuntimeError("evidence probe source changed while compiling/running")
    if {path.name: digest(path) for path in libraries} != library_hashes:
        raise RuntimeError("kernel libraries changed while the parity probe was compiling/running")
    if database_fixture and database_inventory(database_fixture) != fixture_hashes:
        raise RuntimeError("original BEFORE database fixture changed during migration consumer")
    (destination / "trace.json").write_bytes(completed.stdout)
    manifest = {
        "schema": "loom.onboarding_source_parity_manifest/1",
        "source_revision": revision, "production_revision": pinned_production, "pinned_baseline": baseline,
        "probe_file": probe_file, "probe_sha256": probe_hash, "executable_sha256": executable_hash,
        "libraries": library_hashes, "source_files": inventory,
        "trace_sha256": hashlib.sha256(completed.stdout).hexdigest(),
        "compile_options": ["-std=c++20", "-g0", "-O0", "-Wall", "-Wextra", "-Werror"],
        "network_calls": 0, "model_calls": 0,
        "scope": "Actual compiled probe linked to recorded real kernel libraries. Caller must freeze/rebuild the kernel first; hashes alone do not prove source-to-binary correspondence.",
    }
    if mode:
        manifest["mode"] = mode
        manifest["database_files"] = database_inventory(destination / "database")
        manifest["database_fixture_input"] = fixture_hashes
    (destination / "manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    return {"revision": revision, "trace_sha256": manifest["trace_sha256"], "source_files": len(inventory)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--build", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--baseline", action="store_true")
    parser.add_argument("--production-revision")
    parser.add_argument("--probe-file", default="probe.cpp")
    parser.add_argument("--mode", choices=("prepare", "migrate"))
    parser.add_argument("--database-fixture", type=Path)
    options = parser.parse_args()
    print(json.dumps(run(options.source.resolve(), options.build.resolve(), options.output.resolve(), options.baseline,
                         options.production_revision, options.probe_file, options.mode,
                         options.database_fixture.resolve() if options.database_fixture else None), sort_keys=True))
