// Link this identical offline program to the pinned BEFORE and actual AFTER
// kernels. BEFORE prepares a genuine SQLite fixture; AFTER consumes a copy.
// All content is synthetic, and preparing a model request makes no model call.
#include <filesystem>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "loom/db.h"
#include "loom/knowledge_store.h"
#include "loom/onboarding_layers.h"
#include "loom/onboarding_store.h"
#include "loom/sqlite.h"
#include "loom/util/sha256.h"

using loom::Json;
using namespace loom::onboarding;

namespace {
constexpr const char* kUser = "synthetic/source-migration-user";
constexpr const char* kProvider = "offline/source-migration-provider";
constexpr const char* kTime = "2000-01-01T00:00:00Z";
constexpr const char* kNode = "synthetic/unowned-legacy-node";
constexpr const char* kExcludedKey = "preference.length";
constexpr const char* kPresentationId = "onboarding.presentation/v1";

template <class T> T take(loom::Result<T> result) {
  if (!result) throw std::runtime_error(result.error().to_string());
  return std::move(result).value();
}
void check(loom::Status status) {
  if (!status) throw std::runtime_error(status.error().to_string());
}
void require(bool condition, const char* message) {
  if (!condition) throw std::runtime_error(message);
}
std::string hash(const Json& value) { return loom::Sha256::hex(loom::json::canonical(value)); }
Json outcome(loom::Result<Json> result) {
  if (result) return Json{{"ok", true}, {"value", std::move(result).value()}};
  return Json{{"ok", false}, {"error", {{"code", loom::errc_name(result.error().code)}, {"message", result.error().message}}}};
}
Json legacy() {
  return Json{{"legacy_extension", {{"schema", "synthetic/opaque-extension"},
      {"unknown", Json::array({nullptr, true, 17, "synthetic exact\n  bytes"})},
      {"nested", {{"future_key", "synthetic untouched"}}}}},
    {"graph", {{"nodes", {{kNode, {{"id", kNode}, {"kind", "synthetic/unowned"},
      {"opaque", Json::array({"preserve", nullptr, 9})}}}}}, {"edges", Json::array()}}}};
}
Json unrelated_inputs() { return Json{{"source", "synthetic/source-migration-sentinel"}}; }
std::string unrelated_id() {
  return loom::kb::KnowledgeRun::make_id("synthetic/source-migration-unrelated-pack", unrelated_inputs());
}
Json action(std::string op, std::string id, std::string field = "") {
  Json result{{"op", std::move(op)}, {"id", id}, {"time", kTime},
      {"source_refs", Json::array({"synthetic/" + id})}};
  if (!field.empty()) result["field"] = std::move(field);
  return result;
}
std::string identifier(std::string_view value) {
  std::string result = "\"";
  for (char c : value) { result += c; if (c == '"') result += '"'; }
  return result + '"';
}
// Preserve TEXT bytes (including stored JSON whitespace), SQL types, and all
// existing columns. Ordering by every column is deterministic for this fixture.
Json raw_rows(loom::sql::Connection& conn, const std::string& table,
              const std::optional<std::string>& run = std::nullopt) {
  const auto columns = conn.columns(table);
  require(!columns.empty(), "raw fixture table has no columns");
  std::string sql = "SELECT * FROM " + identifier(table);
  if (run) sql += " WHERE run_id=?";
  sql += " ORDER BY ";
  for (std::size_t i = 0; i < columns.size(); ++i) {
    if (i) sql += ',';
    sql += std::to_string(i + 1);
  }
  auto statement = take(conn.prepare(sql));
  if (run) statement.bind(1, *run);
  Json rows = Json::array();
  while (take(statement.step())) {
    Json row = Json::array();
    for (int i = 0; i < statement.column_count(); ++i) {
      const auto type = statement.column_type(i);
      Json cell{{"type", static_cast<int>(type)}, {"value", nullptr}};
      switch (type) {
        case loom::sql::Type::Integer: cell["value"] = statement.get_int(i); break;
        case loom::sql::Type::Float: cell["value"] = statement.get_double(i); break;
        case loom::sql::Type::Text: cell["value"] = statement.get_text(i); break;
        case loom::sql::Type::Blob: cell["value"] = statement.get_blob(i); break;
        case loom::sql::Type::Null: break;
      }
      row.push_back(std::move(cell));
    }
    rows.push_back(std::move(row));
  }
  return Json{{"columns", columns}, {"rows", std::move(rows)}};
}
Json knowledge_rows(loom::sql::Connection& conn, const std::string& run) {
  std::vector<std::string> tables;
  auto statement = take(conn.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name GLOB 'loom_kb_*' ORDER BY name"));
  while (take(statement.step())) tables.push_back(statement.get_text(0));
  Json result = Json::object();
  for (const auto& table : tables) {
    // Per-run data are scoped explicitly. Global append-only/schema/cache rows
    // are included unchanged in both captures and are never silently omitted.
    result[table] = conn.has_column(table, "run_id")
        ? raw_rows(conn, table, run) : raw_rows(conn, table);
  }
  return result;
}
Json capture(loom::sql::Connection& conn) {
  const auto raw = take(conn.query_text("SELECT body FROM loom_onboarding_profiles WHERE user_id=?", kUser));
  require(raw.has_value(), "synthetic migration user is missing");
  const auto state = take(loom::json::parse(*raw));
  const auto schema = take(conn.query_text("SELECT value FROM _meta WHERE key='schema_version'"));
  return Json{{"profile_body_bytes", *raw}, {"profile_body_sha256", loom::Sha256::hex(*raw)},
      {"stored_state", state}, {"onboarding_sql_rows", raw_rows(conn, "loom_onboarding_profiles")},
      {"onboarding_meta_sql_rows", raw_rows(conn, "loom_onboarding_meta")},
      {"core_schema", schema ? Json(*schema) : Json(nullptr)},
      {"core_sql_rows", {{"conversations", raw_rows(conn, "conversations")}, {"messages", raw_rows(conn, "messages")}}},
      {"native_graph_sql_rows", knowledge_rows(conn, state.at("graph_run_id").get<std::string>())},
      {"unrelated_knowledge_sql_rows", knowledge_rows(conn, unrelated_id())}};
}
Json effective(const Json& state, const char* key) {
  const auto layers = take(DefaultLayers::create(state.at("pack"), state.at("layers")));
  return take(layers.resolve(key));
}
void retained_fixture(const Json& state) {
  const auto& profile = state.at("profile");
  const auto& fields = profile.at("fields");
  require(fields.at("communication.style").at("status") == "known", "known form fact was lost");
  require(fields.at("communication.style").at("value") == "synthetic preserved form style", "known form value changed");
  require(fields.at("communication.style").at("provenance") == "form", "known form provenance changed");
  require(fields.at("identity.description").at("status") == "declined", "declined disposition was lost");
  require(fields.at("work.projects").at("status") == "never", "never disposition was lost");
  require(profile.at("legacy_extension") == legacy().at("legacy_extension"), "opaque legacy extension changed");
  require(profile.at("graph").at("nodes").at(kNode) == legacy().at("graph").at("nodes").at(kNode), "unowned graph node changed");
  const auto resolution = effective(state, kExcludedKey);
  require(resolution.at("status") == "excluded" && !resolution.contains("value"), "permanent length exclusion was restored");
}
void queries(loom::onboarding::OnboardingStore& store) {
  for (const auto& request : Json::array({
      Json{{"op", "ask"}, {"category", "identity"}, {"field", "identity.description"}},
      Json{{"op", "ask"}, {"category", "work"}, {"field", "work.projects"}},
      Json{{"op", "infer"}, {"category", "work"}, {"field", "work.projects"}, {"provenance", "model_inferred"}}})) {
    require(take(store.policy_decision(kUser, request)).at("allowed") == false, "protected disposition allowed ask/inference");
  }
}
Json prepare(const std::filesystem::path& path) {
  require(!std::filesystem::exists(path), "prepare refuses to overwrite a database");
  require(std::filesystem::is_directory(path.parent_path()), "explicit database parent directory is missing");
  require(take(builtin_pack()).at("revision") == 1, "prepare must run the pinned real BEFORE kernel with pack revision 1");
  loom::DbOptions options; options.enable_fts = false;
  auto db = take(loom::Database::open(path, options));
  const auto conversation = take(db->create_conv("Synthetic migration untouched conversation"));
  loom::NewMessage message; message.conv_id = conversation.id; message.role = "user";
  message.text = "Synthetic migration immutable sentinel\n  preserve exact bytes";
  message.metadata = Json{{"synthetic", true}, {"opaque", Json::array({nullptr, 1, "preserve"})}};
  take(db->create_msg(message));
  loom::kb::KnowledgeStore knowledge(*db);
  const auto unrelated = take(knowledge.begin_run("synthetic/source-migration-unrelated-pack", unrelated_inputs()));
  require(unrelated.id == unrelated_id(), "unrelated synthetic run identity changed");
  check(knowledge.finish_run(unrelated.id, "done", Json{{"synthetic", true}, {"unchanged", true}}));
  const auto core = Json{{"conversations", raw_rows(db->conn(), "conversations")}, {"messages", raw_rows(db->conn(), "messages")}};
  const auto unrelated_rows = knowledge_rows(db->conn(), unrelated_id());
  OnboardingStore store(*db);
  auto state = take(store.open(kUser, legacy()));
  auto apply = [&](const Json& command) { state = take(store.apply(kUser, state.at("revision").get<std::int64_t>(), command)); };
  auto form = action("answer", "migration-form", "communication.style");
  form["value"] = "synthetic preserved form style"; form["provenance"] = "form"; apply(form);
  auto confirmed = action("review", "migration-confirm-form"); confirmed["candidate"] = "migration-form"; confirmed["decision"] = "confirmed"; apply(confirmed);
  auto declined = action("status", "migration-declined", "identity.description"); declined["status"] = "declined"; apply(declined);
  auto never = action("status", "migration-never", "work.projects"); never["status"] = "never"; apply(never);
  auto exclusion = action("exclude", "migration-exclude-length"); exclusion["target"] = "layers"; exclusion["key"] = kExcludedKey; apply(exclusion);
  retained_fixture(state); queries(store);
  const auto fixture = capture(db->conn());
  require(fixture.at("core_sql_rows") == core, "fixture setup altered existing core rows");
  require(fixture.at("unrelated_knowledge_sql_rows") == unrelated_rows, "fixture setup altered unrelated knowledge rows");
  return Json{{"mode", "prepare"}, {"fixture", fixture}, {"prepared_model_request", outcome(store.model_request(kUser, kProvider))},
      {"invariants", {{"actual_builtin_pack_revision_1", true}, {"known_declined_never", true}, {"opaque_extension", true},
        {"unowned_graph_node", true}, {"permanent_length_exclusion", true}, {"existing_core_rows", true}, {"unrelated_knowledge_rows", true}}}};
}
Json migrate(const std::filesystem::path& path) {
  require(std::filesystem::is_regular_file(path), "migrate requires a copy of the real BEFORE database");
  const auto pack = take(builtin_pack()); const auto scenario = take(builtin_scenario());
  require(pack.at("revision") == 3, "migrate must run the actual AFTER kernel with pack revision 3");
  // Capture before even Database::open so its migrations cannot hide changes.
  loom::sql::OpenOptions read_options; read_options.create = false; read_options.read_only = true;
  auto raw_connection = take(loom::sql::Connection::open(path, read_options));
  const auto before = capture(raw_connection); raw_connection.close();
  const auto& old_state = before.at("stored_state");
  require(old_state.at("pack").at("revision") == 1 && old_state.at("layers").at("pack_revision") == 1,
      "consumed fixture is not the real installed revision-1 state");
  retained_fixture(old_state);
  loom::DbOptions options; options.enable_fts = false;
  auto db = take(loom::Database::open(path, options)); OnboardingStore store(*db);
  const auto opened = take(store.open(kUser)); const auto read = take(store.read(kUser));
  require(opened == read, "open/read returned different decorated snapshots");
  require(opened.at("pack") == old_state.at("pack") && opened.at("layers") == old_state.at("layers") &&
      opened.at("profile") == old_state.at("profile") && opened.at("revision") == old_state.at("revision"),
      "open/read implicitly changed installed defaults or profile");
  queries(store); const auto prepared = outcome(store.model_request(kUser, kProvider));
  const auto after_open = capture(db->conn());
  require(after_open == before, "AFTER open/read/request mutated raw BEFORE profile, graph or core rows");
  auto updated = take(store.update_pack(kUser, opened.at("revision").get<std::int64_t>(), pack, scenario));
  require(updated.at("pack") == pack && updated.at("layers").at("pack_revision") == 3,
      "explicit forward update did not install builtin revision 3");
  require(updated.at("revision").get<std::int64_t>() == old_state.at("revision").get<std::int64_t>() + 1,
      "explicit update did not increment the native CAS revision exactly once");
  retained_fixture(updated); queries(store);
  require(updated.at("profile").at("fields") == old_state.at("profile").at("fields"), "explicit update altered existing facts/dispositions");
  require(updated.at("profile").at("graph") == old_state.at("profile").at("graph"), "explicit update altered retained profile graph");
  // Unknown top-level extensions and all other profile members must remain
  // exact; operational policy history/revision are the documented additions.
  const auto& old_profile = old_state.at("profile"); const auto& new_profile = updated.at("profile");
  for (const auto& [key, value] : old_profile.items()) {
    if (key == "revision" || key == "history") continue;
    require(new_profile.contains(key) && new_profile.at(key) == value, "explicit update changed a retained profile member");
  }
  require(new_profile.size() == old_profile.size(), "explicit update unexpectedly added/removed profile members");
  require(new_profile.at("history").size() >= old_profile.at("history").size(), "explicit update truncated history");
  for (std::size_t i = 0; i < old_profile.at("history").size(); ++i)
    require(new_profile.at("history")[i] == old_profile.at("history")[i], "explicit update rewrote existing history");
  auto old_layers = old_state.at("layers"); auto new_layers = updated.at("layers");
  require(new_layers.at("catalog").size() == old_layers.at("catalog").size() + 1, "explicit update introduced unexpected default identities");
  require(new_layers.at("catalog").at(kPresentationId).at("first_pack_revision") == 3, "fresh presentation catalog has wrong first origin");
  require(new_layers.at("catalog").at(kPresentationId).at("entry").at("revision") == 2,
      "fresh presentation entry has wrong public forward revision");
  for (const auto& [id, record] : old_layers.at("catalog").items()) {
    require(record.at("first_pack_revision") == 1, "fixture catalog origin is not revision 1");
    require(new_layers.at("catalog").at(id) == record, "explicit update altered old default identity/origin");
  }
  require(new_layers.at("pack_fingerprint") == hash(pack), "explicit update pack fingerprint is wrong");
  new_layers["catalog"].erase(kPresentationId); new_layers["pack_revision"] = old_layers.at("pack_revision");
  new_layers["pack_fingerprint"] = old_layers.at("pack_fingerprint");
  require(new_layers == old_layers, "explicit update altered retained exclusion/overlay/layer metadata");
  const auto after_update = capture(db->conn());
  require(after_update.at("core_sql_rows") == before.at("core_sql_rows") && after_update.at("core_schema") == before.at("core_schema"),
      "explicit update altered existing core rows/schema");
  require(after_update.at("unrelated_knowledge_sql_rows") == before.at("unrelated_knowledge_sql_rows"),
      "explicit update altered unrelated knowledge rows");
  return Json{{"mode", "migrate"}, {"before_open", before}, {"after_open", after_open}, {"after_explicit_update", after_update},
      {"opened_snapshot", opened}, {"updated_snapshot", updated}, {"prepared_model_request", prepared},
      {"native_graph_sha256", {{"before_open", hash(before.at("native_graph_sql_rows"))},
        {"after_open", hash(after_open.at("native_graph_sql_rows"))}, {"after_explicit_update", hash(after_update.at("native_graph_sql_rows"))}}},
      {"invariants", {{"open_read_no_implicit_pack_upgrade", true}, {"raw_profile_bytes_unchanged_on_open", true},
        {"native_graph_sql_bytes_unchanged_on_open", true}, {"core_sql_bytes_unchanged_on_open", true},
        {"explicit_update_revision_1_to_3", true}, {"exact_existing_fields", true}, {"exact_unknown_extensions", true},
        {"exact_profile_graph", true}, {"existing_history_prefix", true}, {"permanent_length_exclusion", true},
        {"existing_catalog_origin_revision_1", true}, {"fresh_presentation_origin_revision_3", true},
        {"presentation_entry_public_revision_2", true},
        {"existing_core_rows", true}, {"unrelated_knowledge_rows", true}}}};
}
}  // namespace

int main(int argc, char** argv) {
  try {
    require(argc == 3, "pass prepare|migrate and one explicit SQLite database path");
    const std::string mode = argv[1]; require(mode == "prepare" || mode == "migrate", "unknown migration probe mode");
    Json report = mode == "prepare" ? prepare(argv[2]) : migrate(argv[2]);
    report["schema"] = "loom.onboarding_source_migration/1"; report["synthetic_only"] = true; report["model_calls"] = 0;
    std::cout << loom::json::canonical(report) << '\n'; return 0;
  } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 2; }
}
