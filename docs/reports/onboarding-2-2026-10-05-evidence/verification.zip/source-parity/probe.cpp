// One identical offline probe is linked against BEFORE and AFTER real kernels.
// All user content is synthetic. This program performs no network/model calls.
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <string>

#include "loom/db.h"
#include "loom/knowledge_store.h"
#include "loom/onboarding.h"
#include "loom/onboarding_store.h"

using loom::Json;
using namespace loom::onboarding;

namespace {
constexpr const char* kUser = "synthetic/source-parity-user";
constexpr const char* kProvider = "offline/source-parity-provider";
constexpr const char* kTime = "2000-01-01T00:00:00Z";

template <class T> T take(loom::Result<T> result) {
  if (!result) throw std::runtime_error(result.error().to_string());
  return std::move(result).value();
}
void check(loom::Status status) {
  if (!status) throw std::runtime_error(status.error().to_string());
}
void require(bool condition, const char* message) {
  if (!condition) throw std::runtime_error(message);
}
Json outcome(loom::Result<Json> result) {
  if (result) return Json{{"ok", true}, {"value", std::move(result).value()}};
  return Json{{"ok", false}, {"error", {{"code", loom::errc_name(result.error().code)}, {"message", result.error().message}}}};
}
Json action(std::string op, std::string id, std::string field = "") {
  Json result{{"op", std::move(op)}, {"id", id}, {"time", kTime}, {"source_refs", Json::array({"synthetic/" + id})}};
  if (!field.empty()) result["field"] = std::move(field);
  return result;
}
Json policy_requests() {
  return Json::array({
    Json{{"op", "ask"}, {"category", "identity"}, {"field", "identity.description"}},
    Json{{"op", "ask"}, {"category", "work"}, {"field", "work.projects"}},
    Json{{"op", "store"}, {"category", "communication"}, {"field", "communication.style"}, {"provenance", "form"}, {"detail", 1}, {"sensitivity", 1}},
    Json{{"op", "send"}, {"category", "communication"}, {"field", "communication.style"}, {"provider", kProvider}, {"detail", 1}, {"sensitivity", 1}},
    Json{{"op", "infer"}, {"category", "communication"}, {"field", "communication.length"}, {"provenance", "model_inferred"}},
    Json{{"op", "infer"}, {"category", "work"}, {"field", "work.projects"}, {"provenance", "model_inferred"}}
  });
}
Json decisions(const Json& state) {
  Json values = Json::array();
  for (const auto& request : policy_requests()) values.push_back(Json{{"request", request}, {"result", outcome(privacy_decision(state, request))}});
  return values;
}
Json graph_rows(loom::Database& db, const std::string& run) {
  Json graph = Json::object();
  for (const auto& [kind, table] : {std::pair{"entities", "loom_kb_entities"},
      std::pair{"claims", "loom_kb_claims"}, std::pair{"observations", "loom_kb_observations"}}) {
    auto statement = take(db.conn().prepare(std::string("SELECT body FROM ") + table + " WHERE run_id=? ORDER BY id"));
    statement.bind(1, run);
    graph[kind] = Json::array();
    while (take(statement.step())) graph[kind].push_back(take(loom::json::parse(statement.get_text(0))));
  }
  return graph;
}
Json session_trace(const Json& scenario, const Json& defaults) {
  auto session = take(ProfileSession::create(scenario, defaults));
  Json trace = Json::object();
  auto record = [&](const char* stage) {
    const auto snapshot = session.snapshot();
    const auto request = outcome(session.model_request(kProvider));
    const auto policy = decisions(snapshot);
    trace[stage] = Json{{"snapshot", snapshot}, {"request", request}, {"policy", policy},
      {"snapshot_bytes", loom::json::dump(snapshot)}, {"request_bytes", loom::json::dump(request)}, {"policy_bytes", loom::json::dump(policy)}};
  };
  record("00-default");
  auto form = action("answer", "form-style", "communication.style"); form["value"] = "synthetic direct style"; form["provenance"] = "form";
  take(session.dispatch(form)); record("01-form-candidate");
  auto confirm = action("review", "confirm-form"); confirm["candidate"] = "form-style"; confirm["decision"] = "confirmed";
  take(session.dispatch(confirm)); record("02-form-confirmed");
  auto declined = action("status", "decline-identity", "identity.description"); declined["status"] = "declined";
  take(session.dispatch(declined)); record("03-declined");
  auto never = action("status", "never-work", "work.projects"); never["status"] = "never";
  take(session.dispatch(never)); record("04-never");
  auto repeated = action("repeat", "repeat-communication"); repeated["section"] = "communication";
  take(session.dispatch(repeated));
  const auto request = take(session.model_request(kProvider));
  // Saved synthetic summary: no inferred personal facts or provider execution.
  const Json reply{{"provider", request["provider"]}, {"request_token", request["request_token"]}, {"section", request["section"]},
      {"summary", "Synthetic form style recorded. Confirm or correct this summary."}, {"questions", Json::array()}, {"candidates", Json::array()}};
  take(session.ingest_model_reply(reply)); record("05-saved-summary");
  take(session.dispatch(action("pause", "pause"))); record("06-paused");
  take(session.dispatch(action("resume", "resume"))); record("07-resumed");
  auto erase = action("delete", "delete-style", "communication.style"); erase["purge_history"] = true;
  take(session.dispatch(erase)); record("08-deleted");
  const auto restored = take(ProfileSession::create(scenario, defaults, session.snapshot()));
  require(restored.snapshot() == session.snapshot(), "ProfileSession recreation changed state");
  return trace;
}
Json store_trace(const std::filesystem::path& data_directory) {
  require(std::filesystem::is_directory(data_directory), "explicit temporary data directory unavailable");
  const auto db_path = data_directory / "synthetic.db";
  loom::DbOptions options; options.enable_fts = false;
  auto db = take(loom::Database::open(db_path, options));
  const auto core_schema = take(db->schema_version());
  const auto conversation = take(db->create_conv("Synthetic untouched conversation"));
  loom::NewMessage message; message.conv_id = conversation.id; message.role = "user";
  message.text = "Synthetic immutable sentinel\n  preserve exact bytes";
  message.metadata = Json{{"sentinel", Json::array({1, nullptr, "keep"})}};
  const auto message_id = take(db->create_msg(message));
  const auto old_conversation = take(db->get_conv(conversation.id))->to_json();
  const auto old_message = take(db->get_msg(message_id))->to_json();
  loom::kb::KnowledgeStore knowledge(*db);
  const auto unrelated = take(knowledge.begin_run("synthetic/unrelated-pack", Json{{"source", "synthetic/unchanged"}}));
  check(knowledge.finish_run(unrelated.id, "done", Json{{"synthetic", true}}));
  const auto old_run = take(knowledge.get_run(unrelated.id))->to_json();
  OnboardingStore store(*db);
  Json state = take(store.open(kUser));
  Json trace = Json::object();
  auto record = [&](const char* stage) {
    Json policies = Json::array();
    for (const auto& request : policy_requests()) policies.push_back(Json{{"request", request}, {"result", outcome(store.policy_decision(kUser, request))}});
    const auto request = outcome(store.model_request(kUser, kProvider));
    trace[stage] = Json{{"snapshot", state}, {"request", request}, {"policy", policies},
      {"profile_bytes", loom::json::dump(state.at("profile"))}, {"request_bytes", loom::json::dump(request)},
      {"stored_graph", graph_rows(*db, state.at("graph_run_id").get<std::string>())}};
    require(take(db->get_conv(conversation.id))->to_json() == old_conversation, "onboarding changed an existing conversation");
    require(take(db->get_msg(message_id))->to_json() == old_message, "onboarding changed an existing message");
    require(take(knowledge.get_run(unrelated.id))->to_json() == old_run, "onboarding changed an unrelated knowledge run");
    require(take(db->schema_version()) == core_schema, "onboarding changed the core schema version");
  };
  auto apply = [&](const Json& command) { state = take(store.apply(kUser, state.at("revision").get<std::int64_t>(), command)); };
  record("00-default");
  auto form = action("answer", "native-form-style", "communication.style"); form["value"] = "synthetic native style"; form["provenance"] = "form";
  apply(form); record("01-form-candidate");
  auto confirm = action("review", "native-confirm-form"); confirm["candidate"] = "native-form-style"; confirm["decision"] = "confirmed";
  apply(confirm); record("02-form-confirmed");
  auto declined = action("status", "native-decline", "identity.description"); declined["status"] = "declined";
  apply(declined); record("03-declined");
  auto never = action("status", "native-never", "work.projects"); never["status"] = "never";
  apply(never); record("04-never");
  auto repeated = action("repeat", "native-repeat"); repeated["section"] = "communication";
  apply(repeated); record("05-repeated");
  auto rule = state.at("profile").at("privacy").at("rules")[0];
  rule["id"] = "synthetic-communication-consent"; rule["category"] = "communication";
  rule["provenance"] = "user_stated"; rule["consent_event"] = "synthetic/explicit-consent";
  rule["providers"] = Json::array({kProvider}); rule["infer"] = true; rule["explicit_only"] = false;
  rule["retention"]["history"] = "metadata";
  auto privacy = action("privacy", "native-privacy"); privacy["rule"] = rule;
  apply(privacy); record("06-privacy");
  auto proposal = action("propose", "native-derived-length", "communication.length"); proposal["value"] = "synthetic inferred candidate";
  proposal["provenance"] = "model_inferred"; apply(proposal); record("07-inferred-candidate");
  auto reject = action("review", "native-reject"); reject["candidate"] = "native-derived-length"; reject["decision"] = "rejected";
  apply(reject); record("08-rejected");
  auto erase = action("delete", "native-delete-style", "communication.style"); erase["purge_history"] = true;
  apply(erase); record("09-deleted");
  auto exclude = action("exclude", "native-exclude-method"); exclude["target"] = "layers"; exclude["key"] = "method.onboarding";
  apply(exclude); record("10-method-excluded");
  const auto saved = state;
  db.reset();
  auto restored_db = take(loom::Database::open(db_path, options));
  OnboardingStore restored(*restored_db);
  const auto restored_state = take(restored.open(kUser));
  require(restored_state == saved, "native persistence/restart changed the snapshot");
  const auto restored_request = outcome(restored.model_request(kUser, kProvider));
  trace["11-restarted"] = Json{{"snapshot", restored_state}, {"request", restored_request},
      {"profile_bytes", loom::json::dump(restored_state.at("profile"))}, {"request_bytes", loom::json::dump(restored_request)},
      {"stored_graph", graph_rows(*restored_db, restored_state.at("graph_run_id").get<std::string>())}};
  return trace;
}
}  // namespace

int main(int argc, char** argv) {
  try {
    require(argc == 2, "pass one explicit temporary data directory");
    const auto pack = take(builtin_pack());
    const auto scenario = take(builtin_scenario());
    Json report{{"schema", "loom.onboarding_source_parity/1"}, {"synthetic_only", true}, {"model_calls", 0},
      {"pack", pack}, {"scenario", scenario}, {"session", session_trace(scenario, pack.at("runtime_definition").at("defaults"))},
      {"native", store_trace(argv[1])}, {"within_run_invariants", Json{{"core_schema", true}, {"existing_conversation", true},
         {"existing_message", true}, {"unrelated_run", true}, {"session_recreation", true}, {"native_restart", true}}}};
    std::cout << loom::json::canonical(report) << '\n';
    return 0;
  } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 2; }
}
