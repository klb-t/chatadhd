# W12 source parity probe

The same `probe.cpp` is compiled against the exact previous W12 foundation
`3c0bc36552ef9851f1174946cfb108549aae3228` and the final composed main plus this
increment. It calls the real `ProfileSession`, `OnboardingStore`, `DefaultLayers`
and `KnowledgeStore` APIs. Inputs, provider name, consent and replies are synthetic.
There are no network or model calls. Run only after the validator confirms that
the kernel libraries correspond to frozen source; the runner records source and
library hashes but hashes alone do not establish how a binary was built.

`run_probe.py` uses an explicit temporary SQLite data directory and a temporary
working directory outside either source tree. It checks that the baseline is
pristine at the pinned revision and that source/library bytes do not change
during the run. The complete unmodified probe stdout is retained in `trace.json`.
`manifest.json` records its raw SHA-256, source inventory, libraries, executable,
probe and compilation options. Neither the runner nor the comparator calls a
build or modifies production source.

```sh
python3 -B run_probe.py --baseline --source /tmp/w12-before-source \
  --build /tmp/w12-before-build --output ./before
python3 -B run_probe.py --production-revision 6adbf2ad00671da40a356b922a8c1a8091b1e5ea \
  --source /path/to/final-composed-source \
  --build /path/to/final-composed-build --output ./after
python3 -B compare.py --before ./before/trace.json --after ./after/trace.json \
  --output ./comparison.json
python3 -B -m unittest -v test_compare.py
```

The probe records nine standalone session stages and twelve persistent native
stages. They cover fresh defaults, form confirmation, `declined`, `never`, repeat,
synthetic saved summary, pause/resume, explicit provider/inference consent,
candidate rejection, deletion with history purge, permanent method exclusion and
database restart. Six privacy requests are evaluated at each applicable stage.
Each native stage reads the actual persisted entity, claim and observation
bodies. Existing conversation/message bytes, an unrelated knowledge run and the
core schema are checked inside the process; their random ids and wallclock dates
are omitted from output. Session recreation and native restart must preserve
their complete snapshots within each run.

## Exact checks and permitted additions

| Payload | Comparison |
| --- | --- |
| Interview scenario and all prior expanded pack entry values | Exact JSON equality |
| Standalone session snapshots, requests and privacy decisions | Exact JSON equality and original serialized JSON bytes |
| Native profile snapshots and prepared requests | Exact JSON equality and original serialized JSON bytes |
| Native privacy decisions | Exact except the resolution's explicit pack lineage revision |
| Existing native graph rows | Complete body equality after the specific pack lineage source transform below |
| Complete raw native graphs | Retained and hashed individually; expected to differ |

Only these additions are allowed:

- Pack top revision `1` becomes `3`, and the pack gains `presentation_key` equal
  to `presentation.onboarding` and one entry `onboarding.presentation/v1`, area
  `onboarding/presentation`, entry revision `2`, with a
  `loom.onboarding.presentation/1` catalog value. Removing these changes must
  recover the entire old expanded pack. Runtime bindings and expanded runtime
  defaults must stay identical. Pack `2` / presentation `1` was a public source
  checkpoint; the final CSS token addition uses forward revisions instead of
  recycling those published identities.
- Layer state gains exactly that catalog record and its fingerprint changes to
  the verified canonical SHA-256 of the new pack. The old catalog contents,
  overrides, history and policy remain exact.
- Decorated native state gains exactly that effective default and a matching
  `presentation` inspection envelope. Its resolver value and source are checked.
- Every persisted native graph gains exactly one presentation default entity,
  four standard default claims (`has_default`, `has_state`, `has_value`,
  `from_layer`) and one captured resolution source. The complete entity, edge
  targets, claim metadata and supports are checked against the existing native
  default projection shape. No unknown graph additions are discarded.

Pack revision metadata may change only at explicit layer record fields:
`pack_revision`, catalog `first_pack_revision`, disabled/exclusion
`pack_revision`, area `excluded_at_pack_revision`, proposal
`created_pack_revision`; and a built-in, disabled, excluded or proposed
resolution's source revision. User values and arbitrary nested keys with these
names remain exact. Existing default/layer/exclusion entity attributes use these
same scoped transforms. Captured default resolution source text changes with
that explicit metadata, so its byte length, SHA-256 locator, native unit id and
native observation id necessarily change. The comparator first verifies each
actual raw capture and id, then computes the corresponding normalized identity;
claim supports must reference the exact actual source quote and locator before
that accounting transform. It does not omit support or whole graph objects.

`test_compare.py` contains twenty-five independent synthetic checks of the
comparator, including rejection of changed profile, prompt, policy, unknown
snapshot/graph additions and duplicate identities, wrong presentation edge or support, forged source/id,
boolean/number substitution, and business values named `pack_revision`.
These tests validate the accounting tool; they are not native behavior evidence.
The actual before/after run is reported separately in `comparison.json` only
after both compiled probes have completed.

`independent-review/` retains the reviewer-authored mutation runner and both
results, including the initial failed accounting checks and the fixed rerun.
The final independent result rejects all five adversarial inputs and names the
exact comparator SHA-256 tested. This evidence also concerns the comparison
tool only, rather than native application behavior.
The final actual-shape rerun rejects five synthetic mutations. A separate
reviewer-authored check using the real default-stage traces passes its positive
control and rejects ten malformed variants; raw input and comparator hashes
are recorded in `actual-trace-accounting-review.json`. These accounting checks
have separate denominators from the native stages and full CTest.

## Actual old-user migration fixture

`migration_probe.cpp` is a second, identical-source producer/consumer probe.
The producer is compiled against the pinned real BEFORE kernel, opens a fresh
synthetic user using the legitimate legacy input, confirms a form value, marks
another field `declined` and another `never`, and permanently excludes
`preference.length`. It retains an opaque extension and an unowned profile
graph node. Its SQLite database is retained before temporary cleanup; the runner
records hashes for every database file. The fixture does not manufacture a
revision-1 pack or downgrade an AFTER-created database.

The final same-source fixture is
`migration-before-final-pack3/database/synthetic.db`. Its producer checks seven
invariants. The earlier genuine fixture created while the planned consumer
target was revision 2 is retained as historical evidence; it is excluded from
the final same-source migration result. The final producer/consumer source
SHA-256 is `99f95d97e4a10f6ce348d0ef73e3f45af502cfb9ca8e764067ebdecff23e637e`.

```sh
python3 -B run_probe.py --baseline --source /tmp/w12-before-source \
  --build /tmp/w12-before-build --probe-file migration_probe.cpp --mode prepare \
  --output ./migration-before-final-pack3
python3 -B run_probe.py --production-revision 6adbf2ad00671da40a356b922a8c1a8091b1e5ea \
  --source /path/to/final-composed-source --build /path/to/final-composed-build \
  --probe-file migration_probe.cpp --mode migrate \
  --database-fixture ./migration-before-final-pack3/database --output ./migration-after
```

The consumer operates on a copy. Before even `Database::open`, it captures typed
SQL cells, original JSON body strings, native knowledge tables, existing core
conversation/message rows and an unrelated knowledge run. AFTER `open`, `read`,
privacy queries and a prepared model request must leave all of those bytes
unchanged and keep installed pack 1. Only explicit `update_pack` may install
pack 3. Existing fields, dispositions, opaque extensions, profile graph, previous
history and exclusion records must survive. Old catalog entries retain first
origin 1; the presentation entry first appears at 3 with entry revision 2. Core
rows/schema and the unrelated knowledge run remain exact. "SQL bytes" means
typed cell values and body text; it does not assert physical SQLite page
identity. The runner checks that the original retained fixture remains untouched.
The final consumer result is recorded only after linking to the actual AFTER
kernel.

## Final compiled result

`results-final-pack3.json` binds the pinned BEFORE and final AFTER
`6adbf2ad00671da40a356b922a8c1a8091b1e5ea` to the recorded library, probe,
database and trace hashes. `comparison-final-pack3.json` passes for nine session
and twelve native stages, twenty-one prepared requests and 120 privacy decisions.
It compares 1,560 existing entities, 2,090 existing claims and 352 sources across
the native stages after only the documented source-lineage transform. Each of
the twelve complete raw graphs differs by the declared presentation addition.
Their raw equality is explicitly false.

The actual retained-database consumer passes all fifteen invariants: opening
with AFTER leaves installed pack 1 and all captured raw rows unchanged; explicit
update to 3 preserves the user's data and durable exclusion. Both migration
executables were compiled from source SHA-256 `99f95d97…637e`. The original
retained database still hashes to
`d3f74be8cba0d8005ea64ecba863ee627212bce1c5a679c9716370cc7f5e5c32`.

The first actual comparison exposed two incorrect synthetic accounting shapes:
the privacy envelope wraps `resolution`, and native supports live under
`assessment.basis.support`. Those initial negative JSON results are retained,
as is the exact pre-correction comparator snapshot. Correcting those DTO paths
does not broaden the allowed metadata differences. The final synthetic fixture
uses both actual wrappers, with explicit empty-support regression cases.
The twenty-five accounting tests pass. Full CTest and the complete build-source
closure remain separate validator results; this report makes no substitute claim
for them. All probes use synthetic data and make zero model/network calls.

The final full-test source pin is
`6ea0772654736ac08c34743295beef27d9115d58`. Its only delta from the compiled
production pin is explicit RHS string extraction in two CHECK expressions in
`test_onboarding_presentation.cpp`; their equality assertions are preserved.
`kernel-closure/test-only-fix-source-closure.json` records that production
source/include/data and the actual kernel hashes remain unchanged. The existing
compiled trace manifests stay bound to production `6adbf2ad…e5ea`; this later
test-only commit is recorded separately rather than relabeling their provenance.
