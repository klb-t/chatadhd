#!/usr/bin/env python3
"""Capture closed, offline native/data inputs without reading evaluation data."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True)
parser.add_argument('--build', required=True)
parser.add_argument('--pin', required=True)
parser.add_argument('--production-pin', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--allow-web-differences', action='store_true')
args = parser.parse_args()
source, build = Path(args.source).resolve(), Path(args.build).resolve()
def git(*values):
    return subprocess.check_output(['git', '-C', str(source), *values], text=True).strip()
subprocess.run(['git', '-C', str(source), 'merge-base', '--is-ancestor', args.pin, 'HEAD'], check=True)
changed_paths = git('diff', '--name-only', args.pin, '--', 'loom').splitlines()
if changed_paths and not (args.allow_web_differences and all(path.startswith('loom/web/') for path in changed_paths)):
    raise SystemExit('Changed source inputs relative to pin: ' + str(changed_paths))
untracked = git('ls-files', '--others', '--exclude-standard', '--', 'loom')
if untracked:
    raise SystemExit('Untracked loom inputs: ' + untracked)
entries = json.loads((build / 'compile_commands.json').read_text())
paths = {Path(entry['file']).resolve() for entry in entries}
for relative in ('loom/include', 'loom/src', 'loom/third_party'):
    paths.update(path.resolve() for path in (source / relative).rglob('*')
                 if path.is_file() and path.suffix in ('.h', '.hpp', '.inc'))
for relative in ('loom/data/onboarding', 'loom/data/profiles'):
    paths.update(path.resolve() for path in (source / relative).rglob('*') if path.is_file())
paths.update((source / relative).resolve() for relative in
             ('loom/CMakeLists.txt', 'loom/cli/CMakeLists.txt', 'loom/server/CMakeLists.txt'))
hashes = {str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in sorted(paths)}
manifest_sha = hashlib.sha256(json.dumps(hashes, sort_keys=True,
                                         separators=(',', ':')).encode()).hexdigest()
result = {'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'production_test_pin': args.pin, 'production_only_pin': args.production_pin,
          'head_at_capture': git('rev-parse', 'HEAD'),
          'allowed_dirty_web_paths_outside_native_inputs': changed_paths,
          'loom_tree_at_pin': git('rev-parse', args.pin + ':loom'),
          'loom_tree_at_capture_head': git('rev-parse', 'HEAD:loom'), 'source': str(source),
          'build': str(build), 'input_count': len(hashes), 'manifest_sha256': manifest_sha,
          'sha256': hashes}
Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: result[key] for key in ('head_at_capture', 'input_count', 'manifest_sha256')}))
