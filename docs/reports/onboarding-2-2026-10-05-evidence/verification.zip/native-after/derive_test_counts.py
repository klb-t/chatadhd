#!/usr/bin/env python3
"""Derive executed counts from untruncated CTest evidence, never inventory alone."""
import argparse
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
parser = argparse.ArgumentParser()
parser.add_argument('--folder', required=True)
args = parser.parse_args()
folder = Path(args.folder)
raw = (folder / 'ctest-full-final-LastTest.txt').read_text()
inventory = json.loads((folder / 'ctest-inventory.json').read_text())
expected = [entry['name'] for entry in inventory['tests']]
parts = re.split(r'^\d+/\d+ Testing: (.*?)\n', raw, flags=re.M)
records = []
for name, body in zip(parts[1::2], parts[2::2]):
    output = body.split('Output:\n----------------------------------------------------------\n', 1)[1].split('<end of output>', 1)[0]
    entry = {'ctest_name': name, 'passed': '\nTest Passed.\n' in body}
    if name.startswith('unit.'):
        cases = re.search(r'\[doctest\] test cases:\s*(\d+)\s*\|\s*(\d+) passed\s*\|\s*(\d+) failed', output)
        assertions = re.search(r'\[doctest\] assertions:\s*(\d+)\s*\|\s*(\d+) passed\s*\|\s*(\d+) failed', output)
        assert cases and assertions, (name, output)
        entry.update(kind='native_doctest', executed_cases=int(cases[1]),
                     passed_cases=int(cases[2]), failed_cases=int(cases[3]),
                     assertions=int(assertions[1]), failed_assertions=int(assertions[3]))
    else:
        ran = re.findall(r'Ran (\d+) tests? in ([0-9.]+)s', output)
        skips = re.findall(r'OK \(skipped=(\d+)\)', output)
        if ran:
            entry.update(kind='python_unittest', reported_cases=sum(int(item[0]) for item in ran),
                         skipped_cases=sum(int(item) for item in skips))
        else:
            assert name in ('server.smoke', 'cli.smoke'), (name, output)
            assert 'SKIP' not in output and ('all loom-server smoke checks passed' in output or 'cli smoke: ok' in output), (name, output)
            entry.update(kind='python_smoke_script', reported_cases=None,
                         count_note='Executed script success; no unittest case denominator.')
    records.append(entry)
xml = ET.parse(folder / 'ctest-full-final.xml').getroot()
log = (folder / 'ctest-full-final.txt').read_text()
elapsed = float(re.search(r'Total Test time \(real\) =\s*([0-9.]+) sec', log)[1])
native = [entry for entry in records if entry['kind'] == 'native_doctest']
python = [entry for entry in records if entry['kind'] == 'python_unittest']
onboarding = [entry for entry in native if '.test_onboarding' in entry['ctest_name']]
count = int(re.search(r'unskipped test cases passing the current filters:\s*(\d+)',
                      (folder / 'doctest-final-count.txt').read_text())[1])
assert sorted(entry['ctest_name'] for entry in records) == sorted(expected)
assert all(entry['passed'] for entry in records)
assert sum(entry['executed_cases'] for entry in native) == count
assert int(xml.attrib['failures']) == 0
result = {'ctest_entries': len(records), 'ctest_failures': int(xml.attrib['failures']),
          'ctest_skipped_statuses': int(xml.attrib['skipped']), 'ctest_elapsed_seconds': elapsed,
          'native_source_entries': len(native),
          'native_executed_cases': sum(entry['executed_cases'] for entry in native),
          'native_assertions': sum(entry['assertions'] for entry in native),
          'native_failed_cases': sum(entry['failed_cases'] for entry in native),
          'native_failed_assertions': sum(entry['failed_assertions'] for entry in native),
          'native_unskipped_count_query': count,
          'native_zero_case_entries': [entry['ctest_name'] for entry in native if entry['executed_cases'] == 0],
          'native_opt_in_note': 'The opt-in catalog scale source executes zero cases by default; the ~1 GB slow corpus case was not opted in.',
          'onboarding_native_cases': sum(entry['executed_cases'] for entry in onboarding),
          'onboarding_native_assertions': sum(entry['assertions'] for entry in onboarding),
          'onboarding_suites': onboarding,
          'python_unittest_entries': len(python),
          'python_unittest_reported_cases': sum(entry['reported_cases'] for entry in python),
          'python_unittest_skipped_cases': sum(entry['skipped_cases'] for entry in python),
          'python_non_unittest_smoke_entries': [entry['ctest_name'] for entry in records if entry['kind'] == 'python_smoke_script'],
          'count_evidence': 'Full untruncated Testing/Temporary/LastTest.log copied to ctest-full-final-LastTest.txt; JUnit stdout truncation is not used for case denominators.',
          'entries': records}
(folder / 'executed-test-counts.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ('entries', 'onboarding_suites')}, indent=2))
