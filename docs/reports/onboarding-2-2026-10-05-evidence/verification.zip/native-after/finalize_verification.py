#!/usr/bin/env python3
"""Close an already completed gate against source bytes and actual raw counts."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

folder = Path('/tmp/w12-after-verification-2026-10-05')
source = Path('/workspace/scratch/4db3ee41b13b/chatadhd')
manifest = json.loads((folder / 'source-inputs-final.json').read_text())
changed, missing = [], []
for relative, expected in manifest['sha256'].items():
    path = source / relative
    if not path.is_file():
        missing.append(relative)
    elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        changed.append(relative)
assert not changed and not missing
subprocess.run(['git', '-C', str(source), 'merge-base', '--is-ancestor', manifest['production_test_pin'], 'HEAD'], check=True)
subprocess.run(['git', '-C', str(source), 'diff', '--quiet', manifest['production_test_pin'], '--', 'loom'], check=True)
untracked = subprocess.check_output(['git', '-C', str(source), 'ls-files', '--others', '--exclude-standard', '--', 'loom'], text=True).strip()
assert not untracked
head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
comparison = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'source_test_pin': manifest['production_test_pin'], 'production_only_pin': manifest['production_only_pin'],
              'head_at_check': head, 'compared_inputs': manifest['input_count'],
              'manifest_sha256': manifest['manifest_sha256'], 'changed': changed, 'missing': missing,
              'untracked_loom_inputs': [], 'whole_loom_diff_to_gate_pin': [], 'identical': True,
              'loom_tree_at_gate_pin': subprocess.check_output(['git', '-C', str(source), 'rev-parse', manifest['production_test_pin'] + ':loom'], text=True).strip(),
              'loom_tree_at_checked_head': subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD:loom'], text=True).strip()}
(folder / 'source-inputs-after-full-gate.json').write_text(json.dumps(comparison, indent=2) + '\n')
counts = json.loads((folder / 'executed-test-counts.json').read_text())
build = json.loads((folder / 'build-verdict.json').read_text())
assert counts['ctest_entries'] == 125 and counts['ctest_failures'] == 0
assert counts['native_executed_cases'] == counts['native_unskipped_count_query']
verdict = {'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'status': 'PASS', 'build_exit_code': 0, 'ctest_exit_code': 0,
           'source_test_pin': manifest['production_test_pin'], 'production_only_pin': manifest['production_only_pin'],
           'source_comparison': comparison, 'source_input_count': manifest['input_count'],
           'source_manifest_sha256': manifest['manifest_sha256'],
           'build_command': '/root/.local/bin/cmake --build /tmp/w12-after-build -j4',
           'ctest_command': 'env -u PYTHONPATH /root/.local/bin/ctest --test-dir /tmp/w12-after-build --output-on-failure -j2 --output-junit /tmp/w12-after-verification-2026-10-05/ctest-full-final.xml',
           'configuration': 'Ninja Debug -g0 -O0; WERROR, static/shared, CLI, server, tests ON; bundled SQLite 3.47.2; OpenSSL ON.',
           'baseline_source_pin': '3c0bc36552ef9851f1174946cfb108549aae3228',
           'baseline_core_shared_cli_server_build_exit_code': 0,
           'old_baseline_full_ctest_repeated': False,
           'mixed_base_acceptance_note': 'This gate verifies the actual mixed W12 branch. It does not independently declare W5 accepted by the integrator.',
           'no_thresholds_or_gates_relaxed': True,
           'generator_check': json.loads((folder / 'builtin-generated-check.json').read_text()),
           'historical_negative_statuses': {
               'build-presentation-test-type-negative.txt': 'COMPILE_FAIL exit 1; two typed JSON RHS fixes, equality assertions unchanged.',
               'ctest-onboarding-pack3-fixture-negative.txt': 'FAIL exit 8, 7/8 entries passed; two graph fixture upgrades incorrectly used revision 2 after the public pack advanced to 3.',
               'ctest-graph-pack-revision-fix.txt': 'PASS exit 0, graph 11 cases / 2172 assertions; fixture revisions now increment relative to current, semantic assertions unchanged.'},
           'intentional_builder_interruptions': {
               'build-initial-j2-interrupted-resource-recovery.txt': 'exit 130; parent-authorized increase to -j4 after resource recovery.',
               'build-j4-interrupted-parity-window.txt': 'exit 130; serialize real AFTER primary and retained SQLite consumer probes.'},
           'artifacts': build['artifacts'], **counts}
artifact_changes = [name for name, values in build['artifacts'].items()
                    if hashlib.sha256((Path('/tmp/w12-after-build') / name).read_bytes()).hexdigest() != values['sha256']]
assert not artifact_changes
verdict['compiled_artifacts_after_full_ctest_changed'] = artifact_changes
receipt_file = folder / 'migration-consumer-final-receipt.json'
if receipt_file.is_file():
    verdict['retained_sqlite_migration'] = json.loads(receipt_file.read_text())
(folder / 'final-verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')
print(json.dumps({key: verdict[key] for key in ('status', 'source_test_pin', 'production_only_pin', 'source_input_count', 'source_manifest_sha256', 'ctest_entries', 'ctest_elapsed_seconds', 'native_executed_cases', 'native_assertions', 'onboarding_native_cases', 'onboarding_native_assertions', 'python_unittest_reported_cases', 'python_unittest_skipped_cases')}, indent=2))
