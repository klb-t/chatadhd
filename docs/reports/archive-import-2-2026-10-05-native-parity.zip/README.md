# Actual paired native import and audit parity

This supplementary probe links the real native core twice and uses a fixed public synthetic SQLite archive. Both runs passed 11/11 correctness gates. Six complete sections match exactly after the stated import normalization: 704 scalar JSON values, zero dropped fields, zero skips, zero model calls. This is a correctness probe, not the repository's full CTest result or a performance measurement.

| Section | Compared scalar values | Exact equality |
| --- | ---: | --- |
| Five `ImportOptions` defaults | 5 | yes |
| Imported audit matrix | 142 | yes |
| Complete normalized import and stored records | 222 | yes |
| Source byte and SQLite integrity checks | 6 | yes |
| Source audit matrix | 196 | yes |
| Native source conversation and message records | 133 | yes |

Before: source `66da570d3b5379492e128d940ad474467082c59f`, clean working tree. After: source `156a82080a7abb8a68d249747dfa167b3045effe`; only report/ZIP documentation work was dirty and is recorded in the unchanged receipt. Both native builds use Release with `-O0 -DNDEBUG`, WERROR, bundled SQLite, and the same standalone probe compile/link flags. Actual source manifests cover 24 files before and 34 after and are stable within each run. The library hashes and parent build logs establish compiled-library provenance; the manifests do not claim to cover the whole repository.

Before probe binary SHA256: `32be144f7743036db7f51929a721fc17f334964ce7f7630a93c6886d55a1dbb8`.
After probe binary SHA256: `1c95731f194277b9b92d2ff7600f23b869fd1586dfaab4ddb73f4ea4b83438c3`.
Before core archive SHA256: `c375272a05f4bb4cb1bc8a2619b18a93dcacefefbe00e4fc14670c642001f59d`.
After core archive SHA256: `6a35c4a7c9c5f1112a078f429743130529f115661c8420345e9b3ea65d857cf7`.

The [exact runner](run_native_parity.py), [exact probe](native_parity_probe.cpp), [synthetic seed](synthetic-source.sqlite), [paired comparison](parity.json), and both stage directories are retained. Stage `receipt.json` files contain commands, executable/input hashes, source snapshots, durations, checks and exact executed code hashes. Full unfiltered JSON output is in each `probe.stdout`; the historical commands contain their original absolute workspace paths. No executable, static library, or imported output database is included in this package.

The fixture has three conversations (including an empty one), seven messages, six roles and six statuses. It includes a version group, parent relationships, tool/deleted/suppressed/unknown-status rows, non-ASCII text and embedded NULs. Native source audit counts 86 Unicode code points. The four full audit results per database cover defaults, explicit prices, active-only/custom token bounds and output ratio, and empty selection. Each result includes assumptions, role/status counts, null/unavailable costs and the model-call count. The importer stores three conversations, seven messages and ten provenance records and verifies the captured source blob.

Only generated imported conversation/message/source/provenance/version-group IDs, generated DTO timestamps, and the copied fixture's source URI are normalized. All keys remain; source rows, text, metadata, relationships, roles/statuses, provenance locators and all audit fields remain compared. Both complete raw imported JSON results are retained. Sorting provenance uses normalized logical records to avoid generated-ID ordering.

The retained seed's SHA256 is `586e92b16a5785daf937955fa9143ff05b67099e8546510636afe6ce4163f3ab`. A native `Database::open` and source audit initialize each independent copy before import; they rewrite that copy to SHA256 `7d588326906345ae54228d0286803f059676c398aa8ce7bd9f6535b99f06909b`. Both initialized copies and both captured blobs have that same hash. The original seed remains unchanged. This proves the quiescent fixture path, not a live WAL snapshot.

The existing SQLite importer maps non-user/human roles to assistant and resets statuses/version data. The probe explicitly verifies that unchanged historical projection (one user, six assistants, all active) while retaining the complete source blob. It does not claim a lossless native SQLite structure import. This SQLite route also does not exercise JSON scanner chunk/depth thresholds; the five default values are observed directly and actual SQLite import/audit behavior is compared.

To reproduce, build `libloom_core.a`, `libloom_sqlite3_amalgamation.a` and `libloom_miniz.a` from the two stated source revisions using the recorded CMake settings. Use fresh output directories and pass the repo/build paths to the exact retained runner:

```sh
python3 run_native_parity.py \
  --before-repo /path/to/before-checkout \
  --after-repo /path/to/after-checkout \
  --before-build /path/to/before-build \
  --after-build /path/to/after-build \
  --out /path/to/fresh-output \
  --stage both
```

The runner creates its public deterministic seed with the before binary, then measures independent copies. It refuses existing stage directories. `--stage before` and `--stage after` can be used sequentially while independent builds finish; `--stage compare` verifies retained outputs. Binary hashes may differ on another toolchain; full typed JSON section equality and integrity/correctness gates must still pass. The seed supplied here binds the original execution and its generator is retained in the probe.

[SHA256SUMS](SHA256SUMS) covers every retained file except itself. Packaging copied original measurement files unchanged; the README and manifest were added after execution.
