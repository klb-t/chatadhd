#!/usr/bin/env python3
"""Real native before/after parity; synthetic SQLite, no provider calls.

Run before and after separately while their independent builds become ready.
All outputs remain in fresh external directories. The probe/runner are hashed
before execution; the measured receipt is never rewritten by packaging.
"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def source_manifest(repo):
    files = sorted((repo / "loom/src/import").glob("*"))
    files += [repo / name for name in (
        "loom/include/loom/importer.h", "loom/include/loom/db.h",
        "loom/include/loom/provenance.h", "loom/cli/main.cpp")]
    files += sorted((repo / "loom/data/presets").glob("*.pack"))
    return {str(path.relative_to(repo)): digest(path) for path in files if path.is_file()}


def command(label, args, cwd, directory, env=None):
    start = time.monotonic()
    with (directory / (label + ".stdout")).open("wb") as stdout, (directory / (label + ".stderr")).open("wb") as stderr:
        completed = subprocess.run([str(x) for x in args], cwd=cwd, stdout=stdout, stderr=stderr, env=env)
    return {"label": label, "args": [str(x) for x in args], "cwd": str(cwd),
            "exit_code": completed.returncode, "seconds": time.monotonic() - start}


def cache_values(build):
    values = {}
    for line in (build / "CMakeCache.txt").read_text().splitlines():
        if line.startswith(("#", "//")) or "=" not in line or ":" not in line.split("=", 1)[0]:
            continue
        key, value = line.split("=", 1)
        values[key.split(":", 1)[0]] = value
    return values


def gate(report):
    checks = {}
    rows = report["source_rows"]["messages"]
    source = report["source_audits"]["default"]
    imported = report["imported_normalized"]
    checks["source_fixture_7_messages_3_conversations"] = len(rows) == 7 and source["raw"]["conversations"] == 3
    checks["source_unicode_nul_characters_exact"] = source["raw"]["characters"] == sum(len(row["text"]) for row in rows)
    checks["source_statuses_exact"] = {k: v["messages"] for k, v in source["by_status"].items()} == dict(Counter(row["status"] for row in rows))
    checks["source_roles_exact"] = {k: v["messages"] for k, v in source["by_role"].items()} == dict(Counter(row["role"] for row in rows))
    checks["source_active_projection_exact"] = report["source_audits"]["custom"]["projected"]["messages"] == sum(row["status"] == "active" for row in rows)
    checks["import_3_conversations_7_messages"] = len(imported["result"]["conversations"]) == 3 and len(imported["messages"]) == 7 and imported["result"]["messages"] == 7
    checks["import_10_provenance_records"] = len(imported["provenance"]) == 10
    checks["historical_sqlite_all_statuses_flattened_to_active"] = all(row["status"] == "active" for row in imported["messages"])
    checks["historical_sqlite_role_projection"] = Counter(row["role"] for row in imported["messages"]) == Counter({"user": 1, "assistant": 6})
    checks["source_hash_captured_unchanged"] = report["integrity"]["source_blob_matches"] and len({report["integrity"][key] for key in ("retained_source_hash", "source_hash_before_import", "source_hash_after_import")}) == 1
    checks["sqlite_integrity"] = report["integrity"]["quick_check"] == "ok" and report["integrity"]["foreign_key_violations"] == 0
    return checks


def measure(stage, repo, build, out, probe_source, runner_source):
    directory = out / stage
    if directory.exists():
        raise RuntimeError("fresh stage directory required: " + str(directory))
    directory.mkdir(parents=True)
    shutil.copyfile(probe_source, directory / "executed_probe.cpp")
    shutil.copyfile(runner_source, directory / "executed_runner.py")
    cache = cache_values(build)
    if Path(cache["CMAKE_HOME_DIRECTORY"]).resolve() != (repo / "loom").resolve():
        raise RuntimeError("build source directory differs from requested repo")
    libs = [build / name for name in ("libloom_core.a", "libloom_sqlite3_amalgamation.a", "libloom_miniz.a")]
    inputs = [probe_source, runner_source, build / "CMakeCache.txt", *libs]
    before = {str(path): digest(path) for path in inputs}
    receipt = {"schema": "loom.native_import_parity_run/1", "stage": stage,
               "repo": str(repo), "build": str(build),
               "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
               "source_dirty": subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True).splitlines(),
               "inputs_before": before, "source_manifest_before": source_manifest(repo),
               "execution_source_copies": {name: digest(directory / name) for name in
                   ("executed_probe.cpp", "executed_runner.py")},
               "cmake": {key: value for key, value in cache.items() if key.startswith(("CMAKE_CXX", "CMAKE_BUILD_TYPE", "LOOM_"))},
               "commands": [], "model_calls": 0, "skips": 0}
    receipt_path = directory / "receipt.json"

    def run(label, args, cwd=repo, env=None):
        result = command(label, args, cwd, directory, env)
        receipt["commands"].append(result)
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
        if result["exit_code"]:
            raise RuntimeError(label + " failed; original stdout/stderr retained")

    binary = directory / "native_parity_probe"
    compiler = cache.get("CMAKE_CXX_COMPILER", "c++")
    run("compile-link", [compiler, "-std=c++20", "-O0", "-DNDEBUG", "-Wall", "-Wextra", "-Wpedantic",
        "-Wshadow", "-Wnon-virtual-dtor", "-Wold-style-cast", "-Wcast-align", "-Woverloaded-virtual",
        "-Wnull-dereference", "-Wimplicit-fallthrough", "-Wno-unused-parameter", "-Werror",
        "-I" + str(repo / "loom/include"), "-I" + str(repo / "loom/src"),
        "-I" + str(repo / "loom/third_party/nlohmann"), "-I" + str(repo / "loom/third_party/sqlite"),
        probe_source, *libs, "-lssl", "-lcrypto", "-ldl", "-lm", "-pthread", "-o", binary])
    fixture = out / "synthetic-source.sqlite"
    if not fixture.exists():
        if stage != "before":
            raise RuntimeError("measure baseline first to generate the shared fixture")
        run("make-fixture", [binary, "--make-fixture", fixture])
    fixture_copy = directory / "fixture-copy.sqlite"
    shutil.copyfile(fixture, fixture_copy)
    receipt["fixture_sha256"] = digest(fixture)
    receipt["fixture_copy_before_sha256"] = digest(fixture_copy)
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)
    env.pop("TMPDIR", None)
    run("probe", [binary, fixture_copy, directory / "data"], env=env)
    report = json.loads((directory / "probe.stdout").read_text())
    receipt["checks"] = gate(report)
    receipt["inputs_after"] = {str(path): digest(path) for path in inputs}
    receipt["source_manifest_after"] = source_manifest(repo)
    receipt["source_stable"] = receipt["source_manifest_before"] == receipt["source_manifest_after"]
    receipt["compiled_inputs_stable"] = receipt["inputs_before"] == receipt["inputs_after"]
    receipt["binary_sha256"] = digest(binary)
    receipt["output_sha256"] = digest(directory / "probe.stdout")
    receipt["fixture_copy_after_sha256"] = digest(fixture_copy)
    receipt["correct"] = all(receipt["checks"].values()) and receipt["source_stable"] and receipt["compiled_inputs_stable"]
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    if not receipt["correct"]:
        raise RuntimeError("native gates failed; original result retained")
    print(stage, "native probe/gates passed", flush=True)


def leaves(value):
    if isinstance(value, dict):
        return sum(leaves(item) for item in value.values())
    if isinstance(value, list):
        return sum(leaves(item) for item in value)
    return 1


def compare(out):
    before = json.loads((out / "before/probe.stdout").read_text())
    after = json.loads((out / "after/probe.stdout").read_text())
    keys = sorted(set(before) | set(after))
    # imported_raw is retained unmodified. Its complete normalized counterpart
    # replaces only DB-generated IDs/timestamps and the fixture-copy source URI.
    keys.remove("imported_raw")
    runs = {stage: json.loads((out / stage / "receipt.json").read_text()) for stage in ("before", "after")}
    same_execution_sources = runs["before"]["execution_source_copies"] == runs["after"]["execution_source_copies"]
    same_fixture = runs["before"]["fixture_sha256"] == runs["after"]["fixture_sha256"]
    sections = {key: {"exact_json_equal": canonical(before.get(key)) == canonical(after.get(key)),
                      "actual_leaf_values": leaves(before.get(key))} for key in keys}
    receipt = {"schema": "loom.native_import_parity/1", "sections": sections,
               "all_sections_equal": all(item["exact_json_equal"] for item in sections.values()),
               "same_execution_sources": same_execution_sources, "same_fixture": same_fixture,
               "leaf_values_compared": sum(item["actual_leaf_values"] for item in sections.values()),
               "normalization": ["generated import conversation/message/source/provenance/version-group IDs",
                   "generated import DTO created/updated/imported_at timestamps",
                   "source URI fixture-copy path"],
               "fields_dropped": [], "raw_import_outputs_retained": True,
               "model_calls": 0, "skips": 0,
               "run_receipt_sha256": {stage: digest(out / stage / "receipt.json") for stage in ("before", "after")}}
    (out / "parity.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if not receipt["all_sections_equal"] or not same_execution_sources or not same_fixture:
        raise RuntimeError("native default parity mismatch; full before/after outputs retained")
    print("All", len(keys), "full sections match;", receipt["leaf_values_compared"], "leaf values", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before-repo", type=Path, required=True)
    parser.add_argument("--after-repo", type=Path, required=True)
    parser.add_argument("--before-build", type=Path, required=True)
    parser.add_argument("--after-build", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--stage", choices=("before", "after", "both", "compare"), default="both")
    args = parser.parse_args()
    script = Path(__file__).resolve()
    probe = script.with_name("native_parity_probe.cpp")
    args.out.mkdir(parents=True, exist_ok=True)
    for stage in ("before", "after"):
        if args.stage in (stage, "both"):
            measure(stage, getattr(args, stage + "_repo").resolve(), getattr(args, stage + "_build").resolve(),
                    args.out.resolve(), probe, script)
    if args.stage in ("both", "after", "compare"):
        compare(args.out.resolve())


if __name__ == "__main__":
    main()
