#include <algorithm>
#include <filesystem>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include "import/import_audit.h"
#include "loom/db.h"
#include "loom/event_bus.h"
#include "loom/importer.h"
#include "loom/log.h"
#include "loom/provenance.h"
#include "loom/sqlite.h"
#include "loom/util/sha256.h"

using namespace loom;
namespace fs = std::filesystem;

template <class T> T value(Result<T> result) {
  if (!result) throw std::runtime_error(result.error().to_string());
  return std::move(*result);
}
void require(Status result) {
  if (!result) throw std::runtime_error(result.error().to_string());
}

struct FixtureRow {
  std::string id, conversation, role, status, text;
  std::optional<std::string> parent;
  std::string version_group;
  int version_number;
};
const std::vector<FixtureRow>& fixture_rows() {
  static const std::vector<FixtureRow> rows{
      {"m-a1", "c-a", "user", "active", std::string("ą") + '\0' + "🙂", std::nullopt, "vg-a", 1},
      {"m-a2", "c-a", "assistant", "version", "Draft x", "m-a1", "vg-a", 2},
      {"m-a3", "c-a", "tool", "excluded", std::string("tool\nbinary") + '\0' + "result", "m-a2", "vg-tool", 1},
      {"m-b1", "c-b", "system", "deleted", "deleted evidence 🔎", std::nullopt, "vg-b1", 1},
      {"m-b2", "c-b", "alien", "future-status", "future status {} []", "m-b1", "vg-b2", 1},
      {"m-b3", "c-b", "assistant", "active", "Answer B 😀", "m-b2", "vg-b3", 1},
      {"m-b4", "c-b", "developer", "suppressed", "shadow kept", "m-b3", "vg-b4", 1}};
  return rows;
}

void make_fixture(const fs::path& path) {
  if (fs::exists(path)) throw std::runtime_error("fixture already exists");
  auto db = value(Database::open(path));
  require(db->conn().exec("ALTER TABLE conversations ADD COLUMN created_at TEXT;"
      "ALTER TABLE messages ADD COLUMN conversation_id TEXT;"
      "ALTER TABLE messages ADD COLUMN content TEXT;"
      "ALTER TABLE messages ADD COLUMN created_at TEXT;"));
  int index = 0;
  for (const auto* id : {"c-a", "c-b", "c-empty"}) {
    const auto stamp = std::string("2026-01-0") + std::to_string(++index) + "T00:00:00Z";
    require(db->conn().run("INSERT INTO conversations(id,title,created,updated,source,metadata,created_at) "
        "VALUES (?,?,?,?,?,?,?)", id, std::string("Synthetic ") + id, stamp, stamp, "user",
        Json{{"fixture", "public-native-parity"}, {"original_id", id}}.dump(), stamp));
  }
  index = 0;
  for (const auto& row : fixture_rows()) {
    const auto stamp = std::string("2026-01-01T00:00:0") + std::to_string(++index) + "Z";
    require(db->conn().run("INSERT INTO messages(id,conv_id,parent_id,role,text,model,status,version_group_id,"
        "version_num,weight,attachments,metadata,created,semantic_status,conversation_id,content,created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row.id, row.conversation, row.parent, row.role, row.text,
        std::string("offline-synthetic-model"), row.status, row.version_group, row.version_number, 1.0,
        Json::array({Json{{"type", "fixture"}, {"public", true}}}).dump(),
        Json{{"fixture", "public-native-parity"}, {"original_status", row.status}}.dump(), stamp,
        "pending", row.conversation, row.text, stamp));
  }
  require(db->conn().exec("PRAGMA wal_checkpoint(TRUNCATE);"));
}

Json audit_options(const ImportAuditOptions& options) {
  return Json{{"active_only", options.active_only}, {"chars_per_token_low", options.chars_per_token_low},
      {"chars_per_token_high", options.chars_per_token_high}, {"output_ratio", options.output_ratio},
      {"input_price", options.input_price ? Json(*options.input_price) : Json(nullptr)},
      {"output_price", options.output_price ? Json(*options.output_price) : Json(nullptr)}};
}

Json audits(Database& db, const std::vector<Conversation>& conversations) {
  ImportAuditOptions defaults;
  ImportAuditOptions priced;
  priced.input_price = 2.5; priced.output_price = 7.75;
  ImportAuditOptions custom;
  custom.active_only = true; custom.chars_per_token_low = 6.5; custom.chars_per_token_high = 2.5;
  custom.output_ratio = 1.25; custom.input_price = 3.75; custom.output_price = 11.25;
  return Json{{"default_options", audit_options(defaults)}, {"custom_options", audit_options(custom)},
      {"default", value(audit_import(db, conversations, defaults))},
      {"priced", value(audit_import(db, conversations, priced))},
      {"custom", value(audit_import(db, conversations, custom))},
      {"empty", value(audit_import(db, {}, defaults))}};
}

Json replace_ids(Json document, const std::map<std::string, std::string>& ids) {
  if (document.is_string()) {
    const auto found = ids.find(document.get<std::string>());
    if (found != ids.end()) document = found->second;
  } else if (document.is_object() || document.is_array()) {
    for (auto& item : document) item = replace_ids(std::move(item), ids);
  }
  return document;
}

Json probe(const fs::path& fixture, const fs::path& result_dir) {
  if (fs::exists(result_dir / "import.db")) throw std::runtime_error("fresh result directory required");
  fs::create_directories(result_dir);
  ImportOptions import_defaults;
  Json report{{"import_default_values", {{"stream_threshold_bytes", import_defaults.stream_threshold_bytes},
      {"json_read_chunk_bytes", import_defaults.json_read_chunk_bytes},
      {"json_max_depth", import_defaults.json_max_depth},
      {"json_inline_threshold_bytes", import_defaults.json_inline_threshold_bytes},
      {"generic_inference_max_bytes", import_defaults.generic_inference_max_bytes}}}};
  {
    auto source = value(Database::open(fixture));
    std::vector<Conversation> conversations;
    Json conversation_rows = Json::array(), messages = Json::array();
    for (const auto* id : {"c-a", "c-b", "c-empty"}) {
      auto conversation = value(source->get_conv(id));
      if (!conversation) throw std::runtime_error("fixture conversation missing");
      conversations.push_back(*conversation); conversation_rows.push_back(conversation->to_json());
      for (const auto& message : value(source->get_msgs(id, true))) messages.push_back(message.to_json());
    }
    auto duplicated = conversations;
    duplicated.push_back(conversations.front());
    report["source_rows"] = Json{{"conversations", conversation_rows}, {"messages", messages}};
    report["source_audits"] = audits(*source, duplicated);
    require(source->conn().exec("PRAGMA wal_checkpoint(TRUNCATE);"));
  }
  const auto source_hash = value(sha256_file_hex(fixture));
  auto imported_db = value(Database::open(result_dir / "import.db"));
  EventBus bus;
  BlobStore blobs{result_dir / "blobs", *imported_db};
  ProvenanceStore provenance{*imported_db};
  ConversationImporter importer{*imported_db, bus, &blobs, &provenance};
  const auto result = value(importer.import_file(fixture, import_defaults));
  const auto source = value(provenance.get_source(result.source_id));
  if (!source) throw std::runtime_error("import source missing");
  require(blobs.verify(result.blob_hash));
  Json imported{{"result", result.to_json()}, {"source", source->to_json()},
      {"stored_conversations", Json::array()}, {"messages", Json::array()}, {"provenance", Json::array()}};
  std::map<std::string, std::string> ids{{result.source_id, "$source-0"}};
  int message_index = 0, group_index = 0;
  for (std::size_t i = 0; i < result.conversations.size(); ++i) {
    const auto& conversation = result.conversations[i];
    ids[conversation.id] = "$conversation-" + std::to_string(i);
    const auto stored = value(imported_db->get_conv(conversation.id));
    if (!stored) throw std::runtime_error("imported conversation missing");
    imported["stored_conversations"].push_back(stored->to_json());
    for (const auto& message : value(imported_db->get_msgs(conversation.id, true))) {
      ids[message.id] = "$message-" + std::to_string(message_index++);
      if (message.version_group_id && !ids.contains(*message.version_group_id))
        ids[*message.version_group_id] = "$version-group-" + std::to_string(group_index++);
      imported["messages"].push_back(message.to_json());
    }
  }
  auto records = value(provenance.for_source(result.source_id));
  std::sort(records.begin(), records.end(), [&](const auto& left, const auto& right) {
    Json a = left.to_json(), b = right.to_json();
    a.erase("id"); a.erase("created"); b.erase("id"); b.erase("created");
    return replace_ids(std::move(a), ids).dump() < replace_ids(std::move(b), ids).dump();
  });
  for (std::size_t i = 0; i < records.size(); ++i) {
    ids[records[i].id] = "$provenance-" + std::to_string(i);
    imported["provenance"].push_back(records[i].to_json());
  }
  report["imported_raw"] = imported;
  imported = replace_ids(std::move(imported), ids);
  for (auto& conversation : imported["result"]["conversations"])
    for (const auto* field : {"created", "updated"}) conversation[field] = "$generated-timestamp";
  for (auto& conversation : imported["stored_conversations"])
    for (const auto* field : {"created", "updated"}) conversation[field] = "$generated-timestamp";
  for (auto& message : imported["messages"]) message["created"] = "$generated-timestamp";
  imported["source"]["imported_at"] = "$generated-timestamp";
  imported["source"]["uri"] = "$fixture-copy-path";
  for (auto& record : imported["provenance"]) record["created"] = "$generated-timestamp";
  report["imported_normalized"] = std::move(imported);
  report["imported_audits"] = audits(*imported_db, result.conversations);
  report["integrity"] = Json{{"source_blob_matches", result.blob_hash == source_hash},
      {"retained_source_hash", result.blob_hash},
      {"source_hash_before_import", source_hash}, {"source_hash_after_import", value(sha256_file_hex(fixture))},
      {"quick_check", value(imported_db->conn().query_text("PRAGMA quick_check")).value_or("")},
      {"foreign_key_violations", 0}};
  auto foreign_keys = value(imported_db->conn().prepare("PRAGMA foreign_key_check"));
  while (value(foreign_keys.step())) report["integrity"]["foreign_key_violations"] =
      report["integrity"]["foreign_key_violations"].get<int>() + 1;
  return report;
}

int main(int argc, char** argv) {
  try {
    log::set_stderr(false);
    if (argc == 3 && std::string_view(argv[1]) == "--make-fixture") {
      make_fixture(argv[2]);
      std::cout << Json{{"fixture", argv[2]}, {"messages", fixture_rows().size()},
          {"sha256", value(sha256_file_hex(argv[2]))}}.dump(2) << '\n';
      return 0;
    }
    if (argc != 3) throw std::runtime_error("usage: probe FIXTURE SQLITE_RESULT_DIR or probe --make-fixture FIXTURE");
    std::cout << probe(argv[1], argv[2]).dump(2) << '\n';
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
