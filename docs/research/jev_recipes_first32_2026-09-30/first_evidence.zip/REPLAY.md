# Offline first-response replay

Extract this archive into a new directory, then run there:

```sh
python replay/loom/tools/structure/recipe_live_score.py --manifest prepared/manifest.json --run-dir run --output replayed_score.json
```

This scores exact archived first bytes without keys or network. The manifest retains its original absolute run path for identity; the scorer reads the explicitly supplied evidence copy. INVENTORY.json hashes all archive payloads. Code and frozen T3 inputs are included so future code edits do not invalidate this replay.

Never rerun paid calls to reconstruct lost responses. Before any execution resume after a workspace restore, restore the original run/ receipts and ledger checkpoint into the canonical run directory recorded in prepared/manifest.json. Do not change the prepared manifest or key cap. The existing dedicated USD 2 nonresetting key ceiling remains shared with all jobs. Credentials and lock files are not archived.
