# Offline optional8 development replay

Extract this archive, then from its root:

```sh
python replay/loom/tools/structure/recipe_key_control_pilot.py score --manifest prepared/manifest.json --run-dir run --output replayed_score.json
```

No credentials or network. Frozen v1/new adapter, original T3 bodies/gold and immutable first32 comparator are included. Inventory hashes cover all payloads. The absolute original run path remains in the manifest for identity.

Before any execution resume after workspace restoration, restore run/ receipts and checkpoint into the original canonical path; never reconstruct responses through new paid calls. Original USD 2 nonresetting key cap remains shared.
