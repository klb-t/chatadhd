import hashlib, json, pathlib, sys
from unittest.mock import patch
root=pathlib.Path('/var/tmp/thread7-live-unblock-2026-10-09/audit-binding')
label=sys.argv[1]
repo=pathlib.Path('/workspace/scratch/b258b858b122/chatadhd')
source=root/'audit_run.pinned.py'
sys.argv=[str(source),'--repo',str(repo),'--sha','cb16b336ee0c59a1ff80b4899dadebce33aa7610','--prior-repo',str(repo),'--prior-sha','cb16b336ee0c59a1ff80b4899dadebce33aa7610','--output',str(root/(label+'.json'))]
text=source.read_text().split('\nwith patch.object(socket.socket,')[0]
ns={'__file__':str(source),'__name__':'audit_connection_replay'}
exec(compile(text,str(source),'exec'),ns)
with patch('socket.socket.connect',ns['denied_network']),patch('socket.create_connection',ns['denied_network']):
    ns['connection_tests']()
receipt={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'connector_sha256':hashlib.sha256((repo/'docs/research/thread7_real_2026-10-09/continuation_01/connect_prepared.py').read_bytes()).hexdigest(),'base_sha':'cb16b336ee0c59a1ff80b4899dadebce33aa7610','audit_sha':'9f931da3bb1d1001f9b7d865914ae195d9255b7e','label':label,'tests':ns['tests'],'paid_calls':0,'network_calls':0}
(root/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps([{'id':v['id'],'category':v['category'],'status':v['status']} for v in receipt['tests']],indent=2))
