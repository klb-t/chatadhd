import os, pathlib, subprocess, sys, time
root=pathlib.Path('/workspace/scratch/edcd10c4764c')
repo=root/'chatadhd'
tool=root/'local-toolchain/root/usr'
build=root/'native-build'
env=os.environ.copy()
env['LD_LIBRARY_PATH']=str(tool/'lib/x86_64-linux-gnu')
cmake=str(tool/'bin/cmake')
commands={
'configure':[cmake,'-S',str(repo/'loom'),'-B',str(build),'-G','Ninja','-DCMAKE_MAKE_PROGRAM='+str(tool/'bin/ninja'),'-DCMAKE_BUILD_TYPE=Debug','-DLOOM_USE_SYSTEM_SQLITE=OFF','-DLOOM_WITH_OPENSSL=ON','-DLOOM_SHARED=ON','-DLOOM_BUILD_TESTS=ON','-DLOOM_BUILD_CLI=ON','-DLOOM_BUILD_SERVER=ON','-DPython3_EXECUTABLE='+str(root/'local-python/bin/python')],
'build':[cmake,'--build',str(build),'--parallel','3'],
'test':[str(tool/'bin/ctest'),'--test-dir',str(build),'--output-on-failure','--parallel','3','--timeout','180'],
}
phase=sys.argv[1]
log=root/('native-local-'+phase+'.log')
start=time.monotonic()
with log.open('w') as stream:
 result=subprocess.run(commands[phase],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
print(phase+' exit='+str(result.returncode)+' seconds='+str(round(time.monotonic()-start,2))+' log='+str(log))
print('\n'.join(log.read_text(errors='replace').splitlines()[-30:]))
sys.exit(result.returncode)
