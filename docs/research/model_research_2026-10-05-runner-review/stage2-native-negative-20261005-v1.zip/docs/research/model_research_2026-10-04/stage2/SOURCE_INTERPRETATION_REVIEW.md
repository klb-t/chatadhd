# Stage2 first-response interpretation review

The review records inspect all 60 first replies across all four methods and 15
synthetic DEV cases against the unchanged, preregistered 48 source criteria.
The planned denominator remains 192 request-criterion slots. Every supplied
choice and all 19 complete, bound alternative bundles are retained; incomplete
JSON fragments are read diagnostically without reconstruction, fence removal,
duplicate-key selection or replacement replies.

The frozen native receipts contain 41 invalid responses and 19 native-rejected
bundles, with zero native-valid requests. The reported native errors are 16
`quote_mismatch`, two `shape` and one `span_bounds`; these are the captured
validator rejections, not an exhaustive catalogue of defects in each bundle.
The reply finish reasons are 32 `length` and 28 `stop`. A `stop` response can
still be malformed or native-invalid. Copied source wording, a plausible label
or an asserted `represented` coverage row does not establish eligible extraction.

`SOURCE_INTERPRETATION_REVIEWS.v1.json` binds every reviewed slot to its prepared
request hash, first HTTP response hash, generation identity and exact content
hash. It records source-specific diagnostic rationales and, for bound bundles,
existing candidate pointers and exact source spans. For unparseable responses,
the criteria retain diagnostic source support and an empty bundle-judgement
inventory. No candidate tree is reconstructed. Transport, billing, native
validation and source interpretation remain separate evidence.

`SOURCE_INTERPRETATION_SCORE.v1.json` is the unchanged scorer's output: zero
satisfied, zero violated and 192 unresolved slots. Its numeric
`satisfied_fraction: 0.0` is the eligibility-gated count of satisfied planned
slots, **not a measurement of zero semantic accuracy**. There are no eligible
native candidates on which this review can establish interpretation agreement.
Semantic accuracy is unknown; these records do not identify a winning native
extraction recipe. They are inspected synthetic DEV diagnostics against an
annotation authored in this session, not unseen or independently authored gold,
world truth, or a comparison with W1's different end-to-end scorecard.

The adapter, source reference, scorer and request presets were frozen before
this public-output inspection. Only review data and this explanatory record
were added after collection. The original response and native receipt files,
including their failures and hashes, remain unchanged.
