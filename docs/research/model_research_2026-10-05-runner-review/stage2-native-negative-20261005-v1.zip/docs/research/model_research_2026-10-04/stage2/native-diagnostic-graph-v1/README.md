# Stage2 native and source-review diagnostic graph

This DATA-only projection reuses the four observed method/configuration identities
from the original stage2 graph. Its 60 first-response events produce 12 evaluations
with the existing ModelProfile metric fields. Each method has native first-response
contract validity **0/15**, measured on the `mechanism` axis, and **48 unresolved
source-interpretation slots**, measured on the `diagnostic` axis. Semantic source
agreement is **null / UNKNOWN**, on the `unavailable` axis. Native contract failure
is not a semantic accuracy score; no native extraction winner is established.

All event and evaluation `produced_by` claims point to the original configured
method identities, whose `uses_version` claims retain the original method version
identities. Claims have dated source references to the unchanged native receipts,
first captures, source-only criteria and complete manual review. Exact dependency
and output hashes are in `VERIFICATION.json`. The original stage2 artifacts are
unchanged. This export made no model calls and wrote no canonical store.

Reproduce from the repository root with the unchanged generic exporter:

```sh
python -m loom.tools.structure.method_graph_export_v1 \
  docs/research/model_research_2026-10-04/stage2/native-diagnostic-graph-v1/configuration.json \
  --root . --output /tmp/stage2-native-diagnostic-packet.json
```

The UTF-8 packet bytes match `uncompressed_packet_sha256` in the verification
receipt. `packet.json.gz` is a deterministic gzip (`mtime=0`) of those bytes.
Validation here is through the existing Python GraphPacket native DTO codec and
shared metric schema. This does not claim execution through CABI or the store.

`NATIVE_PLATFORM_PROVENANCE.json` binds the existing full **108/108** gate, its
**1604 Python cases**, all six recorded native binary hashes, and native C++
source/build evidence. The native candidate stdin API is exactly
`{"packet": ..., "bundle": ..., "vocabulary": ...}`. Original native results and
raw invocation captures remain in `programme-actual/stage2-final-20261005-v1/`.
The binary is not duplicated in this artifact. Its recorded SHA identifies the
original platform build; rebuilding elsewhere does not promise a byte-identical
binary.
