// Internal types and pure stage functions of the Archive Intelligence
// pipeline (include/loom/archive.h). Not installed; unit tests include it.
//
// Everything here is deterministic: inputs are plain values, outputs are
// ordered with explicit tie-breaks, and no function reads the clock or
// generates random ids.
#pragma once

#include <cstdint>
#include <filesystem>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

#include "loom/result.h"
#include "loom/util/json.h"

namespace loom {
class SemanticAnalyzer;
}

namespace loom::archive {

// ── Documents ───────────────────────────────────────────────────────
// One retrievable unit: a chat message, a document section, a code file
// digest, a commit, a Claude project doc or memory.
struct Doc {
  std::string key;      // stable: derived from content hashes + locator
  std::string kind;     // chat | doc | code | commit | project | memory
  std::string unit;     // grouping key (conversation / file); stable
  std::string title;    // conversation title, file path, "git log"
  std::string label;    // "#3 user", "§4.9 Project Compiler", "a1b2c3d fix x"
  std::string uri;      // display path of the source (relative when possible)
  std::string date;     // "YYYY-MM-DD" or "YYYY-MM-DDTHH:MM:SSZ"; "" = unknown
  std::string role;     // user | assistant | document | code | commit
  std::string text;
  int ordinal = 0;      // position inside the unit
  Json extra = Json::object();  // fork info, commit files, code symbols/todos, heading path
  Json to_json() const;
  static Doc from_json(const Json& j);
};

struct Corpus {
  std::vector<Doc> docs;
  Json sources = Json::array();  // [{"uri","adapter","format","hash","docs"}]
  // Branch forks / version groups: [{"unit","title","after","date",
  //   "origin":"chatgpt|claude|versions","alternatives":[{"first","messages","current"}]}]
  Json forks = Json::array();
  std::string project;           // derived display name
  std::vector<std::string> default_seeds;
  std::unordered_map<std::string, std::size_t> index;  // key -> position
  void reindex();
  const Doc* find(std::string_view key) const;
  Json to_json() const;
  static Corpus from_json(const Json& j);
};

// ── Text utilities (src/archive/text.cpp) ───────────────────────────
// Lowercased runs of letters/digits (underscore splits), numbers dropped.
std::vector<std::string> tokenize(std::string_view text);
bool is_stopword(std::string_view lower_token);
// tokenize() minus stop words and tokens shorter than 3 code points.
std::vector<std::string> content_tokens(std::string_view text);
// content tokens + adjacent content-token bigrams ("knowledge graph").
std::vector<std::string> candidate_terms(std::string_view text);
// Sentences / bullet lines; markdown bullets and heading marks stripped;
// fenced code blocks skipped.
std::vector<std::string> split_sentences(std::string_view text);
// First ISO date (YYYY-MM-DD) in the text, "" when none.
std::string first_date(std::string_view text);
// "2024-11-03T10:00:00Z" from epoch seconds (UTC).
std::string iso_from_epoch(double seconds);
// Normalises ISO-ish timestamps to "YYYY-MM-DDTHH:MM:SSZ" (UTC when an offset
// is given); returns the input's date prefix or "" when unparseable.
std::string normalize_date(std::string_view s);
std::string date_only(std::string_view iso);  // first 10 chars or ""
// sha256 hex prefix of `s` (n chars).
std::string hash_prefix(std::string_view s, std::size_t n = 12);
// Collapses whitespace and clips to max code points (adding "…").
std::string clip(std::string_view s, std::size_t max_cp);
// Word splitting for identifiers: "GraphEngine" -> {"graph","engine"},
// "ingest_analysis" -> {"ingest","analysis"}.
std::vector<std::string> split_identifier(std::string_view ident);
// CamelCase / mixedCase identifiers ("GraphEngine", "IExecutionEnvironment",
// "ChatADHD") in original case, in order of appearance (duplicates kept).
std::vector<std::string> camel_identifiers(std::string_view text);
// Crude singular form used for matching ("stores" -> "store").
std::string stem(std::string_view lower_token);
// PL -> EN glossary for the gap report (policy data); identity when unknown.
std::string gloss(std::string_view lower_token);

// ── Ingest helpers (src/archive/ingest_parse.cpp) ───────────────────
struct Section {
  std::string heading;       // last heading text ("" before the first heading)
  std::string heading_path;  // "4. Warstwy › 4.9 Project Compiler"
  std::string text;
  int line = 1;              // 1-based line of the section start
};
// Splits markdown/plain text into sections by ATX headings; long sections are
// split further at paragraph boundaries (max_chars per piece).
std::vector<Section> split_markdown(std::string_view content, std::size_t max_chars = 4000);

struct CodeDigest {
  std::string language;
  std::vector<std::string> symbols;  // declared classes/structs/functions (declaration order, unique)
  std::vector<std::string> comments; // comment blocks (normalised text)
  std::vector<std::pair<int, std::string>> todos;  // (line, "TODO: ...")
  std::vector<std::string> uses;     // CamelCase identifiers used in code lines (not comments)
  std::string text;                  // the digest indexed as the document text
};
std::string code_language(const std::filesystem::path& p);  // "" when not code
CodeDigest digest_code(std::string_view rel_path, std::string_view language, std::string_view content);

struct GitCommit {
  std::string hash;
  std::string date;     // normalised UTC ISO
  std::string author;
  std::string subject;
  std::string body;
  std::vector<std::string> files;  // "M path"
};
// Parses the output of
//   git log --format=%x1e%H%x1f%aI%x1f%an%x1f%s%x1f%b%x1f --name-status
std::vector<GitCommit> parse_git_log(std::string_view raw);
inline constexpr std::string_view kGitLogFormat = "%x1e%H%x1f%aI%x1f%an%x1f%s%x1f%b%x1f";

// Chat export structure walkers. Each returns
//   [{"role","text","date","node","parent","branch","current"}] in
// depth-first order plus fork records in `forks`:
//   [{"node","date","alternatives":[{"first_node","messages","current"}]}]
struct ChatWalk {
  Json messages = Json::array();
  Json forks = Json::array();
  std::string title;
  std::string date;  // conversation creation date
};
ChatWalk walk_chatgpt(const Json& conv);
ChatWalk walk_claude(const Json& conv);
// "chatgpt" | "claude" | "claude_projects" | "claude_memories" | "" for one
// element (or top-level object) of an export file.
std::string sniff_export_element(const Json& element);

// ── Retrieval / vocabulary (src/archive/vocab.cpp) ──────────────────
struct DocTerms {
  std::vector<std::string> terms;               // candidate terms, unique, first-occurrence order
  std::unordered_map<std::string, int> tf;      // term -> count
};
struct CorpusStats {
  std::size_t n = 0;
  std::unordered_map<std::string, int> df;      // candidate term -> #docs
  std::vector<DocTerms> docs;                   // parallel to corpus.docs
};
CorpusStats compute_stats(const Corpus& corpus);

struct TermRecord {
  std::string term;
  int pass = 0;              // 0 = seed / synthesis round seed
  std::string origin;        // seed | expansion | synthesis
  double score = 0.0;
  std::vector<std::string> reasons;
  std::vector<std::string> evidence;  // doc keys (max 5)
  Json to_json() const;
  static TermRecord from_json(const Json& j);
};

// Salient new terms of `hits` (doc indexes) against the corpus.
std::vector<TermRecord> expand_vocabulary(const Corpus& corpus, const CorpusStats& stats,
                                          const std::vector<std::size_t>& hits, const std::set<std::string>& vocab,
                                          int pass, int max_new, const SemanticAnalyzer* analyzer);

// Top-k candidate terms of one document by tf-idf (df >= 2).
std::vector<std::pair<std::string, double>> salient_terms(const CorpusStats& stats, std::size_t doc_index, int k);

// ── Clustering (src/archive/cluster.cpp) ────────────────────────────
// Deterministic Louvain (nodes visited in index order, ties -> lowest
// community id). Returns a community id per node, renumbered 0..k-1 by first
// appearance.
std::vector<int> louvain(int n, const std::vector<std::tuple<int, int, double>>& edges, int max_levels = 10);

// ── Items (src/archive/items.cpp) ───────────────────────────────────
inline constexpr std::string_view kItemTypes[] = {"decision",       "rejected_option", "open_question",
                                                  "requirement",    "invariant",       "idea",
                                                  "rationale",      "implementation",  "bug"};

struct Classification {
  std::string type;          // "" when no cue fired
  double confidence = 0.0;
  std::vector<std::string> cues;
  int polarity = 1;          // -1 when the sentence negates / rejects
};
// heading: enclosing section heading path (hints like "Otwarte decyzje").
Classification classify_sentence(std::string_view sentence, std::string_view heading = "");

struct Item {
  std::string id;            // "i_" + hash prefix (stable)
  std::string type;
  std::string text;
  std::string doc;           // doc key
  std::string unit;          // doc unit (conversation / file)
  std::string theme;         // theme id
  std::string date;
  double confidence = 0.0;
  std::vector<std::string> cues;
  std::vector<std::string> subject;  // content tokens (stemmed, unique, sorted)
  std::map<std::string, int> term_polarity;  // subject token -> +1/-1
  std::string status = "active";     // active | superseded | contested
  Json to_json() const;
  static Item from_json(const Json& j);
};
// Items of one document (sentences classified; code docs: TODO/FIXME only;
// commits: one implementation/bug item).
std::vector<Item> extract_items(const Doc& doc, std::string_view theme);

struct ItemEdge {
  std::string src;           // item id (the later / superseding one)
  std::string dst;
  std::string type;          // supersedes | contradicts
  std::string reason;
  Json to_json() const;
};
// Detects supersession / contradiction; updates item.status.
std::vector<ItemEdge> relate_items(std::vector<Item>& items, const CorpusStats* stats = nullptr);

}  // namespace loom::archive
