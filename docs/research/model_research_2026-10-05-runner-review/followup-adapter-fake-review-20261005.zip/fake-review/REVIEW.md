# Follow-up adapter: independent fabricated review

Final scoped PASS on adapter SHA-256 `89b05c9673e256b4be8e2d74c865ae080e757bba5e80dc96111cc1db0f892c18` and focused-test SHA-256 `b7cab428341e70f0351c49af6080098ac77e018c0d76ef2fb993d3a7c25fd197`. The reviewer independently ran 32 focused tests and 23 additional fabricated graph cases. No actual stage3/4 output, private ledger/key/payer record, holdout or new corpus was read. No network, provider call, canonical store write, code/test mutation or model quality selection was performed by this reviewer.

Two concrete counterexamples have full exact before/fixed sources and fabricated inputs/results:

* `pattern-extra-diff-before/`: adapter `054de9dc207e6272289c557e68a6d168a4166855d1db4cebeaf72aff3df4c380` falsely rejects a pattern response containing an unused extra `diff` field. The existing pinned frontier scorer reports mechanical validity true, but the wrapper attempts completion preview and raises `KeyError('instrument_origin')`. `pattern-extra-diff-after/` uses the final adapter and reports one valid request, matching that instrument. The extra content is retained; no new schema gate or repair was added.
* `surrogate-choice-before/`: adapter `87ec97818cd6020e2a363a72c26230ec8b57d5ed97595460270a3458c34af593` receives valid ASCII JSON with an escaped lone-surrogate choice. Evaluation catches that choice's UnicodeEncodeError and retains eleven valid later slots, but CLI serialization aborts and creates a zero-byte output. `surrogate-choice-after/` reuses byte-identical input files and exports all twelve slots with the original invalid value reversibly escaped, eleven later valid slots, and no invented UTF-8 content hash. Successful CLI output SHA-256: `716c4d12bc734d0048cb827b5389b963f60c06948373b4e022edd90c9547f243`.

`graph-matrix-after/` preserves full input/report artifacts for 23 independent fabricated cases: strict whitespace/NFD/CRLF text equality; declared schema/text projection; unexpected text on identity representation; malformed, repeated and sibling alternatives; explicit source/compiler dependency pins and immutable Git references; missing model identity; orphan/duplicate records and qualified aggregate counts; literal observed model/accounting flags; and reversible malformed-Unicode serialization. It contains no actual model outputs.

Mechanical validity remains separate from semantic interpretation and billing/model verification. The adapter retains literal observed identities and caller flags, reports that it performs no billing or identity verification, and does not supply semantic accuracy or a winner. The graph compiler is an exact pinned Python reference; this review does not claim native C++ execution.

The sibling review owns `identity-proofs/` and `missing-followup-instrument-pin/`: exact repeated-body duplicate physical identity, null receipt hashes, and an omitted executing follow-up helper dependency. Their before/fixed witnesses complement this review and are not reclassified as new model measurements.

Replay the two saved counterexamples from any working directory:

```sh
python /path/to/extracted/replay_saved_negatives.py --repository /path/to/public/repository
```

The repository must provide the exact public helper-file hashes and immutable Git objects bound in the saved policy/config. The replay uses only archived fabricated normalized inputs and public frozen preparation/config/reference inputs. It does not open actual stage3/4 results or any credential. Original exploratory probe scripts are retained unchanged beside this portable saved-fixture replay.
