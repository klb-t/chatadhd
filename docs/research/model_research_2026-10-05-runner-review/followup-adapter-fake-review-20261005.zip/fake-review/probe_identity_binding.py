"""Independent fabricated before/after proof; no actual response/private reads."""
from pathlib import Path
import sys
import hashlib
import importlib.util
import json
from copy import deepcopy

ROOT = Path('/workspace/scratch/407fe6f6ff42/chatadhd')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from loom.tools.structure import test_programme_followup_results_v1 as fixture
from loom.tools.structure import programme_followup_results_v1 as current

def loaded(path, suffix, expected):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected
    name = 'loom.tools.structure._review_' + suffix
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

before = loaded(OUT/'draft-054de9dc207e/loom/tools/structure/programme_followup_results_v1.py',
                'followup_before', '054de9dc207e6272289c557e68a6d168a4166855d1db4cebeaf72aff3df4c380')
after = loaded(OUT/'candidate-87ec97818cd6/loom/tools/structure/programme_followup_results_v1.py',
               'followup_after', '87ec97818cd6020e2a363a72c26230ec8b57d5ed97595460270a3458c34af593')

def duplicate_operation():
    inputs = list(fixture.fixture())
    n, manifest_raw, config_raw, policy, refs = inputs
    source = current.wire.parse_json(manifest_raw)
    first = deepcopy(source['requests'][0]); second = deepcopy(first)
    second['id'] += ':fabricated-repetition'
    second['request_sha256'] = current.digest({k:v for k,v in second.items() if k!='request_sha256'})
    source['requests'] = [first, second]
    source_raw = current.wire.canonical(source)
    source_hash = current.sha(source_raw)
    request = deepcopy(n['requests'][0]); request['metadata']['source_manifest_sha256'] = source_hash
    repeat = deepcopy(request); repeat['metadata']['prepared_request_id'] = second['id']
    operation_id = request['operation_id']
    n['requests'] = [request, repeat]
    n['responses'] = n['responses'][:1]
    n['rows'] = n['rows'][:1]
    n['planned_operations'] = 2
    n['planned_operation_ids'] = [operation_id, operation_id]
    policy['sources']['manifest']['sha256'] = source_hash
    return n, source_raw, config_raw, policy, refs

def none_hash():
    inputs = fixture.fixture()
    inputs[0]['responses'][0]['response_sha256'] = None
    inputs[0]['rows'][0]['response_sha256'] = None
    return inputs

def evaluate(module, inputs):
    n, manifest, config, policy, refs = inputs
    return module.evaluate(current.wire.canonical(n), manifest, config, deepcopy(policy), references_raw=refs)

proofs = {}
for name, build in [('one_capture_two_prepared_repetitions', duplicate_operation),
                    ('matching_null_receipt_hashes', none_hash)]:
    inputs = build()
    target = OUT/'identity-proofs'/name
    target.mkdir(parents=True, exist_ok=True)
    n, source, config, policy, refs = inputs
    files = {'normalized.json':current.wire.canonical(n), 'source-manifest.json':source,
             'config.json':config, 'policy.json':current.wire.canonical(policy)}
    if refs is not None:
        files['references.json'] = refs
    for filename, raw in files.items():
        (target/filename).write_bytes(raw)
    old = evaluate(before, inputs); new = evaluate(after, inputs)
    (target/'before-result.json').write_bytes(current.wire.canonical(old)+b'\n')
    (target/'after-result.json').write_bytes(current.wire.canonical(new)+b'\n')
    proofs[name] = {'planned_slots':len(old['rows']), 'physical_response_records':len(n['responses']),
                    'before_valid_count':old['all_choices_valid_requests'],
                    'after_valid_count':new['all_choices_valid_requests'],
                    'before_first_slot_valid':old['rows'][0]['all_choices_mechanically_valid'],
                    'after_first_slot_valid':new['rows'][0]['all_choices_mechanically_valid'],
                    'after_integrity_errors':new['input_integrity_errors'],
                    'after_first_binding_errors':new['rows'][0]['choices'][0]['binding_errors'],
                    'fake_inputs_sha256':{fn:current.sha(raw) for fn,raw in files.items()},
                    'before_result_sha256':current.sha(current.wire.canonical(old)+b'\n'),
                    'after_result_sha256':current.sha(current.wire.canonical(new)+b'\n')}
assert proofs['one_capture_two_prepared_repetitions']['before_valid_count'] == 2
assert proofs['one_capture_two_prepared_repetitions']['physical_response_records'] == 1
assert proofs['one_capture_two_prepared_repetitions']['after_valid_count'] == 0
assert proofs['matching_null_receipt_hashes']['before_first_slot_valid'] is True
assert proofs['matching_null_receipt_hashes']['after_first_slot_valid'] is False
assert proofs['matching_null_receipt_hashes']['after_valid_count'] == 11
(OUT/'identity-proofs'/'proof-summary.json').write_text(json.dumps(proofs,indent=2)+'\n')
print(json.dumps(proofs,indent=2))
