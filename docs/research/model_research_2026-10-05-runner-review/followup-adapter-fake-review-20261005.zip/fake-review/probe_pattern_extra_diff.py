from pathlib import Path
import json,sys,hashlib,importlib.util
from copy import deepcopy
ROOT=Path('/workspace/scratch/407fe6f6ff42/chatadhd')
sys.path.insert(0,str(ROOT))
from loom.tools.structure import frontier_comparison_v1 as frontier
from loom.tools.structure import openrouter_runner as wire
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'loom/tools/structure/programme_followup_results_v1.py'
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).parent/'pattern-extra-diff-before'
OUT.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('loom.tools.structure.followup_review_candidate',SOURCE)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def sha(v):return hashlib.sha256(v).hexdigest()
def raw(v):return wire.canonical(v)
cases,references=frontier.synthetic_cases()
settings={'schema':frontier.SCHEMA+'/config','models':[{'key':'fake','model':'fabricated/model'}],
          'runtimes':[{'key':'fake','kind':'single_call'}],'repetitions':1,'resource_limits':None}
prepared=frontier.prepare(cases[:1],settings,references=references)
row=next(r for r in prepared['requests'] if r['track']=='pattern_discovery')
row['body']={'model':'fabricated/model','messages':deepcopy(row['messages']),'provider':{'only':['fabricated/provider']},'max_tokens':128}
row['request_sha256']=frontier.digest({k:v for k,v in row.items() if k!='request_sha256'})
manifest={'schema':frontier.SCHEMA,'requests':[row]}
config={'schema':'fabricated-followup-config/1','stage3':{'resource_limits':None}}
manifest_raw,config_raw,refs_raw=map(raw,[manifest,config,references])
policy=json.loads((ROOT/'docs/research/model_research_2026-10-04/followup-results/stage3-policy.json').read_bytes())
policy['prepared']['body_path']=['body']
policy['sources']={'manifest':{'sha256':sha(manifest_raw),'schema':manifest['schema']},
                   'config':{'sha256':sha(config_raw),'schema':config['schema']},
                   'references':{'sha256':sha(refs_raw)}}
scripted=frontier.scripted_response(row,references[row['case_id']])
results={}
for kind in ['baseline','unused_diff_field']:
    content=deepcopy(scripted['content'])
    if kind!='baseline':content['diff']={'unused':'retained extra content, not a pattern mutation'}
    recorded=deepcopy(scripted);recorded.update(response_origin='recorded',captured_model='fabricated/model',
                                              content=content,content_sha256=frontier.digest(content))
    direct=frontier.score_response(row,recorded,references[row['case_id']])
    operation_id='fabricated-one-first-attempt'
    response_sha=sha(raw(['fabricated-response-envelope',kind,content]))
    normalized={'schema':'loom.programme_results/1','manifest_sha256':'f'*64,
                'planned_operation_ids':[operation_id],'planned_operations':1,
                'requests':[{'operation_id':operation_id,'body':deepcopy(row['body']),
                             'request_sha256':frontier.digest(row['body']),
                             'metadata':{'prepared_request_id':row['id'],'source_manifest_sha256':sha(manifest_raw)}}],
                'responses':[{'operation_id':operation_id,'response_sha256':response_sha,
                              'projection':{'model':'fabricated/model','choices':[{'message':{'content':raw(content).decode()}}]}}],
                'rows':[{'operation_id':operation_id,'response_sha256':response_sha,
                         'request_sha256':frontier.digest(row['body']),'manifest_sha256':'f'*64}]}
    normalized_raw=raw(normalized)
    report=module.evaluate(normalized_raw,manifest_raw,config_raw,policy,references_raw=refs_raw)
    for name,value in [('manifest.json',manifest_raw),('config.json',config_raw),('references.json',refs_raw),
                       ('policy.json',raw(policy)),(kind+'-normalized.json',normalized_raw),
                       (kind+'-direct-score.json',raw(direct)),(kind+'-adapter-report.json',raw(report))]:
        (OUT/name).write_bytes(value)
    results[kind]={'direct_instrument_mechanical_validity':direct['mechanical_validity'],
                   'adapter_all_choices_valid_requests':report['all_choices_valid_requests'],
                   'adapter_failure':report['rows'][0]['choices'][0]['failure'],
                   'adapter_choice_mechanical_validity':report['rows'][0]['choices'][0]['mechanical_validity']}
(OUT/'programme_followup_results_v1.py').write_bytes(SOURCE.read_bytes())
(OUT/'results.json').write_bytes(raw({'source_sha256':sha(SOURCE.read_bytes()),'fabricated_only':True,'results':results}))
print(json.dumps({'source_sha256':sha(SOURCE.read_bytes()),'results':results,'fixture_directory':str(OUT)},indent=2))
