"""Replay exact archived fake witnesses against hash-gated final source."""
from pathlib import Path
import sys,json,hashlib,importlib.util
sys.path.insert(0,'/workspace/scratch/407fe6f6ff42/chatadhd')
from loom.tools.structure import test_programme_followup_results_v1 as fixture
OUT=Path(__file__).resolve().parent
path=OUT/'candidate-89b05c9673e2/loom/tools/structure/programme_followup_results_v1.py'
expected='89b05c9673e256b4be8e2d74c865ae080e757bba5e80dc96111cc1db0f892c18'
assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
name='loom.tools.structure._review_followup_final'
spec=importlib.util.spec_from_file_location(name,path);s=importlib.util.module_from_spec(spec);sys.modules[name]=s;spec.loader.exec_module(s)
proof={}
for name in ('one_capture_two_prepared_repetitions','matching_null_receipt_hashes'):
    folder=OUT/'identity-proofs'/name
    result=s.evaluate((folder/'normalized.json').read_bytes(),(folder/'source-manifest.json').read_bytes(),
                      (folder/'config.json').read_bytes(),s.wire.parse_json((folder/'policy.json').read_bytes()))
    raw=s.serialize_report(result);(folder/'final-result.json').write_bytes(raw)
    proof[name]={'all_choices_valid_requests':result['all_choices_valid_requests'],
                 'first_slot_valid':result['rows'][0]['all_choices_mechanically_valid'],
                 'input_integrity_errors':result['input_integrity_errors'],
                 'first_binding_errors':result['rows'][0]['choices'][0]['binding_errors'],
                 'result_sha256':s.sha(raw)}
assert proof['one_capture_two_prepared_repetitions']['all_choices_valid_requests']==0
assert proof['matching_null_receipt_hashes']['all_choices_valid_requests']==11
assert all(not x['first_slot_valid'] for x in proof.values())
folder=OUT/'missing-followup-instrument-pin'
n,source,config,policy,refs=fixture.fixture()
policy=s.wire.parse_json((folder/'policy.json').read_bytes())
inputs={'normalized.json':s.wire.canonical(n),'source-manifest.json':source,'config.json':config}
for fn,raw in inputs.items():(folder/fn).write_bytes(raw)
try:s.evaluate(inputs['normalized.json'],source,config,policy)
except ValueError as error:
    assert str(error)=='instrument_dependency_binding_missing'
    proof['missing_followup_instrument_pin']={'blocked':True,'error':str(error),
       'fake_input_sha256':{fn:s.sha(raw) for fn,raw in inputs.items()}}
else:raise AssertionError('unbound loader source accepted')
proof['final_adapter_sha256']=expected
(OUT/'final-identity-replay.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
