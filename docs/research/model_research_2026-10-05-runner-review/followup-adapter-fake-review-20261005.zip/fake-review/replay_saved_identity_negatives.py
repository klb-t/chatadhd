"""Portable hash-gated fake-input replay; requires public repo/Git dependencies."""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--repository',type=Path,required=True);ap.add_argument('--archive',type=Path)
args=ap.parse_args();root=args.archive or Path(__file__).resolve().parent
sys.path.insert(0,str(args.repository.resolve()))
def load(folder,expected,label):
    path=root/folder/'loom/tools/structure/programme_followup_results_v1.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
    name='loom.tools.structure._portable_identity_'+label
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module
old=load('draft-054de9dc207e','054de9dc207e6272289c557e68a6d168a4166855d1db4cebeaf72aff3df4c380','old')
pin_old=load('candidate-0bc2a770d87e','0bc2a770d87ef27058469beb376314bfef6e18f17b163417676ea1178499232a','pin_old')
final=load('candidate-89b05c9673e2','89b05c9673e256b4be8e2d74c865ae080e757bba5e80dc96111cc1db0f892c18','final')
def run(module,folder):
    return module.evaluate((folder/'normalized.json').read_bytes(),(folder/'source-manifest.json').read_bytes(),
                           (folder/'config.json').read_bytes(),module.wire.parse_json((folder/'policy.json').read_bytes()))
proof={}
for name,before_count,after_count in [('one_capture_two_prepared_repetitions',2,0),('matching_null_receipt_hashes',12,11)]:
    folder=root/'identity-proofs'/name
    before=run(old,folder);after=run(final,folder)
    assert before['all_choices_valid_requests']==before_count
    assert after['all_choices_valid_requests']==after_count
    assert not after['rows'][0]['all_choices_mechanically_valid']
    proof[name]={'before_valid':before_count,'after_valid':after_count,'affected_slot_rejected':True}
folder=root/'missing-followup-instrument-pin'
before=run(pin_old,folder);assert before['all_choices_valid_requests']==12
try:run(final,folder)
except ValueError as error:assert str(error)=='instrument_dependency_binding_missing'
else:raise AssertionError('missing executed source pin accepted')
proof['missing_followup_instrument_pin']={'before_valid':12,'after_blocked':True}
print(json.dumps({'fabricated_only':True,'source_sha256_verified':True,'proofs':proof},indent=2))
