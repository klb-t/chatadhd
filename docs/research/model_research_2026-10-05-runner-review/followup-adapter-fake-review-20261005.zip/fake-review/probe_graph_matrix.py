"""Independent fabricated alternatives/projection/pin probes; no actual output reads."""
from pathlib import Path
from copy import deepcopy
import hashlib,json,sys,unicodedata
ROOT=Path('/workspace/scratch/407fe6f6ff42/chatadhd');sys.path.insert(0,str(ROOT))
from loom.tools.structure import test_programme_followup_results_v1 as fixture
from loom.tools.structure import programme_followup_results_v1 as subject
OUT=Path('/workspace/scratch/407fe6f6ff42/followup-adapter-review-20261005/graph-matrix-after')
OUT.mkdir(parents=True,exist_ok=True)
BEFORE=Path(subject.__file__).read_bytes()
EXPECTED='89b05c9673e256b4be8e2d74c865ae080e757bba5e80dc96111cc1db0f892c18'
assert subject.sha(BEFORE)==EXPECTED
results=[]

def planned(inputs):return subject.wire.parse_json(inputs[1])['requests']
def text_index(inputs):return next(i for i,r in enumerate(planned(inputs)) if r['arm']['representation']=='text_plus_json')
def edit_content(inputs,index,edit):
    parsed=subject.wire.parse_json(fixture.content(inputs,index));edit(parsed)
    fixture.setcontent(inputs,subject.wire.canonical(parsed).decode(),index)
def rebound_manifest(inputs,edit):
    doc=subject.wire.parse_json(inputs[1]);edit(doc)
    for row in doc['requests']:row['request_sha256']=subject.digest({k:v for k,v in row.items() if k!='request_sha256'})
    inputs[1]=subject.wire.canonical(doc);inputs[3]['sources']['manifest']['sha256']=subject.sha(inputs[1])
    for row in inputs[0]['requests']:row['metadata']['source_manifest_sha256']=subject.sha(inputs[1])

def case(name,mutate=lambda i:None,valid=12,failure=None,inspect=lambda r,i:None,ascii_input=False):
    inputs=list(fixture.fixture());mutate(inputs)
    directory=OUT/name;directory.mkdir(exist_ok=True)
    normalized_raw=(json.dumps(inputs[0],ensure_ascii=True,separators=(',',':')).encode()
                    if ascii_input else subject.wire.canonical(inputs[0]))
    blobs={'normalized.json':normalized_raw,'source-manifest.json':inputs[1],
           'config.json':inputs[2],'policy.json':subject.wire.canonical(inputs[3])}
    for filename,raw in blobs.items():(directory/filename).write_bytes(raw)
    try:
        report=subject.evaluate(normalized_raw,inputs[1],inputs[2],inputs[3])
    except Exception as error:
        assert failure is not None and failure in str(error),(name,str(error))
        result={'case':name,'passed':True,'expected_exception':type(error).__name__,'code':str(error)}
    else:
        assert failure is None,name
        assert report['planned_requests']==len(report['rows'])==12
        assert report['all_choices_valid_requests']==valid,(name,report['all_choices_valid_requests'])
        assert report['semantic_accuracy'] is None and report['winner'] is None
        assert report['paid_calls']==report['network_calls']==0 and report['native_cpp_execution'] is False
        inspect(report,inputs)
        encoded=subject.serialize_report(report)
        assert subject.wire.parse_json(encoded)==report,name
        (directory/'report.json').write_bytes(encoded)
        result={'case':name,'passed':True,'valid_requests':valid,
                'locally_valid_requests':report['locally_all_choices_valid_requests'],
                'report_sha256':subject.sha(encoded)}
    (directory/'result.json').write_bytes(subject.wire.canonical(result))
    results.append(result)

def assert_text_failure(report,inputs):
    index=text_index(inputs);choice=report['rows'][index]['choices'][0]
    assert choice['failure']['code']=='text_annotation_mismatch'
    assert choice['first_content_utf8']==fixture.content(inputs,index)
    assert choice['first_content_hex']==fixture.content(inputs,index).encode().hex()

case('01_baseline_unicode_leaf')
case('02_trimmed_public_text',lambda i:edit_content(i,text_index(i),lambda p:p.update(text=p['text'].strip())),11,inspect=assert_text_failure)
case('03_nfd_public_text',lambda i:edit_content(i,text_index(i),lambda p:p.update(text=unicodedata.normalize('NFD',p['text']))),11,inspect=assert_text_failure)
case('04_extra_crlf_public_text',lambda i:edit_content(i,text_index(i),lambda p:p.update(text=p['text']+'\r\n')),11,inspect=assert_text_failure)
case('05_nonstring_public_text',lambda i:edit_content(i,text_index(i),lambda p:p.update(text=['wrong type'])),11)
case('06_wrong_wire_schema',lambda i:edit_content(i,text_index(i),lambda p:p.update(schema='loom.graph_reply/2')),11)
case('07_no_omit_extra_text_on_identity_arm',lambda i:edit_content(i,0,lambda p:p.update(text=p['nodes'][0]['text'])),11)
case('08_duplicate_json_keys',lambda i:fixture.setcontent(i,'{"schema":"first","schema":"second"}'),11)
case('09_fenced_json_no_repair',lambda i:fixture.setcontent(i,'```json\n'+fixture.content(i)+'\n```'),11)
case('10_text_value_is_object',lambda i:fixture.setcontent(i,{'raw':'JSON object, not model string'}),11)

def siblings(inputs):
    choices=inputs[0]['responses'][0]['projection']['choices'];choices.append(deepcopy(choices[0]));choices.extend([None,{'message':{'content':'{bad'}}])
def check_siblings(report,inputs):
    row=report['rows'][0];assert row['choice_count']==4
    assert [c['choice_index'] for c in row['choices']]==[0,1,2,3]
    assert row['choices'][0]['mechanical_validity'] and row['choices'][1]['mechanical_validity']
    assert not row['choices'][2]['mechanical_validity'] and not row['choices'][3]['mechanical_validity']
    assert row['choices'][2]['choice'] is None
    assert list(row['repeated_content_sha256_counts'].values())==[2]
case('11_all_good_bad_repeated_choices_preserved',siblings,11,inspect=check_siblings)
case('12_projection_answers_ambiguity',lambda i:i[0]['responses'][0]['projection'].update(answers={}),11)
case('13_missing_projection_retained',lambda i:i[0]['responses'][0].update(projection=None),11,
     inspect=lambda r,i:None if r['rows'][0]['responses']==[i[0]['responses'][0]] else (_ for _ in ()).throw(AssertionError()))
case('14_empty_choice_list_preserved',lambda i:i[0]['responses'][0]['projection'].update(choices=[]),11)
case('15_duplicate_full_response_preserved',lambda i:i[0]['responses'].append(deepcopy(i[0]['responses'][0])),11,
     inspect=lambda r,i:None if len(r['rows'][0]['responses'])==r['rows'][0]['choice_count']==2 else (_ for _ in ()).throw(AssertionError()))
case('16_unmapped_capture_qualifies_global_integrity',lambda i:i[0]['responses'].append({'operation_id':'fabricated-orphan','projection':{'choices':[{'message':{'content':'unchanged orphan'}}]}}),0,
     inspect=lambda r,i:None if len(r['unmapped_responses'])==1 and r['locally_all_choices_valid_requests']==12 else (_ for _ in ()).throw(AssertionError()))

def source_component(inputs):
    index=text_index(inputs);rebound_manifest(inputs,lambda d:d['requests'][index]['arm'].update(components=[]))
case('17_projection_requires_exact_declared_component',source_component,11)
def tamper_config(inputs,field,value):
    config=subject.wire.parse_json(inputs[2]);config['sources']['reply_compiler'][field]=value
    inputs[2]=subject.wire.canonical(config);inputs[3]['sources']['config']['sha256']=subject.sha(inputs[2])
case('18_compiler_hash_tamper',lambda i:tamper_config(i,'sha256','0'*64),failure='followup_pinned_git_source_hash_drift')
case('19_mutable_compiler_git_reference',lambda i:tamper_config(i,'commit','HEAD'),failure='followup_full_immutable_commit_required')
case('20_required_instrument_pin_removed',lambda i:i[3]['instrument_files_sha256'].pop('loom/tools/structure/agentic_graph_v1/packet.py'),failure='instrument_dependency_binding_missing')
case('21_model_missing_no_config_fallback',lambda i:(i[0]['responses'][0]['projection'].pop('model'),i[0]['rows'][0].pop('response_model')),11)

def accounting_flags(inputs):
    inputs[0]['rows'][0].update(completed=False,state='uncertain',http_status=503,billing_replay_verified=False,response_ledger_bound=False,actual_cost_usd=None)
    inputs[0]['responses'][0]['projection'].update(model='literal/fabricated-other-model',provider='literal other provider')
def check_flags(report,inputs):
    row=report['rows'][0];assert row['billing_and_resource_rows']==[inputs[0]['rows'][0]]
    assert row['billing_or_identity_verification_performed_here'] is False
    assert report['billing_or_identity_verification_performed_here'] is False
    assert row['choices'][0]['compilation']['diff']['origin']['model']=='literal/fabricated-other-model'
case('22_mechanics_not_billing_or_model_verification',accounting_flags,12,inspect=check_flags)

def surrogate(inputs):fixture.setcontent(inputs,'\ud800')
def check_surrogate(report,inputs):
    choice=report['rows'][0]['choices'][0]
    assert choice['choice']['message']['content']=='\ud800'
    assert choice['failure']['type']=='UnicodeEncodeError'
    assert choice['first_content_sha256'] is None and choice['first_content_utf8'] is None
case('23_lone_surrogate_reversible_report',surrogate,11,inspect=check_surrogate,ascii_input=True)

assert Path(subject.__file__).read_bytes()==BEFORE
(OUT/'programme_followup_results_v1.py').write_bytes(BEFORE)
(OUT/'results.json').write_bytes(subject.serialize_report({'source_sha256':EXPECTED,'fake_only':True,'cases':results,'passed':len(results)}))
print(json.dumps({'source_sha256':EXPECTED,'independent_cases_passed':len(results),'directory':str(OUT)},indent=2))
