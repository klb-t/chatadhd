"""Replay saved fabricated fixtures against exact archived modules.

Usage: python replay_saved_negatives.py --repository /path/to/public/repository
Requires the public dependency hashes and immutable Git objects bound by inputs.
No original model outputs, credentials or network are needed or read.
"""
from pathlib import Path
import argparse,importlib.util,json,sys,tempfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repository',required=True,type=Path)
parser.add_argument('--archive',type=Path,default=Path(__file__).resolve().parent)
args=parser.parse_args();sys.path.insert(0,str(args.repository.resolve()))
from loom.tools.structure import openrouter_runner as wire

def load_candidate(path,label):
    spec=importlib.util.spec_from_file_location('loom.tools.structure.archived_followup_'+label,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

outcomes=[]
for label,expected in [('before',0),('after',1)]:
    directory=args.archive/('pattern-extra-diff-'+label)
    module=load_candidate(directory/'programme_followup_results_v1.py','pattern_'+label)
    result=module.evaluate((directory/'unused_diff_field-normalized.json').read_bytes(),
        (directory/'manifest.json').read_bytes(),(directory/'config.json').read_bytes(),
        wire.parse_json((directory/'policy.json').read_bytes()),references_raw=(directory/'references.json').read_bytes())
    assert result['all_choices_valid_requests']==expected
    outcomes.append({'probe':'pattern_extra_diff','source_variant':label,'valid_requests':expected})

for label,expected_success in [('before',False),('after',True)]:
    directory=args.archive/('surrogate-choice-'+label)
    module=load_candidate(directory/'programme_followup_results_v1.py','surrogate_'+label)
    with tempfile.TemporaryDirectory() as tmp:
        target=Path(tmp)/'result.json';argv=[]
        for name in ['normalized','source-manifest','config','policy']:argv.extend(['--'+name,str(directory/(name+'.json'))])
        argv.extend(['--output',str(target)])
        try:module.main(argv);success=True
        except UnicodeEncodeError:success=False
        assert success is expected_success
        if success:
            report=wire.parse_json(target.read_bytes());choice=report['rows'][0]['choices'][0]
            assert report['all_choices_valid_requests']==11
            assert choice['choice']['message']['content']=='\ud800'
            assert choice['first_content_sha256'] is None and choice['first_content_utf8'] is None
        outcomes.append({'probe':'lone_surrogate_report','source_variant':label,'cli_success':success})
print(json.dumps({'all_four_saved_before_after_replays_pass':True,'outcomes':outcomes},indent=2))
