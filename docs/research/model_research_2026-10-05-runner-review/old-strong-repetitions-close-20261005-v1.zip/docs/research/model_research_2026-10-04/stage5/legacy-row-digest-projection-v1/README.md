# Explicit legacy row-digest scoring view v1

The repeated source-prepared records received new IDs/repetition numbers while retaining legacy `request_sha256` values that commit the entire source row excluding that field. The paid request BODY digests were correct. The earlier body/cost peer PASS remains unchanged; its instrument-specific row-digest omission is disclosed separately in `../old-strong-repetition-row-digest-supplement-v1/`.

`project.py` creates a new source/normalized/policy view and full lineage. Policy paths define the hash domains. It recomputes only source row digests, then changes only the copied normalized request metadata `source_manifest_sha256` and the copied evaluator policy source commitment. Actual BODY bytes/hashes, IDs/order, paid manifest commitments, first responses and billing rows remain identical as decoded DATA. Serialization uses the unchanged `openrouter_runner.canonical` (sorted compact UTF-8 JSON, no newline). Original files are never rewritten. The original policy refers to the original twelve-row preparation; `--policy-is-template` explicitly discloses that original commitment when binding a selected repetition source view.

From repository root, replace STAGE with 3 or 4 and choose a **new** output directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python docs/research/model_research_2026-10-04/stage5/legacy-row-digest-projection-v1/project.py --source docs/research/model_research_2026-10-04/stage5/old-stageSTAGE-repetitions-v1/source-prepared.json --normalized docs/research/model_research_2026-10-04/stage5/old-stageSTAGE-results-v1/NORMALIZED.json --policy docs/research/model_research_2026-10-04/followup-results/stageSTAGE-policy.json --policy-is-template --output-dir /tmp/explicit-stageSTAGE-scoring-view
```

Use SOURCE/NORMALIZED/POLICY from that view with the unchanged `loom.tools.structure.programme_followup_results_v1` CLI, the existing final-verified-lineage config, and (Stage3 only) its stage3/references.json. The exact actual reports are separately retained beside each original NORMALIZED file as MECHANICAL_RESULTS.json. Actual input binding passes all12 planned requests; Stage3 report-format checks reject all8, while Stage4 pinned Python graph-reply compilation accepts all4. These mechanical outcomes do not score source semantics, verify authentication, execute native C++, write CABI/canonical state or adopt a method.

`verify_fake.py` replays the existing full before/after FAKE witness and eight rejection controls (body/source metadata/grid/policy):

```sh
PYTHONDONTWRITEBYTECODE=1 python docs/research/model_research_2026-10-04/stage5/legacy-row-digest-projection-v1/verify_fake.py docs/research/model_research_2026-10-04/stage5/old-strong-repetition-row-digest-supplement-v1/VERIFICATION.json
```

Its output reproduces FAKE_VERIFICATION.json exactly (ignoring the stdout newline),10/10 PASS. No actual model content is read by that fake replay. ACTUAL_VERIFICATION.json separately checks all12 actual views against original public inputs, complete request/response inventories, first-content hashes, exact paid bodies, retained billing fields and unchanged instrument hashes. The actual public attested bills sum to0.1489102 USD for8 Stage3 requests and0.0206444 USD for4 Stage4 requests. This is selected-field public source commitment replay; original full provider captures and owner account/billing reconciliation remain outside this audit. No private/key/ledger/account data or network is accessed.

The helper imports only the unchanged canonical strict JSON utility. Archive reproduction must retain that exact source dependency plus the bound original inputs, derived views, lineage, mechanical reports, and full original FAKE supplement. Source semantic manual reviews use the original first outputs and unchanged preregistered criteria; no output repair or literal reference-template substitution is licensed.
