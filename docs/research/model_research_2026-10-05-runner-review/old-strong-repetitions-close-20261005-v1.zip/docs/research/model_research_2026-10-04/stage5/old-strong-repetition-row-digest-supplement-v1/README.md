# Legacy row-digest oversight: separate offline supplement

The earlier body/cost peer receipt remains unchanged. **All eight Stage3 and four Stage4 repetition source rows carry a stale legacy whole-row digest** after their `id` and `repetition` were changed. The paid manifest's `request_sha256` hashes exact BODY bytes and is correct. These are separate hash domains.

The prior audit verified bodies, source row differences, selections, order, original floors and full reservations. It did not execute the instrument's legacy row-digest guard. Its broad freeze PASS therefore omitted a scoring-metadata defect; this supplement records that omission without replacing the original evidence or changing its correct body/cost findings.

The explicit offline scoring projection is:

1. Keep the original source-prepared bytes, paid manifest and all first captures immutable. Clone source data and recompute only each source row's legacy `request_sha256` as the canonical digest of that complete row excluding the field itself.
2. Serialize the derived source with a declared canonical byte recipe and retain both raw source hashes plus every row's before/after mapping.
3. Clone normalized scoring DATA. Require every existing request's metadata source SHA to equal the original source hash, then change only `requests[*].metadata.source_manifest_sha256` to the derived source hash. Preserve the actual paid-manifest hashes, BODY hashes/bytes, operation IDs, order, response/billing records, model/provider identities and parameters.
4. Copy the evaluator policy and bind `sources.manifest.sha256` to the derived raw source hash. Retain this policy/source/metadata projection as explicit provenance. It must never be represented as original provider-captured metadata.

Fabricated metadata witnesses reproduce the exact guard behavior with the existing evaluator: stale source produces row-hash failures; correcting source alone produces source-metadata binding failures; correcting source, copied request metadata and policy together admits all 8 + 4 fabricated valid proposals. Unexpected original metadata hashes, a stale policy hash and a changed BODY remain rejected. No answer repair, field bypass, actual scoring or paid retry is involved.

`VERIFICATION.json` retains complete base64 before/after source bytes, every digest/unchanged-BODY mapping, full fabricated normalized before/after views, policy snapshots and per-slot guard traces. Fabricated compiler acceptance is solely a binding/format witness; it does not measure any actual model's semantics or mechanical quality. No old/new response file or private ledger/key/account file was read. No network/provider call, paid operation, functional code change, original-artifact edit or prior PASS modification occurred. The prior receipt was read only to bind and verify its unchanged hash. No actual score is written.
