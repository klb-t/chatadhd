"""Replay the existing ten fake projection checks; no actual model data is read."""
import base64
from copy import deepcopy
import json
from pathlib import Path
import sys
import project


def verify(witness_raw):
    witness = json.loads(witness_raw)
    checks = []
    for stage in witness['stages']:
        label = 'stage' + str(stage['stage'])
        source = base64.b64decode(stage['source_before_raw_bytes_base64'])
        normalized = project.wire.canonical(stage['fake_normalized_before'])
        policy = project.wire.canonical(stage['before_policy'])
        outputs, _ = project.project(source, normalized, policy, policy_is_template=True)
        assert outputs['SOURCE.json'] == base64.b64decode(stage['source_derived_raw_bytes_base64'])
        assert project.wire.parse_json(outputs['NORMALIZED.json']) == stage['fake_normalized_derived']
        assert project.wire.parse_json(outputs['POLICY.json']) == stage['after_policy']
        checks.append(label + '_full_before_after_match')
        for control in ('metadata', 'body', 'grid', 'policy'):
            n = deepcopy(stage['fake_normalized_before'])
            p = deepcopy(stage['before_policy'])
            if control == 'metadata':
                n['requests'][0]['metadata']['source_manifest_sha256'] = '0' * 64
            elif control == 'body':
                n['requests'][0]['body']['model'] = 'fake-tampered-body'
            elif control == 'grid':
                n['planned_operation_ids'] = []
            else:
                p['sources']['manifest']['sha256'] = '0' * 64
            try:
                project.project(source, project.wire.canonical(n), project.wire.canonical(p),
                                policy_is_template=(control != 'policy'))
            except ValueError:
                checks.append(label + '_reject_' + control)
            else:
                raise AssertionError('negative control accepted: ' + control)
    return {'schema': 'loom.legacy_projection_fake_verification/1', 'result': 'PASS',
            'helper_sha256': project.sha(Path(project.__file__).read_bytes()),
            'before_after_full_witness_sha256': project.sha(witness_raw),
            'checks': checks, 'passed': len(checks), 'actual_scores_written': 0,
            'model_outputs_read': 0}


if __name__ == '__main__':
    result = verify(Path(sys.argv[1]).read_bytes())
    print(project.wire.canonical(result).decode())
