"""Explicit offline scoring views; original captures and paid requests stay immutable.

Paths and row/body hash domains come from the existing evaluator policy. This
helper changes only row digests, copied request metadata's source commitment,
and the copied evaluator policy's source commitment. No evaluator, corpus,
transport, scoring, output repair or model-specific preset is implemented here.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
from pathlib import Path
import sys

REPOSITORY_ROOT = Path(__file__).resolve().parents[5]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))
from loom.tools.structure import openrouter_runner as wire


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def at(value, path):
    for part in path:
        value = value[part]
    return value


def project(source_raw, normalized_raw, policy_raw, *, policy_is_template=False):
    if not all(isinstance(x, bytes) for x in (source_raw, normalized_raw, policy_raw)):
        raise ValueError('projection_exact_input_bytes_required')
    source, normalized, policy = map(wire.parse_json, (source_raw, normalized_raw, policy_raw))
    if policy.get('schema') != 'loom.programme_followup_results_policy/1':
        raise ValueError('projection_policy_schema')
    if normalized.get('schema') != policy['normalized_schema']:
        raise ValueError('projection_normalized_schema')
    binding = policy['sources']['manifest']
    if source.get('schema') != binding.get('schema', source.get('schema')):
        raise ValueError('projection_source_schema')
    source_before_sha = sha(source_raw)
    if binding['sha256'] != source_before_sha and not policy_is_template:
        raise ValueError('projection_original_policy_source_binding')
    prepared = policy['prepared']
    rows = at(source, prepared['requests_path'])
    ids = [at(row, prepared['id_path']) for row in rows]
    if (not rows or any(not isinstance(x, str) or not x for x in ids)
            or len(ids) != len(set(ids))):
        raise ValueError('projection_unique_prepared_inventory')
    requests = normalized['requests']
    operation_ids = [r['operation_id'] for r in requests]
    metadata_ids = [r['metadata']['prepared_request_id'] for r in requests]
    if (normalized.get('planned_operations') != len(rows) or len(requests) != len(rows)
            or len(set(operation_ids)) != len(operation_ids)
            or len(set(metadata_ids)) != len(metadata_ids) or set(metadata_ids) != set(ids)
            or len(normalized.get('planned_operation_ids', [])) != len(rows)
            or set(normalized['planned_operation_ids']) != set(operation_ids)):
        raise ValueError('projection_exact_planned_bijection')
    source_after = deepcopy(source)
    after_rows = at(source_after, prepared['requests_path'])
    digest_field = prepared['row_digest_field']
    row_changes = []
    by_prepared = {r['metadata']['prepared_request_id']: r for r in requests}
    for index, (row, projected_row) in enumerate(zip(rows, after_rows)):
        ident = ids[index]
        request = by_prepared[ident]
        body = at(row, prepared['body_path'])
        if (request['body'] != body or request['request_sha256'] != sha(wire.canonical(body))
                or request['metadata']['source_manifest_sha256'] != source_before_sha):
            raise ValueError('projection_before_body_or_source_binding')
        if not isinstance(row.get(digest_field), str) or len(row[digest_field]) != 64:
            raise ValueError('projection_original_row_digest_required')
        fresh = sha(wire.canonical({k: v for k, v in row.items() if k != digest_field}))
        projected_row[digest_field] = fresh
        unchanged = deepcopy(projected_row)
        unchanged[digest_field] = row[digest_field]
        if unchanged != row:
            raise AssertionError('projection_source_change_outside_row_digest')
        row_changes.append({'index': index, 'prepared_request_id': ident,
                            'operation_id': request['operation_id'],
                            'digest_field': digest_field, 'before': row[digest_field], 'after': fresh,
                            'changed': row[digest_field] != fresh,
                            'paid_body_sha256_unchanged': request['request_sha256']})
    source_after_raw = wire.canonical(source_after)
    source_after_sha = sha(source_after_raw)
    normalized_after = deepcopy(normalized)
    request_changes = []
    for index, request in enumerate(normalized_after['requests']):
        request['metadata']['source_manifest_sha256'] = source_after_sha
        expected = deepcopy(request)
        expected['metadata']['source_manifest_sha256'] = source_before_sha
        if expected != requests[index]:
            raise AssertionError('projection_normalized_change_outside_source_metadata')
        request_changes.append({'pointer': '/requests/' + str(index) + '/metadata/source_manifest_sha256',
                                'operation_id': request['operation_id'],
                                'before': source_before_sha, 'after': source_after_sha})
    for field in normalized:
        if field != 'requests' and normalized_after[field] != normalized[field]:
            raise AssertionError('projection_normalized_other_field_changed')
    policy_after = deepcopy(policy)
    policy_after['sources']['manifest']['sha256'] = source_after_sha
    restored_policy = deepcopy(policy_after)
    restored_policy['sources']['manifest']['sha256'] = binding['sha256']
    if restored_policy != policy:
        raise AssertionError('projection_policy_change_outside_source_commitment')
    outputs = {'SOURCE.json': source_after_raw,
               'NORMALIZED.json': wire.canonical(normalized_after),
               'POLICY.json': wire.canonical(policy_after)}
    lineage = {'schema': 'loom.explicit_legacy_row_digest_projection/1',
               'helper_sha256': sha(Path(__file__).read_bytes()),
               'input_sha256': {'source': source_before_sha, 'normalized': sha(normalized_raw),
                                'policy': sha(policy_raw)},
               'policy_is_explicit_template': policy_is_template,
               'original_policy_source_sha256': binding['sha256'],
               'output_sha256': {name: sha(raw) for name, raw in outputs.items()},
               'serialization': 'openrouter_runner.canonical; UTF8 sorted compact JSON, no newline',
               'row_digest_changes': row_changes, 'request_metadata_changes': request_changes,
               'policy_change': {'pointer': '/sources/manifest/sha256', 'before': binding['sha256'],
                                 'after': source_after_sha},
               'planned_requests': len(rows),
               'invariants': {'only_source_row_digest_fields_changed': True,
                              'only_normalized_request_source_metadata_changed': True,
                              'only_policy_source_manifest_sha_changed': True,
                              'exact_paid_body_hashes_and_bodies_preserved': True,
                              'paid_manifest_hash_operation_ids_order_responses_billing_preserved': True,
                              'original_inputs_edited': False},
               'boundary': 'Derived scoring metadata view, never original provider-captured metadata. '
                           'No response repair, scoring, authentication, native/CABI write or paid call.',
               'new_model_calls': 0, 'network_calls': 0, 'actual_scores_written': 0}
    return outputs, lineage


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--normalized', type=Path, required=True)
    parser.add_argument('--policy', type=Path, required=True)
    parser.add_argument('--policy-is-template', action='store_true',
                        help='Explicitly retain/rebind an original policy source commitment in lineage.')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    inputs = {name: path.read_bytes() for name, path in
              [('source', args.source), ('normalized', args.normalized), ('policy', args.policy)]}
    outputs, lineage = project(inputs['source'], inputs['normalized'], inputs['policy'],
                               policy_is_template=args.policy_is_template)
    lineage['input_paths'] = {'source': str(args.source), 'normalized': str(args.normalized),
                             'policy': str(args.policy)}
    if args.output_dir.exists():
        raise ValueError('projection_output_directory_must_be_new')
    args.output_dir.mkdir(parents=True)
    for name, raw in outputs.items():
        with (args.output_dir / name).open('xb') as stream:
            stream.write(raw)
    with (args.output_dir / 'LINEAGE.json').open('xb') as stream:
        stream.write(wire.canonical(lineage))
    print(wire.canonical({'planned_requests': lineage['planned_requests'],
                          'row_digest_changes': sum(c['changed'] for c in lineage['row_digest_changes']),
                          'source_sha256': lineage['output_sha256']['SOURCE.json'],
                          'new_model_calls': 0}).decode())


if __name__ == '__main__':
    main()
