from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256SUMS.json').read_bytes())
for name,expected in manifest.items():
    path=Path(name)
    assert not path.is_absolute() and '..' not in path.parts
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,name
print(f'Verified {len(manifest)} files')
