# Portable runner review proof

All credentials, API responses, model names, billing metadata and ledgers in the fixtures are fabricated. No real key, ledger, provider response, holdout, or private export is included. Transport calls are injected Python fakes; reproduction makes no network calls.

On a POSIX system with Python 3, run `python verify.py` and `python reproduce.py` from this directory. The probes need only the Python standard library; optional paid-transport dependencies are not invoked.

`snapshots/initial` preserves the first reviewed source. `snapshots/first-fixes` preserves the first accepted fixes. `snapshots/resume-before` preserves the STOP-resolution deletion defect. `snapshots/resume-after` preserves the corrected source. Captured exact inputs, response bytes, SQLite ledgers and results are under `captured` and the resolution fixture directories. Original captures retain their exact old path strings; reproduction resolves its own inputs and creates new temporary directories.

| Counterexample | Before | Expected corrected behavior |
| --- | --- | --- |
| Mixed admitted cheap Jev then expensive chat stage | False durable stop after first call | Both admitted requests complete |
| Same stage ID with changed manifest and disjoint new IDs | New calls accepted, stage-total guard bypassed | Block before new network calls |
| Duplicate generation for distinct operations | Both completions accepted | Stop without duplicate adoption |
| One stale key-usage GET | Durable stop | GET-only reconciliation, one POST |
| One generation 404 before receipt appears | Uncertain stop | GET-only reconciliation, one POST |
| Persistent lower usage under strict policy | Durable stop | Still stops after bounded GET reads |
| Delete immutable resolution JSON after GET-only STOP resolution | Paid resume accepted | Block before network calls |
| Explicit captured POST 200 plus generation 404 later becomes exact generation 200 | Ordinary run/reconcile remain blocked | Explicit GET-only append-only proof resolves; old rows and captures unchanged |
| Late generation cost/model/ID/BYOK mismatch | Unresolved STOP | Still blocked, zero POST and no proof insertion |
| Delete appended captured-attempt proof | Completed projection exists | Block replay before network calls |

The opt-in lower-usage policy retains observed provider usage and the failed strict equality check. It uses unique replayed credit receipts, preserves cumulative costs, and still enforces both the provider remaining balance and the local cap. Higher/unknown usage, unknown costs and forged or duplicated billing proofs remain blocking.

`current-tests` holds the current focused regression sources for review. The portable reproduction uses its bundled source snapshots and fabricated fixtures independently of a repository checkout.
