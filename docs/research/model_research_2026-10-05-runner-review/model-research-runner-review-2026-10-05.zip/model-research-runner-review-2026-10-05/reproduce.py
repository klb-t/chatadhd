"""Offline reproduction; standard Python and fabricated transports only."""
from pathlib import Path
import json,subprocess,sys
root=Path(__file__).resolve().parent
expected_before={'mixed_per_operation':'stopped','mixed_stage_total':'completed','lagging_key_usage':'stopped','duplicate_generation':'completed','same_stage_changed_manifest':'completed','transient_key_lag':'stopped','transient_generation_lag':'stopped'}
expected_after={**expected_before,'mixed_per_operation':'completed','duplicate_generation':'stopped','same_stage_changed_manifest':'blocked','transient_key_lag':'completed','transient_generation_lag':'completed'}
for name,script in [('initial','probes.py'),('first-fixes','probes.py'),('resume-before','repro_missing_resolution.py'),('resume-after','repro_missing_resolution.py')]:
    result=subprocess.run([sys.executable,str(root/'snapshots'/name/script)],check=True,capture_output=True,text=True)
    value=json.loads(result.stdout)
    if script=='probes.py':
        statuses={k:v.get('status') for k,v in value.items()}
        assert statuses==(expected_before if name=='initial' else expected_after),(name,statuses)
        print(name,json.dumps(statuses,sort_keys=True))
    else:
        status=value['resumed']['status']; posts=sum(method=='POST' for method,_ in value['resume_calls'])
        assert (status,posts)==(('completed',1) if name=='resume-before' else ('blocked',0)),(name,status,posts)
        print(name,json.dumps({'resume_status':status,'resume_reason':value['resumed'].get('reason'),'resume_posts':posts},sort_keys=True))
result=subprocess.run([sys.executable,str(root/'snapshots/resume-after/repro_captured_pending.py')],check=True,capture_output=True,text=True)
captured=json.loads(result.stdout)
for name,value in captured.items():
    assert value['original_rows_and_captures_unchanged'] is True,name
    assert not any(method=='POST' for method,_ in value['late_calls']),name
    assert value['checks']['ordinary_run']['calls']==[] and value['checks']['ordinary_reconcile']['calls']==[],name
    if name=='success':
        assert value['late_resolution']['status']=='stop_resolved_read_only' and value['projection_count']==1 and value['active_stop_present'] is False
        assert value['checks']['missing_late_proof']['outcome']['status']=='blocked' and value['checks']['missing_late_proof']['calls']==[]
    else:
        assert value['late_resolution']['status']=='blocked' and value['projection_count']==0 and value['active_stop_present'] is True,name
print('captured-pending',json.dumps({k:v['late_resolution']['status'] for k,v in captured.items()},sort_keys=True))
