"""Portable, synthetic STOP resolution deletion regression. No network."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime, timezone
import json, tempfile, shutil, hashlib
import research_programme_runner as runner

ROOT = Path(__file__).resolve().parent
def wire(value): return json.dumps(value, separators=(',', ':')).encode()
class Fake:
    def __init__(self): self.calls=[]; self.count=0
    def __call__(self, method, route, body=None, params=None):
        self.calls.append((method,route))
        if route=='key': value={'data':{'usage':'0','limit':'5','limit_remaining':'5','byok_usage':'0','include_byok_in_limit':False,'is_management_key':False,'limit_reset':None}}
        elif route=='model_endpoints': value={'data':{'id':'fake/model','endpoints':[{'model_id':'fake/model','provider_name':'Fake','pricing':{'prompt':'0.0001','completion':'0.0002','discount':'0'}}]}}
        elif method=='POST':
            self.count+=1
            value={'id':f'gen-{self.count}','model':'fake/model','provider':'Fake','usage':{'cost':'0.01','is_byok':False,'prompt_tokens':1,'completion_tokens':1}}
        elif route=='generation': value={'data':{'id':f'gen-{self.count}','model':'fake/model','provider_name':'Fake','api_type':'completions','total_cost':'0.01','is_byok':False}}
        else: raise AssertionError(route)
        return {'http_status':200,'latency_seconds':0,'raw':wire(value)}

def main():
    original=ROOT/'fixture-missing-resolution'
    root=Path(tempfile.mkdtemp(prefix='runner-review-resolution-delete-'))
    shutil.copytree(original/'repo',root/'repo')
    policy=json.loads((original/'policy.json').read_bytes()); policy['provider_usage_lag']={'mode':'strict'}
    for options in policy['read_only_reconciliation'].values(): options['delay_seconds']='0'
    evidence=json.loads((original/'evidence.json').read_bytes()); evidence['fx']['raw_file']=str(root/'repo'/'fx.json')
    now=datetime.now(timezone.utc); evidence['fx']['checked_at']=now.isoformat(); evidence['fx']['rate_date']=now.date().isoformat()
    keydir=root/'key'; keydir.mkdir(mode=0o700); key=keydir/'key'; key.write_text('fabricated-offline-review-key'); key.chmod(0o600)
    send=Fake(); args=(root/'repo'/'manifest.json',evidence,root/'private',key,root/'repo')
    stopped=runner.run_stage(policy,*args,transport_fn=send)
    policy['provider_usage_lag']={'mode':'allow_verified_lower_usage','authority_ref':'fabricated-review-authority'}
    resolved=runner.reconcile_stop(policy,*args,transport_fn=send)
    path=next((root/'private').glob('*.resolution.json')); (root/'resolution-deleted-original.json').write_bytes(path.read_bytes()); path.unlink()
    send.calls.clear()
    try: resumed=runner.run_stage(policy,*args,transport_fn=send)
    except runner.ProgrammeError as error: resumed={'status':'blocked','reason':str(error)}
    result={'fixture_root':str(root),'stopped':stopped,'resolved':resolved,'resumed':resumed,'resume_calls':send.calls}
    (root/'result.json').write_bytes(wire(result)); print(json.dumps(result,indent=2))

if __name__=='__main__': main()
