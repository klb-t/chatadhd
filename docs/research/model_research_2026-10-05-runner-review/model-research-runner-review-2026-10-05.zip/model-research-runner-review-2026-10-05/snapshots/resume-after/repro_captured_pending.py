"""Only injected fabricated transports and temporary fabricated evidence."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal
import hashlib,json,tempfile,shutil,sqlite3
import research_programme_runner as runner

ROOT=Path(__file__).resolve().parent
def wire(value): return json.dumps(value,separators=(',',':')).encode()
class Fake:
    def __init__(self): self.count=0; self.pending=True; self.calls=[]; self.late_changes={}
    def __call__(self,method,route,body=None,params=None):
        self.calls.append((method,route))
        if route=='key':
            usage=Decimal('.01')*self.count
            value={'data':{'usage':str(usage),'limit':'5','limit_remaining':str(5-usage),'byok_usage':'0','include_byok_in_limit':False,'is_management_key':False,'limit_reset':None}}
        elif route=='model_endpoints': value={'data':{'id':'fake/model','endpoints':[{'model_id':'fake/model','provider_name':'Fake','pricing':{'prompt':'0.0001','completion':'0.0002','discount':'0'}}]}}
        elif method=='POST':
            self.count+=1
            value={'id':f'gen-{self.count}','model':'fake/model','provider':'Fake','usage':{'cost':'0.01','is_byok':False,'prompt_tokens':1,'completion_tokens':1}}
        elif route=='generation':
            if self.count==2 and self.pending: return {'http_status':404,'raw':b'{"error":{"message":"pending"}}','latency_seconds':0}
            data={'id':f'gen-{self.count}','model':'fake/model','provider_name':'Fake','api_type':'completions','total_cost':'0.01','is_byok':False}
            if not self.pending: data.update(self.late_changes)
            value={'data':data}
        else: raise AssertionError(route)
        return {'http_status':200,'latency_seconds':0,'raw':wire(value)}

def case(name,changes=None):
    original=ROOT/'fixture-missing-resolution'; root=Path(tempfile.mkdtemp(prefix='captured-review-'+name+'-'))
    shutil.copytree(original/'repo',root/'repo')
    policy=json.loads((original/'policy.json').read_bytes()); policy['provider_usage_lag']={'mode':'strict'}
    for options in policy['read_only_reconciliation'].values(): options['delay_seconds']='0'
    evidence=json.loads((original/'evidence.json').read_bytes()); evidence['fx']['raw_file']=str(root/'repo'/'fx.json')
    now=datetime.now(timezone.utc); evidence['fx']['checked_at']=now.isoformat(); evidence['fx']['rate_date']=now.date().isoformat()
    keydir=root/'key'; keydir.mkdir(mode=0o700); key=keydir/'key'; key.write_text('fabricated-offline-review-key'); key.chmod(0o600)
    args=(policy,root/'repo'/'manifest.json',evidence,root/'private',key,root/'repo'); send=Fake()
    stopped=runner.run_stage(*args,transport_fn=send)
    originals={path.name:path.read_bytes() for path in (root/'private'/'records').iterdir()}
    with sqlite3.connect(root/'private'/'ledger.sqlite3') as db: old_rows=db.execute('SELECT operation_id,payload FROM attempts ORDER BY rowid').fetchall()
    checks={}
    for label,action in [('ordinary_run',runner.run_stage),('ordinary_reconcile',runner.reconcile_stop)]:
        send.calls.clear()
        try: outcome=action(*args,transport_fn=send)
        except runner.ProgrammeError as error: outcome={'status':'blocked','reason':str(error)}
        checks[label]={'outcome':outcome,'calls':list(send.calls)}
    send.pending=False; send.late_changes=changes or {}; send.calls.clear()
    try: resolved=runner.reconcile_stop(*args,transport_fn=send,captured_pending=True)
    except ValueError as error: resolved={'status':'blocked','reason':str(error)}
    late_calls=list(send.calls)
    with sqlite3.connect(root/'private'/'ledger.sqlite3') as db:
        new_rows=db.execute('SELECT operation_id,payload FROM attempts ORDER BY rowid').fetchall()
        projection_count=db.execute('SELECT COUNT(*) FROM attempt_resolutions').fetchone()[0]
        stop_present=bool(db.execute("SELECT 1 FROM programme_state WHERE name='stop_reason'").fetchone())
    unchanged=old_rows==new_rows and all((root/'private'/'records'/name).read_bytes()==raw for name,raw in originals.items())
    replay=None
    if resolved.get('status')=='stop_resolved_read_only':
        send.calls.clear(); replay=runner.run_stage(*args,transport_fn=send); checks['saved_completed_replay']={'outcome':replay,'calls':list(send.calls)}
        proof=next((root/'private').glob('*.attempt-resolution.json')); (root/'deleted-attempt-proof-original.json').write_bytes(proof.read_bytes()); proof.unlink()
        send.calls.clear()
        try: deleted=runner.run_stage(*args,transport_fn=send)
        except runner.ProgrammeError as error: deleted={'status':'blocked','reason':str(error)}
        checks['missing_late_proof']={'outcome':deleted,'calls':list(send.calls)}
    result={'fixture_root':str(root),'stopped':stopped,'checks':checks,'late_resolution':resolved,'late_calls':late_calls,'original_rows_and_captures_unchanged':unchanged,'projection_count':projection_count,'active_stop_present':stop_present}
    (root/'policy.json').write_bytes(wire(policy)); (root/'evidence.json').write_bytes(wire(evidence)); (root/'result.json').write_bytes(wire(result))
    return result

if __name__=='__main__':
    result={name:case(name,changes) for name,changes in [('success',None),('cost-mismatch',{'total_cost':'0.011'}),('pair-mismatch',{'model':'other/model'}),('byok',{'is_byok':True}),('id-mismatch',{'id':'other-generation'})]}
    print(json.dumps(result,indent=2))
