"""Fabricated transports only; snapshots local immutable repro inputs/results."""
from pathlib import Path
import sys, json, hashlib, tempfile, os
from datetime import datetime, timezone
from decimal import Decimal
sys.path.insert(0, str(Path(__file__).resolve().parent))
import research_programme_runner as runner

ROOT = Path(__file__).resolve().parent
def wire(obj): return json.dumps(obj, separators=(',', ':')).encode()
def sha(raw): return hashlib.sha256(raw).hexdigest()

class Fake:
    def __init__(self, lag=False, duplicate=False, transient_lag=False, generation_lag=False):
        self.usage=Decimal(0); self.calls=[]; self.current=None; self.count=0
        self.lag=lag; self.duplicate=duplicate
        self.transient_lag=transient_lag; self.generation_lag=generation_lag; self.post_key_reads=0; self.generation_count=0
    def __call__(self, method, route, body=None, params=None):
        self.calls.append((method,route))
        if route=='model_endpoints':
            model=params['model_id']; low=model=='fake/low'
            result={'data':{'id':model,'endpoints':[{'model_id':model,'provider_name':'Fake',
                  'pricing':{'prompt':'0.00000005' if low else '0.00001',
                             'completion':'0' if low else '0.00002'}}]}}
        elif route=='key':
            if self.usage: self.post_key_reads += 1
            usage=Decimal(0) if self.lag or (self.transient_lag and self.post_key_reads==1) else self.usage
            result={'data':{'usage':str(usage),'limit':'5','limit_remaining':str(5-usage),
                'byok_usage':'0','include_byok_in_limit':False,'is_management_key':False,'limit_reset':None}}
        elif method=='POST':
            parsed=json.loads(body); self.count+=1
            cost=Decimal('0.00002') if parsed['model']=='fake/low' else Decimal('0.002')
            self.usage+=cost; ident='generation-1' if self.duplicate else f'generation-{self.count}'
            self.current={'id':ident,'model':parsed['model'],'provider_name':'Fake',
                'api_type':'decisions' if route=='jev' else 'completions','total_cost':str(cost),'is_byok':False}
            result={'id':ident,'model':parsed['model'],'provider':'Fake','usage':{'cost':str(cost),'is_byok':False}}
        elif route=='generation':
            self.generation_count += 1
            if self.generation_lag and self.generation_count==1:
                return {'http_status':404,'latency_seconds':0,'raw':b'{"error":{"message":"not-yet-available"}}'}
            result={'data':self.current}
        else: raise AssertionError(route)
        return {'http_status':200,'latency_seconds':0,'raw':wire(result)}

def probe(name, scope='per_operation', lag=False, duplicate=False, same_low=False, mutate_same_stage=False, transient_lag=False, generation_lag=False):
    root=Path(tempfile.mkdtemp(prefix='runner-review-'+name+'-'))
    repo=root/'repo'; repo.mkdir(exist_ok=True)
    keydir=root/'fake-credential'; keydir.mkdir(mode=0o700,exist_ok=True)
    key=keydir/'key'; key.write_text('fabricated-offline-credential'); key.chmod(0o600)
    low={'model':'fake/low','provider':{'only':['fake'],'allow_fallbacks':False},'state':{},'questions':[]}
    high=low if same_low else {'model':'fake/high','provider':{'only':['fake'],'allow_fallbacks':False},'messages':[],'max_tokens':100}
    bodies=[low] if lag or transient_lag or generation_lag else [low,high]
    ops=[]
    for i,b in enumerate(bodies):
        raw=wire(b); path=repo/f'request-{i}.json'; path.write_bytes(raw)
        is_low=b['model']=='fake/low'
        ops.append({'operation_id':f'op-{i}','route_id':'jev' if is_low else 'chat','request_file':path.name,
            'request_sha256':sha(raw),'model_id':b['model'],'provider_id':'fake',
            'units_upper_bounds':{'prompt':'500' if is_low else '1000','completion':'0' if is_low else '100','request':'1'}})
    manifest=repo/'manifest.json'; manifest.write_bytes(wire({'schema':'loom.research_programme_manifest/1','programme_id':'fake-programme','stage_id':'mixed-approved-stage','operations':ops}))
    policy=json.loads((ROOT/'runner-policy.json').read_bytes())
    policy.update(programme_id='fake-programme',usd_cap='5',provider_aliases={'fake':['Fake']})
    policy['escalation_guard']['scope']=scope
    policy['fx_snapshot']={'format':'json','rate_path':['rate'],'source_url_prefix':'https://fixture.invalid/','maximum_rate_age_seconds':86400}
    fx=repo/'fx.json'; fx.write_bytes(b'{"rate":"1.1"}')
    now=datetime.now(timezone.utc)
    evidence={'fx':{'base_currency':'EUR','quote_currency':'USD','usd_per_eur':'1.1','source_ref':'https://fixture.invalid/fx',
              'checked_at':now.isoformat(),'rate_date':now.date().isoformat(),'raw_file':str(fx),'raw_sha256':sha(fx.read_bytes())}}
    (repo/'policy.json').write_bytes(wire(policy)); (repo/'evidence.json').write_bytes(wire(evidence))
    send=Fake(lag=lag,duplicate=duplicate,transient_lag=transient_lag,generation_lag=generation_lag)
    result=runner.run_stage(policy,manifest,evidence,root/'ledger',key,repo,transport_fn=send)
    if mutate_same_stage:
        first_result=result
        original=manifest.read_bytes(); (repo/'manifest-first.json').write_bytes(original)
        changed=json.loads(original)
        for op in changed['operations']:
            op['operation_id'] += '-readmitted'
            op['units_upper_bounds']['prompt']='1000000'
        manifest.write_bytes(wire(changed))
        try:
            result=runner.run_stage(policy,manifest,evidence,root/'ledger',key,repo,transport_fn=send)
        except runner.ProgrammeError as error:
            result={'status':'blocked','reason':str(error)}
        result['first_result']=first_result
    result['calls']=send.calls; result['fixture_root']=str(root); (root/'result.json').write_bytes(wire(result))
    return result

if __name__=='__main__':
    results={
      'mixed_per_operation':probe('mixed-per-operation'),
      'mixed_stage_total':probe('mixed-stage-total',scope='stage_total'),
      'lagging_key_usage':probe('lagging-key-usage',lag=True),
      'duplicate_generation':probe('duplicate-generation',duplicate=True,same_low=True),
      'same_stage_changed_manifest':probe('same-stage-changed-manifest',scope='stage_total',same_low=True,mutate_same_stage=True),
      'transient_key_lag':probe('transient-key-lag',transient_lag=True),
      'transient_generation_lag':probe('transient-generation-lag',generation_lag=True),
    }
    print(json.dumps(results,indent=2))
