# New corpus pre-collection corrections — exact archive v1

This archive preserves authored before/fixed DATA and independent peer evidence
for three source ambiguities resolved BEFORE any model collection. It contains
no model response, measured model quality, paid inference, key, private account,
ledger or holdout payload. Source-relative peer PASS is not a world-truth or model
performance result. Authors see their labels; this is not blind-sealed data.

The three fixes are: new_label_014 inventory endpoint “may enter” -> “enters”;
f03-pl-parameters R3 unknown replication binding1.3 -> actual method version1.2;
and r02-pl-dialogue “Tylko jeśli” -> one-way “Jeśli”. Source obligations and labels
were not relaxed after outputs: no outputs existed. Label gold is byte-identical;
ten other graph case inputs are byte-identical. Full author/reviewer before
snapshots, correction records, fixed snapshots and existing peer receipts remain.

Layout:
- payloads/label/before: all12 exact pre-peer draft files, including both prepared
  arms and the offline replay record. payloads/label/after: all13 final files.
- author-evidence/new-graph-corpus-author-fix-20261005: all89 graph before files,
  the complete before manifest and fix proof, plus guarded label replay dependency
  evidence. No failed or superseded authored input/prepared payload is omitted.
- payloads/graph/after: all91 final frontier/reply files, including generic DATA
  producer, authored JSON stories/parameters/obligations, exact source bytes,
  packets, rubrics, manifests, schema and proof records.
- reviewer-evidence/new-graph-corpus-peer-review-20261005: full independent
  closure, validation, notes, metadata digest-overlap checks and exact before/fixed
  snapshot witnesses. Digest checks do not assert external source independence.
- receipts: two label peer files and four graph peer files, unchanged.
- source-closure: exact universal Python/recipe/DTO source used by the guarded
  replay, plus pinned reply prompt/compiler. Universal code may define historical
  loader/scorer/transport functions; no such DATA or execution is bundled.

MANIFEST.json gives relative ZIP member paths, per-file SHA-256, CRC32, byte size,
logical source reference and section. Every original payload is preserved byte
for byte. Existing payload text can contain its original local paths; no payload
was sanitized or rewritten. The manifest excludes its own hash to avoid a cycle;
ZIP CRC covers it, and the separately reported whole-ZIP SHA binds the manifest.
All ZIP member names are relative, unique and traversal-free.

VERIFY_ARCHIVE.py uses only the Python standard library and can be run against
the ZIP. It checks every declared hash/CRC/size and exact membership. Packaging
also compared the two independently retained before snapshots and final reviewed
snapshots, verified87 graph before/fixed pairs and the one label JSON delta, and
replayed the existing guarded label producer without changing prepared bytes.
Existing peer receipts retain the18 Python native DTO and292 graph locator checks;
no C++ worker/store/provider execution is claimed. Root owns final freeze,
publication and any later collection. The archived peer_pending metadata is
preserved as it existed, not rewritten into a retrospective approval.
