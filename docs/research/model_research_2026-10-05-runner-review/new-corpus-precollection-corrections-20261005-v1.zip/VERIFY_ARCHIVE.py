#!/usr/bin/env python3
"""Universal offline ZIP SHA/CRC/member verifier; no provider or file writes."""
import hashlib,json,sys,zlib
from pathlib import PurePosixPath
from zipfile import ZipFile

def main(path):
 with ZipFile(path) as z:
  assert z.testzip() is None
  names=z.namelist();assert len(names)==len(set(names))
  for name in names:
   p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
  manifest=json.loads(z.read('MANIFEST.json'))
  assert set(names)=={r['path'] for r in manifest['files']}|{'MANIFEST.json'}
  for row in manifest['files']:
   raw=z.read(row['path']);info=z.getinfo(row['path'])
   assert hashlib.sha256(raw).hexdigest()==row['sha256']
   assert len(raw)==row['bytes']==info.file_size
   assert f'{zlib.crc32(raw)&0xffffffff:08x}'==row['crc32']==f'{info.CRC:08x}'
 print(json.dumps({'status':'pass','declared_files':len(manifest['files']),'zip_members':len(names),'whole_zip_sha256':hashlib.sha256(open(path,'rb').read()).hexdigest()}))

if __name__=='__main__':main(sys.argv[1])
