# New independently authored reply data v1

Six new synthetic contexts and current requests, three Polish and three English,
authored after global method and population selection was frozen at
`7aed09b9df6b8d2fc0afc3a399f12016795ca687`. They are separate from the frontier
corpus. Source-relative semantic fidelity is evaluated; domain/world truth is not.
The author sees their own labels, so this is independent authorship, not blind
sealing.

`cases.json` contains the exact `base_packet_sha256`, `prior_graph` and separate
`current_request` payload for the unchanged selected GPT graph_v2 recipe.
`source_packets/` contains each complete native DTO GraphPacket. No response
fixture or scripted model answer is supplied. All sources, qualifiers and
provenance are retained in the request context; source history array order is
deliberately not chronological in two cases.

`sources/` preserves exact authored UTF-8 bytes. `source_manifest.json` supplies
content hashes, synthetic permalinks and source-point IDs. `rubrics/` separately
binds each required meaning to exact source spans, speaker, branch, speech role
and source time. Later corrections point toward earlier statements even when
imported in another order. Quotations, unadopted proposals, hypotheses, trial
plans, observations and unknown statuses remain distinct.

Common rules apply to every applicable source assertion and any emitted optional
extra. Links, topology depth, node count, particular IDs, confidence values and
recommendations are not additional required quotas. Advice is permitted if
qualified as assistant advice. Unknown does not license an inverse, converse,
new prohibition, permission or validation result.

`wire_schema.json` and `format_binding.json` preserve `loom.graph_reply/2` plus
the exact pinned prompt/compiler source bindings. Request parameters, provider
routing and execution are root-owned and are not prepared by this DATA package.
`native_dto_validation.json` uses the exact native DTO Python codec only and
explicitly records `native_cpp_execution=false`.

The shared producer is `../new-frontier-corpus-v1/build_data.py`. It never sends a
request, discovers cases or reads old outputs, metrics, private data or holdout.
Independent peer review and final content freeze must precede first collection;
all labels, rubrics, packets and source bytes then remain unchanged.
