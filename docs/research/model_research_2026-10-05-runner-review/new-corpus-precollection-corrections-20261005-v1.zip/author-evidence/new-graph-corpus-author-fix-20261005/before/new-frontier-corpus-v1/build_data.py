#!/usr/bin/env python3
"""Independent authored DATA producer. No transport, discovery, tuning, or scoring.

Only the explicitly allowed common criteria/protocol are projected from an old
preregistration. No old case, response, key, metric, or ledger is consumed.
Run once before collection. Existing non-identical output bytes are rejected.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT))
from loom.tools.structure.agentic_graph_v1 import packet as graph

BASE = ROOT / 'docs/research/model_research_2026-10-04/stage5'
FRONTIER = BASE / 'new-frontier-corpus-v1'
REPLY = BASE / 'new-reply-corpus-v1'
FREEZE = '7aed09b9df6b8d2fc0afc3a399f12016795ca687'
AUTHOR = 'independent_graph_corpus_author'
PROMPT_BINDING = {
    'commit': 'd49e05fd484e1a0af8432a5512762107ff633c1e',
    'path': 'loom/tools/structure/graph_reply_v1/prompt.py',
    'sha256': '375cdff3fea91ca7317c40d9d2c08ba4ce11388072f4f03b14ba94cdd0ad50bc',
}
COMPILER_BINDING = {
    'commit': 'd49e05fd484e1a0af8432a5512762107ff633c1e',
    'path': 'loom/tools/structure/graph_reply_v1/reply.py',
    'sha256': '50fffaffbf1abcbb2de1b626ae51f270a5842cd3e023c1dc3cee8011a401a903',
}
ORIGIN = {'kind': 'recorded', 'actor': AUTHOR, 'model': None,
          'recipe_sha256': None, 'response_sha256': None}
NOW = '2026-10-05T12:00:00Z'


def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value, raw=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = value if raw else canonical(value) + b'\n'
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError('immutable_authored_output_drift:' + str(path))
    else:
        path.write_bytes(data)


def entity(ident, kind, label, lang, attrs=None):
    return {'id': ident, 'kind': kind, 'canonical_key': ident, 'label': label,
            'labels': {lang: label}, 'aliases': [], 'parent': '', 'first_seen': '',
            'last_seen': '', 'evidence_class': 'observed', 'origin': 'archive',
            'confidence': 1, 'status': 'active', 'attrs': attrs or {}}


def make_sources(directory, case_id, lang, groups, record_context=None):
    sources, rows, files, source_groups = [], {}, [], {}
    for group_id, turns in groups:
        member = 'sources/' + case_id + '-' + group_id + '.txt'
        records = []
        for ordinal, turn in enumerate(turns):
            point_id, text, speaker, branch, time, status = turn
            context = '' if record_context is None else '; context=' + json.dumps(record_context[group_id],ensure_ascii=False,sort_keys=True)
            header = '[' + time + '; speaker=' + speaker + '; branch=' + branch + '; role=' + status + context + '] '
            records.append((point_id, header, text, speaker, branch, time, status, ordinal))
        raw = ''.join(header + text + '\n' for _, header, text, *_ in records).encode('utf-8')
        raw_sha = sha(raw)
        save(directory / member, raw, raw=True)
        files.append({'member': member, 'sha256': raw_sha, 'bytes': len(raw),
                      'permalink': 'synthetic+sha256://' + raw_sha + '/' + member,
                      'source_groups': [group_id], 'observation_ids': [r[0] for r in records]})
        offset = 0
        for point_id, header, text, speaker, branch, time, status, ordinal in records:
            whole = header + text
            locator = {'source': 'sha256:' + raw_sha, 'member': member, 'json_pointer': '',
                       'byte_start': offset, 'byte_len': len(whole.encode()),
                       'time_start': None, 'time_end': None, 'line': ordinal + 1}
            source = {'observation': {'id': point_id, 'unit': case_id + ':' + group_id,
                      'kind': 'utterance', 'text': whole, 'locator': locator, 'lang': lang,
                      'date': time[:10], 'ordinal': ordinal, 'artifact_type': 'synthetic_conversation',
                      'speaker': speaker, 'attrs': {'branch': branch, 'source_time': time,
                      'speech_role': status, 'caller_source_group': group_id}},
                      'known_at': None, 'text_sha256': sha(whole.encode())}
            sources.append(source)
            rows[point_id] = {'observation': point_id, 'quote': whole, 'locator': deepcopy(locator),
                             'extractor': 'independent-authored-data@1', 'quality': 1}
            source_groups[point_id] = group_id
            offset += len((whole + '\n').encode())
    return sources, rows, files, source_groups


def claim(ident, subject, predicate, obj, support, lang, *, version='', branch='', scope='',
          polarity='positive', extra=None, value=None, status='active'):
    qextra = {'polarity': polarity, 'direction': 'subject_to_object_or_value'}
    qextra.update(extra or {})
    return {'id': ident, 'subject': subject, 'predicate': predicate, 'object': obj,
            'value': value, 'qualifiers': {'valid_from': '', 'valid_to': '', 'version': version,
            'branch': branch, 'scope': scope, 'lang': lang, 'extra': qextra},
            'assessment': {'basis': {'support': [deepcopy(support)], 'derivation': None},
            'evidence_class': 'observed', 'origin': 'archive', 'confidence': 1,
            'premises': {'claims': [], 'principles': [], 'assumptions': []},
            'counter': {'observations': [], 'claims': []}, 'status': status,
            'consequences': {'claims': [], 'predictions': [], 'checks': []},
            'open': {'slots': [], 'questions': ['Source-relative statement; external truth unverified.'],
                     'fill_query': None},
            'expected_property': None, 'check_state': 'n/a', 'alternatives': []}}


# Each row: subject kind, middle kind, object kind; two directed edge predicates;
# three concrete instances; independently written source texts; target relation;
# one source-stated unknown. Opposed instance differs in polarity or version.
FRONTIER_SPECS = json.loads((FRONTIER / "authored_specifications.json").read_bytes())


def build_frontier(spec):
    ident, lang = spec['id'], spec['lang']
    groups = []
    for i, texts in enumerate(spec['texts']):
        group = 'declared-' + ident + '-occurrence-' + str(i + 1)
        turns = [(ident + '-s' + str(i + 1) + '-' + str(j + 1), text, spec['speaker'], spec['branch'], NOW, 'declaration')
                 for j, text in enumerate(texts)]
        groups.append((group, turns))
    groups.append(('declared-' + ident + '-supplement', [
        (ident+'-s-target', spec['target'][3], spec['speaker'], spec['branch'], NOW, 'declaration'),
        (ident+'-s-single', spec['single'][3], spec['speaker'], spec['branch'], NOW, 'declaration'),
        (ident+'-s-unknown', spec['unknown'][2], spec['speaker'], spec['branch'], NOW, 'unknown'),
    ]))
    source_contexts={gid:{'version':spec['opposed'].get('version',spec['version']) if index==spec['mismatched_occurrence_index'] else spec['version'],
                         'scope':spec['scope'],'binding':spec['binding'],'direction':'subject_to_object_or_value'}
                     for index,(gid,_) in enumerate(groups)}
    sources, support, files, source_groups = make_sources(FRONTIER, ident, lang, groups,source_contexts)
    entities, bylabel, claims = [], {}, []
    def eid(label, kind):
        if label not in bylabel:
            name = ident + '-e' + str(len(entities)+1)
            bylabel[label] = name
            entities.append(entity(name,kind,label,lang,{'synthetic_identity': True}))
        return bylabel[label]
    occurrence_claims = []
    extra = {'speaker':spec['speaker'], 'speech_role':'source_declaration', 'binding':spec['binding']}
    for i, labels in enumerate(spec['labels']):
        ids = [eid(l,k) for l,k in zip(labels,spec['kinds'])]
        ids_claims = []
        for j, pred in enumerate(spec['predicates']):
            opposed = spec['opposed'] if i == spec['mismatched_occurrence_index'] else {}
            polarity = opposed.get('polarity','positive') if opposed.get('edge') == j else 'positive'
            c = claim(ident+'-c'+str(i+1)+'-'+str(j+1),ids[j],pred,ids[j+1],support[ident+'-s'+str(i+1)+'-'+str(j+1)],lang,
                      version=opposed.get('version',spec['version']),branch=spec['branch'],scope=spec['scope'],polarity=polarity,extra=extra)
            claims.append(c); ids_claims.append(c['id'])
        occurrence_claims.append(ids_claims)
    a,p,b,_ = spec['single']
    single = claim(ident+'-c-single',eid(a,'singleton_marker'),p,eid(b,'source_referent'),support[ident+'-s-single'],lang,
                   version=spec['version'],branch=spec['branch'],scope=spec['scope'],extra=extra)
    claims.append(single)
    unknown_subject, slot, _ = spec['unknown']
    unknown = claim(ident+'-c-unknown',eid(unknown_subject,'source_referent'),'status_of_slot','',support[ident+'-s-unknown'],lang,
                    version=spec['version'],branch=spec['branch'],scope=spec['scope'],extra={**extra,'slot':slot,'epistemic_status':'unknown'},value='unknown')
    claims.append(unknown)
    a,p,b,_ = spec['target']
    target = claim(ident+'-missing-declared',eid(a,'source_referent'),p,eid(b,'source_referent'),support[ident+'-s-target'],lang,
                   version=spec['version'],branch=spec['branch'],scope=spec['scope'],extra=extra)
    request = ('Uzupełnij relacje jawnie zadeklarowane w źródłach, których brakuje w grafie. Oddziel propozycje przez analogię i wiedzę modelu oraz pytania unknown. W drugim zadaniu znajdź powtarzające się kwalifikowane wzorce, zachowując kierunek, wiązania, wersję, zakres, atrybucję i negację. Grupy źródeł są zadeklarowane przez wywołującego i nie wolno ich redefiniować.' if lang=='pl' else
               'Complete source-declared relations missing from the graph. Separate analogy/model-knowledge proposals and unknown questions. In the other task discover recurring qualified patterns, preserving direction, bindings, version, scope, attribution and negation. Source groups are caller-declared and must not be redefined.')
    packet = graph.make_packet(entities=entities,claims=claims,sources=sources,task={'current_request':request,'source_truth':'synthetic source fidelity only'},origin=ORIGIN,known_at=None)
    nodes=[{'id':role,'kind':kind} for role,kind in zip(spec['pattern_roles'],spec['kinds'])]
    edges=[{'source':nodes[j]['id'],'target':nodes[j+1]['id'],'predicate':spec['predicates'][j],
            'qualifiers':deepcopy(claims[j]['qualifiers'])} for j in range(len(spec['predicates']))]
    witness=[]
    for i in spec['recurring_occurrence_indices']:
        witness.append({'node_map':dict(zip(spec['pattern_roles'],[bylabel[l] for l in spec['labels'][i]])),
                        'claim_ids':occurrence_claims[i],
                        'source_groups':[source_groups[ident+'-s'+str(i+1)+'-1']],
                        'source_points':[support[ident+'-s'+str(i+1)+'-'+str(j+1)] for j in range(len(spec['predicates']))]})
    rubric={'case_id':ident,'source_truth_unverified':True,
      'completion':{'required_obligations':[{'id':'declared-missing-relation','meaning':spec['target'][3], 'source_points':[support[ident+'-s-target']],
                                            'audit_target':target}],
                    'acceptable_results':{'relation_ids':'Any new noncolliding ID; semantically faithful predicate wording is accepted.',
                     'source_declared':[target], 'unknown':[{'subject':unknown_subject,'slot':slot,'status':'unknown','source_point':support[ident+'-s-unknown']}],
                     'optional_inferred':'Only explicit hypothesis/model_knowledge origin with derivation, expected property and preserved qualifiers; not required.'},
                    'forbidden_promotions':['The opposed instance may not become positive by recurrence.','Unknown does not imply a missing object, prohibition, inverse or converse.','No unspoken analogous relation is observed.','A result is bound to its exact declared version/parameters/source, never a general validation result.']},
      'patterns':{'required_obligations':[{'id':'qualified-recurring-two-edge-pattern','nodes':nodes,'edges':edges,'witnesses':witness}],
                  'acceptable_results':{'node_and_pattern_ids':'Arbitrary local template IDs; no requirement to copy audit IDs or an outcome list.',
                    'labels':'Label abstraction is permitted if declared as transformation loss.',
                    'subpatterns':'Source-backed recurring proper subpatterns are optional and evaluated with their actual qualifiers and witnesses.',
                    'additional_patterns':'Any other actually witnessed recurrence within the supplied explicit groups is permitted; no quota, depth or confidence threshold.'},
                  'opposed_control':{'claim_ids':occurrence_claims[spec['mismatched_occurrence_index']], 'exclusion_reason':'Different polarity or version cannot witness the required exact qualified pattern.',
                                     'source_points':[support[ident+'-s'+str(spec['mismatched_occurrence_index']+1)+'-'+str(j+1)] for j in range(len(spec['predicates']))]},
                  'singleton_control':{'claim_id':single['id'],'source_point':support[ident+'-s-single'],'recurrence':'not declared'},
                  'unknown_control':{'claim_id':unknown['id'],'source_point':support[ident+'-s-unknown'],'recurrence_does_not_fill':'unknown status'}},
      'common_rules_apply_to':'Every required obligation and every emitted optional assertion/link/proposal; not just audit target records.'}
    track_requests = ({'graph_completion':'Uzupełnij brakujące relacje jawnie wypowiedziane w źródłach; oddziel inferencje i unknown.',
                       'pattern_discovery':'Znajdź powtarzalne kwalifikowane wzorce mające jawne źródłowe świadectwa w podanych grupach.'} if lang=='pl' else
                      {'graph_completion':'Complete missing explicitly source-stated relations; separate inferences and unknown.',
                       'pattern_discovery':'Discover recurring qualified patterns with explicit source witnesses in the supplied groups.'})
    input_value={'packet':packet,'source_groups':source_groups,'current_request':request,'request_templates':track_requests,
                 'source_group_declaration':{'authority':'caller','groups':[{'id':gid,'observation_ids':[t[0] for t in turns]} for gid,turns in groups],
                  'independence_claim':'Distinct authored source units only; no external corroboration or statistical independence established.'}}
    case={'id':ident,'language':lang,'input':input_value,'input_sha256':sha(canonical(input_value))}
    save(FRONTIER/'inputs'/ (ident+'.json'),case)
    save(FRONTIER/'source_packets'/ (ident+'.json'),packet)
    save(FRONTIER/'rubrics'/ (ident+'.json'),rubric)
    # Validate the missing target against the same source closure without making it input.
    full = graph.make_packet(entities=entities,claims=claims+[target],sources=sources,task=packet['task'],origin=ORIGIN,known_at=None)
    return case, files, full


# Source turns carry explicit role/time/branch. Imported array order in r01 and
# r04 is deliberately not chronology; correction meaning follows source time.
REPLY_SPECS = json.loads((REPLY / "authored_specifications.json").read_bytes())


def load_prompt():
    raw = subprocess.check_output(['git','show',PROMPT_BINDING['commit']+':'+PROMPT_BINDING['path']],cwd=ROOT)
    if sha(raw) != PROMPT_BINDING['sha256']:
        raise ValueError('pinned_universal_prompt_drift')
    module=types.ModuleType('independent_data_reply_prompt')
    module.__package__='loom.tools.structure.graph_reply_v1'
    exec(compile(raw,'pinned_universal_prompt','exec'),module.__dict__)
    return module


def build_reply(spec,prompt):
    ident,lang=spec['id'],spec['lang']
    turns=[(ident+'-'+tid,text,speaker,branch,time,status) for tid,text,speaker,branch,time,status in spec['turns']]
    sources,support,files,source_groups=make_sources(REPLY,ident,lang,[('declared-'+ident+'-context',turns)])
    actors={}
    entities=[]
    statements={}
    claims=[]
    for tid,text,speaker,branch,time,status in spec['turns']:
        if speaker not in actors:
            actor_id=ident+'-actor-'+str(len(actors)+1)
            actors[speaker]=actor_id
            entities.append(entity(actor_id,'speaker',speaker,lang))
        sid=ident+'-statement-'+tid
        statements[tid]=sid
        entities.append(entity(sid,'source_statement',text,lang,{'source_point':ident+'-'+tid,'speaker':speaker,'branch':branch,
                       'source_time':time,'speech_role':status,'context_only':True}))
        claims.append(claim(ident+'-asserts-'+tid,actors[speaker],'states',sid,support[ident+'-'+tid],lang,
                     branch=branch,scope='exact attributed source utterance',extra={'speaker':speaker,'source_time':time,
                     'speech_role':status,'epistemic_mode':'attributed_source_statement'},
                     status='superseded' if 'superseded' in status else 'active'))
    newer,older=spec['correction']
    srow=next(x for x in spec['turns'] if x[0]==newer)
    claims.append(claim(ident+'-correction',statements[newer],'corrects_or_refines',statements[older],support[ident+'-'+newer],lang,
                  branch=srow[3],scope='chronological user change',extra={'speaker':srow[2],'source_time':srow[4],
                  'speech_role':srow[5],'direction_semantics':'newer_correction_to_older_statement'}))
    packet=graph.make_packet(entities=entities,claims=claims,sources=sources,
                task={'current_request':spec['request'],'source_truth':'fidelity of stated synthetic content, not model world truth'},origin=ORIGIN,known_at=None)
    prior=prompt.context_payload(packet,'graph')
    payload={'base_packet_sha256':packet['packet_id'],'prior_graph':prior,'current_request':spec['request']}
    obligations=[]
    for oid,meaning,points in spec['obligations']:
        obligations.append({'id':oid,'meaning':meaning,'source_points':[support[ident+'-'+p] for p in points],
                            'required_for_adequacy':True})
    rubric={'case_id':ident,'required_obligations':obligations,'chronology':[
          {'source_point':ident+'-'+tid,'source_time':time,'speaker':speaker,'branch':branch,'speech_role':status}
          for tid,_,speaker,branch,time,status in sorted(spec['turns'],key=lambda x:x[4])],
          'common_rules_apply_to':'All source-relative assertions, all links, every applicable source point, and every optional extra; not only required obligation coverage.',
          'acceptance':{'paraphrase':'Equivalent meaning, direction, branch, speaker, chronology, status and parameter/version meaning accepted.',
            'identifiers':'No requirement for particular response IDs, node granularity or enumerated list wording.',
            'quotation':'Do not attribute a quoted third-party claim to the current user as their commitment.',
            'hypotheses':'Source hypotheses and assistant recommendations may be reported or expanded as explicitly qualified advice; they must not impersonate user decisions or observations.',
            'unknown':'Unknown supplies no inverse/converse, false polarity, new restriction, validation, or permission.',
            'optional_links':'Optional. If emitted, direction and scope must preserve intended semantic chronology; correction points from new to old regardless of import order.',
            'confidence_depth_quota':'No confidence threshold, depth threshold, node count or optional-extra quota.'},
          'source_truth_unverified':True,'model_scores':None}
    case={'id':ident,'language':lang,'input':payload,'input_sha256':sha(canonical(payload)),
          'source_packet_id':packet['packet_id'],'current_request':spec['request']}
    save(REPLY/'inputs'/(ident+'.json'),case)
    save(REPLY/'source_packets'/(ident+'.json'),packet)
    save(REPLY/'rubrics'/(ident+'.json'),rubric)
    return case,files,packet


def native_validate(packets,directory):
    """Validate exact native DTO projection with the pinned Python codec only."""
    checked=[]
    for case_id,packet in packets:
        graph.validate_packet(packet)
        checked.append({'case_id':case_id,'packet_id':packet['packet_id'],'native_dto_projection_valid':True,
                        'entities':len(packet['entities']),'claims':len(packet['claims']),'sources':len(packet['sources'])})
    return {'schema':'loom.independent_corpus_native_dto_validation/1',
            'python_validator':str(Path(graph.__file__).relative_to(ROOT)),
            'python_validator_sha256':sha(Path(graph.__file__).read_bytes()),
            'no_network':True,'native_cpp_execution':False,'store_written':False,'workers_started':False,
            'canonical_store_written':False,'packets':checked}


def verify_source_closure(directory,cases,files):
    bymember={f['member']:f for f in files}
    for case in cases:
        packet=case['input'].get('packet') or case['input']['prior_graph']
        for s in packet['sources']:
            obs=s['observation']; loc=obs['locator']; meta=bymember[loc['member']]
            raw=(directory/loc['member']).read_bytes()
            if sha(raw)!=meta['sha256'] or loc['source']!='sha256:'+meta['sha256']:
                raise ValueError('source_file_hash_drift')
            if raw[loc['byte_start']:loc['byte_start']+loc['byte_len']]!=obs['text'].encode():
                raise ValueError('source_observation_exact_bytes_drift')
        for c in packet['claims']:
            for sup in c['assessment']['basis']['support']:
                loc=sup['locator'];raw=(directory/loc['member']).read_bytes()
                if raw[loc['byte_start']:loc['byte_start']+loc['byte_len']]!=sup['quote'].encode():
                    raise ValueError('claim_exact_source_subspan_drift')


def finish(directory,cases,files,validation,common,recipe_role):
    verify_source_closure(directory,cases,files)
    save(directory/'cases.json',cases)
    save(directory/'source_manifest.json',{'schema':'loom.synthetic_source_manifest/1','files':files,'source_closure_checked':True})
    save(directory/'common_contract.json',common)
    save(directory/'native_dto_validation.json',validation)
    exposure={'schema':'loom.independent_corpus_authorship/1','author':AUTHOR,'created_after_selection_freeze':FREEZE,
        'source_type':'new independently authored synthetic data','cases':len(cases),
        'languages':{'pl':sum(c['language']=='pl' for c in cases),'en':sum(c['language']=='en' for c in cases)},
        'author_exposure':{'own_sources_inputs_labels_rubrics':True,'old_cases':False,'old_model_outputs':False,
          'old_selection_metrics':False,'private_or_holdout':False,'keys_or_ledgers':False,
          'allowed_common_contract':True,'universal_code_schema_recipe':True,
          'mandatory_start_docs':'Read; historical global project status inside start docs is not selection evidence.'},
        'independence_boundary':'Author sees their own labels, so this is independently authored, not blind-sealed. Root may see cases only after global selection/population preset freeze.',
        'immutable_collection_policy':'Before any model collection, freeze exact source/input/rubric/producer hashes and obtain independent peer review. After first collection, never change case, source packet, label or rubric bytes; corrections require separately versioned data and reporting, not tuning.',
        'recipe_selection':recipe_role,'selection_recipe_tuning_performed':False,'network_calls':0,'paid_calls':0,
        'source_truth':'Explicit synthetic source-relative fidelity only; no domain/world truth benchmark.',
        'validation_is_not_model_quality':True}
    save(directory/'authorship.json',exposure)
    paths=sorted(p for p in directory.rglob('*') if p.is_file() and p.name!='freeze_manifest.json')
    manifest={'schema':'loom.independent_corpus_freeze/1','selection_freeze_commit':FREEZE,'author':AUTHOR,
       'collection_started':False,'post_collection_mutation_permitted':False,
       'peer_review_status':'pending','final_collection_freeze':False,
       'files':[{'path':str(p.relative_to(directory)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in paths]}
    manifest['content_manifest_sha256']=sha(canonical(manifest))
    save(directory/'freeze_manifest.json',manifest)
    return manifest['content_manifest_sha256']


def main():
    for directory in (FRONTIER,REPLY): directory.mkdir(parents=True,exist_ok=True)
    # Selectively expose only these explicitly authorized top-level fields.
    common_path=BASE/'new-author-source-contract-v1.json'
    raw_common=json.loads(common_path.read_bytes())
    protocol=deepcopy(raw_common['evaluation_protocol'])
    historical_denominators=protocol.pop('primary_planned_denominators',None)
    common={'common_case_criteria':deepcopy(raw_common['common_case_criteria']),'evaluation_protocol':protocol,
       'historical_exclusions_for_context_only_not_new_case_rules':deepcopy(raw_common['ambiguities_and_exclusions']),
       'projection_source':{'path':str(common_path.relative_to(ROOT)),'fields':['common_case_criteria','evaluation_protocol'],
          'sha256':sha(common_path.read_bytes()),
          'excluded':'Historical stage3/stage4 primary_planned_denominators do not transfer to this new population. No cases/outputs/metrics were inspected.'},
       'exclusion_applicability':'Historical control IDs, populations, scripted controls, excluded stage numbers and paired-arm allocation do not transfer. Applicable generic boundaries remain: source-relative truth, task asymmetry, source-group independence unverified, optional links and open-world unknown.',
       'new_population':'Exactly six frozen cases per corpus, three PL and three EN; all applicable obligations and emitted extras evaluated independently of model/provider and format.'}
    del raw_common,historical_denominators
    prompt=load_prompt()
    fc,ff,fp=[],[],[]
    for spec in FRONTIER_SPECS:
        case,files,full=build_frontier(spec);fc.append(case);ff.extend(files)
        fp.extend([(spec['id']+'-source',case['input']['packet']),(spec['id']+'-target-validation',full)])
    rc,rf,rp=[],[],[]
    for spec in REPLY_SPECS:
        case,files,packet=build_reply(spec,prompt);rc.append(case);rf.extend(files);rp.append((spec['id'],packet))
    save(REPLY/'wire_schema.json',prompt.reply_schema('loom.graph_reply/2'))
    save(REPLY/'format_binding.json',{'schema':'loom.independent_reply_format_binding/1','wire_schema':'loom.graph_reply/2',
         'universal_prompt_source':PROMPT_BINDING,'universal_compiler_source':COMPILER_BINDING,
         'functions':['context_payload(packet,"graph")','reply_schema("loom.graph_reply/2")'],
         'selected_recipe':'unchanged frozen GPT graph_v2 research recipe; transport preparation remains root-owned',
         'current_request_is_separate':True,'rubric_in_model_input':False})
    fv=native_validate(fp,FRONTIER);rv=native_validate(rp,REPLY)
    fhash=finish(FRONTIER,fc,ff,fv,common,{'graph_completion':'unchanged selected Gemini recipe','pattern_discovery':'unchanged selected GPT recipe','role':'research candidate, not production'})
    rhash=finish(REPLY,rc,rf,rv,common,{'reply':'unchanged selected GPT graph_v2 recipe','wire_schema':'loom.graph_reply/2','role':'research candidate, not production'})
    print(json.dumps({'frontier_cases':len(fc),'reply_cases':len(rc),'frontier_content_manifest_sha256':fhash,
                     'reply_content_manifest_sha256':rhash,'native_packets_checked':len(fp)+len(rp),'model_calls':0},ensure_ascii=False))


if __name__=='__main__': main()
