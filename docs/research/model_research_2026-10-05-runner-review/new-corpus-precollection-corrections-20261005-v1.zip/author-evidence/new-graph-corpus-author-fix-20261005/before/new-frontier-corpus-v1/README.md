# New independently authored frontier data v1

Six new synthetic cases, three Polish and three English, authored after global
method and population selection was frozen at `7aed09b9df6b8d2fc0afc3a399f12016795ca687`.
This is source-relative research data, not a world-truth benchmark or production
method promotion. The author sees their own labels; it is not blind-sealed.

`cases.json` contains the six model inputs. Each input has a standalone native
DTO `packet`, caller-defined `source_groups`, explicit group membership, and
separate completion/pattern request templates. The unchanged selected Gemini
completion and GPT pattern recipes remain root-owned. Nothing is sent by this
data producer.

`sources/` holds immutable authored UTF-8 bytes. `source_manifest.json` binds each
file's hash, byte length, synthetic content-addressed permalink and observation
IDs. Locator byte ranges resolve directly against these files; support quotes
include the written speaker, branch, time and qualified context. Source-group
labels describe distinct authored units only, not independent external witnesses.

`source_packets/` repeats the source packet for direct inspection. `rubrics/`
contains separate frozen semantic obligations, exact source spans, an omitted
source-declared relation, qualified recurring witnesses, a mismatching third
instance, a singleton and an unknown. Rubric targets are not model input.
Faithful wording, IDs and granularity may differ. Other actual witnessed
recurrences and explicit hypothesis/advice extras remain admissible and are
evaluated without quotas or confidence/depth thresholds.

`common_contract.json` applies common source fidelity and review rules to all
required content and every emitted extra. Historical denominators and population
exclusions are explicitly not transferred. `native_dto_validation.json` records
Python validation of the exact native DTO projection; C++ execution, store writes,
workers, transport and paid calls are all false/zero.

`build_data.py` is a deterministic, write-once DATA producer for both this corpus
and the separate reply corpus. No old case, output, score, key, ledger or holdout
is read. `freeze_manifest.json` is a pre-collection content manifest; the root
must bind independent peer review and final freeze before first collection.
After collection begins, cases, source packets, labels and rubrics cannot change.
