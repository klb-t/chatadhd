# Final deferred-billing review: portable synthetic proofs

The final independently accepted runner SHA-256 is
`dd74b3d4197c3d274f780a1b324b56d9d579b8df905c512282e7f33cd25f6b97`.
The preserved pre-fix runner is
`c691075f7357175428625784431b3efa4f302318f02cb3008cea1e9977ad82d3`.
Full exact dependency and owned-policy snapshots are in `before/` and `after/`.

All credentials, private ledgers, responses, counters, and captures packaged here
are fabricated. No real key, ledger, provider metadata, private export, holdout,
or real billing record was accessed by this review or included here. Every
transport call in the reproduction is an injected Python mock; no HTTP occurs.
The unrelated earlier frozen runner and optional unit-floor archives stay intact.

## Concrete failures before the fixes

1. A wrong-model generation GET returning HTTP 200 created a durable contradiction
   STOP and billing-failure witness. Deleting only its `verification_failures`
   SQLite row and canonical JSON let a subsequent GET-only reconciliation clear
   the STOP, despite all original captures, STOP receipts, and contradictory raw
   bytes remaining. This reproduces with required credit bootstrap enabled and
   with its explicit generic false option.
2. A stage paused after one independently verified operation and a second pending
   operation. Removing only the pending SQL attempt and all four of its capture
   files, while retaining the immutable paused receipt, let a lagging key counter
   hide the missing operation. Resume redispatched that operation and dispatched
   the next operation: two additional fabricated POSTs before final STOP.

## Results on the final source

Both contradiction-witness deletion cases now reject with
`durable_billing_verification_contradiction` before any network call. The paused
attempt deletion rejects with `saved_actual_attempt_history_missing`, also before
any GET or POST. Generation-read audit inventory and saved actual-receipt attempt
history anchor the surviving evidence.

Four resume probes pass: a mixed-model stage resumes exactly its remaining
operation and verifies both generations; a different stage with prior pending
billing, a missing first capture, and a timing downgrade each reject before
network. Original pending SQL and capture bytes remain unchanged on normal resume.

Required bootstrap is separately checked: three first-generation 404s stop after
one POST; a successful first credit generation GET precedes the second POST,
whose deferred generation is verified at stage end. Model/provider/route/API
identity changes each reject credit-proof reuse.

The reviewer independently ran all 135 focused programme tests and all 35 helper
and budget-gate tests on this final source. Sibling and native reviews cover
additional crash, audit, configured-pending-status, interval, and terminal-lag
cases; their fixture contents are not copied into this archive.

The scope is source and fabricated-fixture acceptance. It does not verify a real
provider account or execute a paid dispatch. Default policy retains per-operation
billing verification, strict unknown-cost handling, and optional endpoint pricing
disabled; deferred billing and reservation-based continuation require explicit
policy selection.

## Reproduce

Python 3 with its standard library is sufficient. Extract anywhere and run:

```sh
python verify.py
python reproduce.py
```

All paths are relative to this folder. Original generated inputs, SQLite states,
raw mock responses, pre-deletion and post-reconcile snapshots, source, and result
files remain available. Reproduction regenerates synthetic date witnesses for
freshness checks and asserts every before/fix outcome. `SHA256SUMS.json` covers
every payload file. `acceptance.json` records the exact source and test boundary.
