"""Offline deferred-billing resume probes. Fresh fabricated credentials only."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import sqlite3
from decimal import Decimal

MODULES, OUTPUT = map(Path,sys.argv[1:3])
sys.path.insert(0,str(MODULES))
import research_programme_runner as runner
import test_research_programme_runner as fixtures

def make():
    test = fixtures.ProgrammeRunnerTests()
    test.setUp()
    test.policy["billing_verification_timing"] = "stage_end"
    test.policy["unknown_cost_policy"] = "reserve"
    test.policy["require_credit_proof_per_pair"] = False
    test.policy["pause"]["maximum_operations_per_invocation"] = 1
    test.policy["read_only_reconciliation"]["generation"]["delay_seconds"] = "0"
    data = json.loads(test.manifest.read_bytes())
    second_body = {**json.loads(test.body),"model":"fake/second"}
    raw = fixtures.wire(second_body)
    (test.repo / "second.json").write_bytes(raw)
    data["operations"].append({**data["operations"][0],"operation_id":"two","model_id":"fake/second","request_file":"second.json","request_sha256":hashlib.sha256(raw).hexdigest()})
    test.manifest.write_bytes(fixtures.wire(data))
    calls, served = [], {}
    usage = Decimal(0)
    def send(method,route,body=None,params=None):
        nonlocal usage
        calls.append([method,route,params])
        response = {"http_status":200,"latency_seconds":0.1}
        if route == "key":
            response["raw"] = fixtures.wire({"data":{"usage":str(usage),"limit":"5","limit_remaining":str(5-usage),"byok_usage":"0","include_byok_in_limit":False,"is_management_key":False,"limit_reset":None}})
        elif route == "model_endpoints":
            model = params["model_id"]
            response["raw"] = fixtures.wire({"data":{"id":model,"endpoints":[{"model_id":model,"provider_name":"Fake","pricing":{"prompt":"0.0001","completion":"0.0002","request":"0"}}]}})
        elif route == "chat":
            model = json.loads(body)["model"]
            identifier = "gen-synthetic-" + str(len(served)+1)
            served[identifier] = model
            usage += Decimal("0.01")
            response["raw"] = fixtures.wire({"id":identifier,"model":model,"provider":"Fake","usage":{"cost":"0.01","is_byok":False}})
        elif route == "generation":
            identifier = params["id"]
            response["raw"] = fixtures.wire({"data":{"id":identifier,"model":served[identifier],"provider_name":"Fake","api_type":"completions","total_cost":"0.01","is_byok":False}})
        else:
            raise AssertionError(route)
        return response
    test.send = send
    return test,calls

summary = {}
for name in ("mixed_pair_resume","cross_stage_pending","missing_pending_first_capture","policy_timing_downgrade"):
    test,calls = make()
    try:
        initial = test.run_stage()
        assert initial["status"] == "paused",initial
        assert sum(call[0] == "POST" for call in calls) == 1
        assert not any(call[1] == "generation" for call in calls)
        case = OUTPUT / name
        case.mkdir(parents=True,exist_ok=True)
        shutil.copytree(test.root,case / "fixture_before_resume",dirs_exist_ok=True)
        if name == "cross_stage_pending":
            data = json.loads(test.manifest.read_bytes())
            data["stage_id"] = "other-stage"
            data["operations"] = [{**data["operations"][1],"operation_id":"three"}]
            test.manifest.write_bytes(fixtures.wire(data))
        elif name == "missing_pending_first_capture":
            next((test.private / "records").glob("*.response.bin")).unlink()
        elif name == "policy_timing_downgrade":
            test.policy["billing_verification_timing"] = "per_operation"
        test.policy["pause"]["maximum_operations_per_invocation"] = None
        calls.clear()
        try:
            result = test.run_stage()
        except runner.ProgrammeError as error:
            result = {"status":"blocked","error":str(error)}
        report = {"initial":initial,"resume":result,"calls_on_resume":calls,"posts_on_resume":sum(call[0] == "POST" for call in calls)}
        if name == "mixed_pair_resume":
            assert result["status"] == "completed",report
            assert report["posts_on_resume"] == 1,report
            assert result["completed_operations"] == 2,report
            assert result["pending_billing_operations"] == 0,report
            with sqlite3.connect(case / "fixture_before_resume/private/ledger.sqlite3") as before_db, sqlite3.connect(test.private / "ledger.sqlite3") as after_db:
                original = before_db.execute("SELECT payload FROM attempts WHERE operation_id='one'").fetchone()[0]
                assert original == after_db.execute("SELECT payload FROM attempts WHERE operation_id='one'").fetchone()[0]
            for path in (case / "fixture_before_resume/private/records").iterdir():
                assert path.read_bytes() == (test.private / "records" / path.name).read_bytes()
            report["original_pending_row_and_captures_unchanged"] = True
        else:
            assert result["status"] == "blocked",report
            assert not calls,report
        shutil.copytree(test.root,case / "fixture_after_resume",dirs_exist_ok=True)
        (case / "policy.json").write_bytes(fixtures.wire(test.policy))
        (case / "report.json").write_text(json.dumps(report,indent=2)+"\n")
        summary[name] = {"resume":result,"posts_on_resume":report["posts_on_resume"],"network_calls_on_resume":len(calls)}
    finally:
        test.doCleanups()
OUTPUT.mkdir(parents=True,exist_ok=True)
(OUTPUT / "summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
