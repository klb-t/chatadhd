"""Synthetic default credit-bootstrap and route-identity probes."""
import json
from pathlib import Path
import shutil
import sys

MODULES, OUTPUT = map(Path,sys.argv[1:3])
sys.path.insert(0,str(MODULES))
import research_programme_runner as runner
import test_research_programme_runner as fixtures

summary = {}
for name in ("first_generation_404","successful_credit_bootstrap"):
    test = fixtures.ProgrammeRunnerTests()
    test.setUp()
    try:
        test.two_operations()
        test.policy["billing_verification_timing"] = "stage_end"
        test.policy["unknown_cost_policy"] = "reserve"
        test.policy["require_credit_proof_per_pair"] = True
        if name == "first_generation_404":
            test.send.generation_pending = 3
        result = test.run_stage()
        calls = [[method,route,params] for method,route,body,params in test.send.calls]
        posts = [index for index,call in enumerate(calls) if call[0] == "POST"]
        generations = [index for index,call in enumerate(calls) if call[1] == "generation"]
        if name == "first_generation_404":
            assert result["status"] == "stopped" and len(posts) == 1,result
            assert len(generations) == 3,calls
        else:
            assert result["status"] == "completed" and len(posts) == 2,result
            assert len(generations) == 2 and generations[0] < posts[1] < generations[1],calls
        case = OUTPUT / name
        case.mkdir(parents=True,exist_ok=True)
        shutil.copytree(test.root,case / "synthetic_fixture",dirs_exist_ok=True)
        report = {"result":result,"calls":calls,"post_count":len(posts),"generation_get_count":len(generations)}
        (case / "policy.json").write_bytes(fixtures.wire(test.policy))
        (case / "report.json").write_text(json.dumps(report,indent=2)+"\n")
        summary[name] = {"status":result["status"],"post_count":len(posts),"generation_get_count":len(generations)}
    finally:
        test.doCleanups()
operation = {"model_id":"synthetic/model","provider_id":"synthetic","route_id":"chat","api_type":"completions"}
row = {"state":"completed","billing_verified":True,"is_byok":False,"actual_cost_usd":"0.01","generation_sha256":"a"*64,"receipt_operation":operation}
assert runner.pair_credit_proven([row],operation)
for field in operation:
    changed = {**operation,field:operation[field]+"-different"}
    assert not runner.pair_credit_proven([row],changed),field
summary["credit_identity_tuple"] = {"same_tuple":True,"all_four_different_dimensions_rejected":True}
OUTPUT.mkdir(parents=True,exist_ok=True)
(OUTPUT / "summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
