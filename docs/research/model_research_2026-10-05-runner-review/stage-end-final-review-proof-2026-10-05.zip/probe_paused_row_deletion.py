"""Synthetic partial-restore probe with a surviving immutable paused receipt."""
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
from decimal import Decimal

MODULES,OUTPUT=map(Path,sys.argv[1:3])
sys.path.insert(0,str(MODULES))
import research_programme_runner as runner
import test_research_programme_runner as fixtures

test=fixtures.ProgrammeRunnerTests()
test.setUp()
try:
    test.two_operations()
    manifest=json.loads(test.manifest.read_bytes())
    manifest["operations"].append({**manifest["operations"][0],"operation_id":"three"})
    test.manifest.write_bytes(fixtures.wire(manifest))
    test.policy.update(billing_verification_timing="stage_end",unknown_cost_policy="reserve",require_credit_proof_per_pair=True)
    test.policy["pause"]["maximum_operations_per_invocation"]=2
    paused=test.run_stage()
    assert paused["status"] == "paused" and paused["attempted_operations"] == 2,paused
    assert paused["completed_operations"] == 1 and paused["pending_billing_operations"] == 1,paused
    OUTPUT.mkdir(parents=True,exist_ok=True)
    shutil.copytree(test.root,OUTPUT/"fixture_before_deletion",dirs_exist_ok=True)
    with sqlite3.connect(test.private/"ledger.sqlite3") as db:
        row=json.loads(db.execute("SELECT payload FROM attempts WHERE operation_id='two'").fetchone()[0])
        assert row["state"] == "pending_billing"
        db.execute("DELETE FROM attempts WHERE operation_id='two'")
    token=hashlib.sha256(b"two").hexdigest()
    deleted=[]
    for path in (test.private/"records").glob(token+".*"):
        deleted.append(path.name); path.unlink()
    assert len(deleted) == 4,deleted
    # Model a legitimate lagging usage read: it matches only the old proven row.
    # The surviving paused receipt must independently prevent redispatch.
    test.send.key_usage_override=Decimal("0.01")
    test.policy["pause"]["maximum_operations_per_invocation"]=None
    test.send.calls.clear()
    try:result=test.run_stage()
    except runner.ProgrammeError as error:result={"status":"blocked","error":str(error)}
    shutil.copytree(test.root,OUTPUT/"fixture_after_resume",dirs_exist_ok=True)
    report={"paused":paused,"deleted_operation_id":"two","deleted_capture_files":sorted(deleted),"resume":result,"posts_on_resume":len(test.send.posts()),"network_calls_on_resume":len(test.send.calls),"paused_actual_receipt_retained":bool(list(test.private.glob("*.actual.json")))}
    (OUTPUT/"policy.json").write_bytes(fixtures.wire(test.policy))
    (OUTPUT/"result.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
finally:test.doCleanups()
