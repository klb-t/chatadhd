import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "SHA256SUMS.json").read_bytes())
actual = {str(path.relative_to(root)).replace("\\", "/") for path in root.rglob("*") if path.is_file() and path.name != "SHA256SUMS.json" and "__pycache__" not in path.parts}
assert actual == set(manifest), (sorted(actual-set(manifest)), sorted(set(manifest)-actual))
for relative, expected in manifest.items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected, relative
print(f"Verified {len(manifest)} payload files")
