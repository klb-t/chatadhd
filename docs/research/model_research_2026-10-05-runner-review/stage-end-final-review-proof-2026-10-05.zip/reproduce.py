import json
from pathlib import Path
import subprocess
import sys
import tempfile

root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix="synthetic-final-runner-review-") as temporary:
    output=Path(temporary)
    for version in ("before","after"):
        modules=root/version/"loom/tools/structure"
        for bootstrap in (False,True):
            case=output/version/("bootstrap" if bootstrap else "generic")
            command=[sys.executable,str(root/"probe_failure_deletion.py"),str(modules),str(case)]
            if bootstrap:command.append("--bootstrap")
            subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
            result=json.loads((case/"result.json").read_bytes())
            assert result["posts_on_reconcile"] == 0
            assert result["stopped"]["status"] == "stopped"
            if version == "before":
                assert result["reconcile_after_failure_record_deletion"]["status"] == "stop_resolved_read_only"
                assert result["network_calls_on_reconcile"] > 0
            else:
                assert result["reconcile_after_failure_record_deletion"] == {"status":"blocked","error":"durable_billing_verification_contradiction"}
                assert result["network_calls_on_reconcile"] == 0
        case=output/version/"paused-deletion"
        subprocess.run([sys.executable,str(root/"probe_paused_row_deletion.py"),str(modules),str(case)],check=True,stdout=subprocess.DEVNULL)
        result=json.loads((case/"result.json").read_bytes())
        assert result["paused_actual_receipt_retained"]
        if version == "before":assert result["posts_on_resume"] == 2
        else:
            assert result["resume"] == {"status":"blocked","error":"saved_actual_attempt_history_missing"}
            assert result["network_calls_on_resume"] == 0
    for script,name in (("probe_stage_end_resume.py","resume"),("probe_stage_end_bootstrap.py","bootstrap")):
        subprocess.run([sys.executable,str(root/script),str(root/"after/loom/tools/structure"),str(output/name)],check=True,stdout=subprocess.DEVNULL)
print("All synthetic before/fix and resume/bootstrap assertions passed; no HTTP calls")
