"""Synthetic append-only contradiction deletion probe; never network."""
import json
from pathlib import Path
import shutil
import sqlite3
import sys

MODULES, OUTPUT = map(Path,sys.argv[1:3])
BOOTSTRAP = len(sys.argv) > 3 and sys.argv[3] == "--bootstrap"
sys.path.insert(0,str(MODULES))
import research_programme_runner as runner
import test_research_programme_runner as fixtures

test = fixtures.ProgrammeRunnerTests()
test.setUp()
try:
    test.two_operations()
    test.policy["billing_verification_timing"] = "stage_end"
    test.policy["unknown_cost_policy"] = "reserve"
    test.policy["require_credit_proof_per_pair"] = BOOTSTRAP
    base_send = test.send
    wrong_receipt = True
    def send(method,route,body=None,params=None):
        response = base_send(method,route,body,params)
        if wrong_receipt and route == "generation" and (not BOOTSTRAP or params["id"] == "gen-fake-2"):
            response["raw"] = fixtures.wire({"data":{"id":params["id"],"model":"wrong/model","provider_name":"Fake","api_type":"completions","total_cost":"0.01","is_byok":False}})
        return response
    test.send = send
    stopped = test.run_stage()
    assert stopped["status"] == "stopped",stopped
    assert len(base_send.posts()) == 2
    failure = next(test.private.glob("*.billing-failure.json"))
    OUTPUT.mkdir(parents=True,exist_ok=True)
    shutil.copytree(test.root,OUTPUT / "fixture_before_deletion",dirs_exist_ok=True)
    source_snapshot = OUTPUT / "source"
    for name in ("research_programme_runner.py","research_programme_manifest.py","research_programme_transport.py","endpoint_pricing_v1.py","openrouter_runner.py","new_budget5eur_gate.py","test_research_programme_runner.py"):
        source_snapshot.mkdir(parents=True,exist_ok=True)
        shutil.copy2(MODULES / name,source_snapshot / name)
    with sqlite3.connect(test.private / "ledger.sqlite3") as database:
        database.execute("DELETE FROM verification_failures")
    failure.unlink()
    wrong_receipt = False
    base_send.calls.clear()
    try:
        result = runner.reconcile_stop(test.policy,test.manifest,test.evidence,test.private,test.keyfile,test.repo,transport_fn=test.send,captured_pending=True)
    except runner.ProgrammeError as error:
        result = {"status":"blocked","error":str(error)}
    shutil.copytree(test.root,OUTPUT / "fixture_after_reconcile",dirs_exist_ok=True)
    (OUTPUT / "policy.json").write_bytes(fixtures.wire(test.policy))
    report = {"bootstrap_required":BOOTSTRAP,"stopped":stopped,"reconcile_after_failure_record_deletion":result,"posts_on_reconcile":len(base_send.posts()),"network_calls_on_reconcile":len(base_send.calls),"contradictory_raw_witnesses_retained":len(list(test.private.glob("*.captured-generation-read-*.bin")))}
    (OUTPUT / "result.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
finally:
    test.doCleanups()
