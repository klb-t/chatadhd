# Optional endpoint pricing unit-floor review

This supplemental archive contains only source and fabricated fixtures. It does
not contain the real programme's credential, private ledger, provider metadata,
private exports, holdouts, or billing records. A fixture credential is plainly
marked synthetic and is created by the offline fixture constructor. All provider
responses come from Python mocks; the reproduction performs no HTTP calls.

The fixed default runner policy keeps `endpoint_pricing: null`. These findings
concern the explicitly selected endpoint-pricing policy.

## Concrete finding and result

Before the fix, a valid text-only request with a published $1 per-request fee
could explicitly declare `request: "0"`. Both the helper quote and runner plan
accepted it with reservation $0. One fabricated POST occurred, reporting $1,
and the runner stopped only after it exceeded the admitted reservation.

The owned policy now sets a generic `minimum_value: "1"` for request units.
It also requires each explicit cache bound to cover the complete prompt bound
and internal reasoning to cover the complete output bound. The same preserved
request-zero probe now rejects at preflight and sends zero POSTs. The five pure
helper probes (request zero/fractional and low cache quantities) change from
accepted before to rejected after.

The helper before SHA-256 is
`3a1b69864110cf8fc92edb8c952923e9379d787aa95183378121c7ad2ea5e006`;
after is
`77ef9a7871166fbfd8325b61eb7c173e14ce720402c49e3101b37a9bb161b2e9`.

## Source scope

`before/` contains the exact runner/helper/policy/test sources captured before
the unit-floor fix. `after/` deliberately holds that runner and other dependencies
constant and replaces only the exact fixed helper, its owned policy, and helper
tests. This isolates the floor change from concurrently developed deferred
`stage_end` billing changes. No source file was edited to synthesize the fix;
each replacement is an exact snapshot of the author's fixed file.

The actual-current-code after probe is separately preserved in `fixture-after/`
and `unit-fixtures-after/`. The controlled after probe is in
`fixture-after-isolated/` and `unit-fixtures-after-isolated/`.

This archive does not give a readiness verdict for the new deferred-billing
branch. It leaves the earlier frozen runner archive unchanged.

## Reproduce

Requires Python 3 with its standard library. Extract this archive anywhere and run:

```sh
python verify.py
python reproduce.py
```

Paths are relative to this directory. Reproduction regenerates synthetic fixture
dates to satisfy the freshness checks and asserts the before/after outcomes;
captured original inputs, synthetic SQLite ledgers, raw responses, and results
remain available for inspection. Every packaged payload file is recorded in
`SHA256SUMS.json`.
