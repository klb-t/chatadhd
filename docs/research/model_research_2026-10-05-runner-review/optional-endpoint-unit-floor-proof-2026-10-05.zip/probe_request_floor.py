"""Offline synthetic probe. Never reads an existing credential or ledger."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

MODULES = Path(sys.argv[1])
OUTPUT = Path(sys.argv[2])
sys.path.insert(0, str(MODULES))
import research_programme_runner as runner
import research_programme_manifest as manifest
import test_research_programme_runner as fixtures

test = fixtures.ProgrammeRunnerTests()
test.setUp()
try:
    policy_path = MODULES.parents[2] / "docs/research/model_research_2026-10-04/billing/endpoint-pricing-policy.json"
    test.policy["endpoint_pricing"] = json.loads(policy_path.read_bytes())
    data = json.loads(test.manifest.read_bytes())
    data["operations"][0]["units_upper_bounds"]["request"] = "0"
    test.manifest.write_bytes(fixtures.wire(data))
    endpoint = {"data": {"id": "fake/model", "endpoints": [{"model_id": "fake/model", "tag": "fake", "provider_name": "Fake", "pricing": {"prompt": "0", "completion": "0", "request": "1"}}]}}
    endpoint_raw = fixtures.wire(endpoint)
    base_send = test.send
    base_send.cost = runner.gate.amount("1")
    def send(method, route, body=None, params=None):
        response = base_send(method,route,body,params)
        if route == "model_endpoints":
            response["raw"] = endpoint_raw
        return response
    test.send = send
    operations = manifest.load_operations(data,base_dir=test.repo)
    try:
        quote = runner.endpoint_quote({"http_status":200,"raw":endpoint_raw},operations[0],runner.utc().isoformat(),test.policy)
        reservation,pairs,expected = runner.price_plan(operations,[quote],test.policy)
        planning = {"admitted": True, "reservations": {k:str(v) for k,v in reservation.items()},"pair_bounds":pairs}
    except runner.ProgrammeError as error:
        planning = {"admitted":False,"error":str(error)}
    try:
        result = test.run_stage()
    except runner.ProgrammeError as error:
        result = {"status":"preflight_rejected","error":str(error)}
    OUTPUT.mkdir(parents=True,exist_ok=True)
    shutil.copytree(test.root,OUTPUT / "synthetic_fixture",dirs_exist_ok=True)
    (OUTPUT / "policy.json").write_bytes(fixtures.wire(test.policy))
    (OUTPUT / "endpoint.json").write_bytes(endpoint_raw)
    report = {"planning":planning,"run_result":result,"post_count":len(base_send.posts()),"source_sha256":hashlib.sha256((MODULES / "endpoint_pricing_v1.py").read_bytes()).hexdigest(),"synthetic_only":True}
    (OUTPUT / "result.json").write_text(json.dumps(report,indent=2,default=str)+"\n")
    print(json.dumps(report,indent=2,default=str))
finally:
    test.doCleanups()
