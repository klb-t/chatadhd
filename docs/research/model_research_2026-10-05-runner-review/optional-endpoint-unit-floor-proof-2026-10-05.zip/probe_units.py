"""Pure fabricated component-floor cases. No network or existing ledgers."""
import hashlib
import json
from pathlib import Path
import sys

MODULES, OUTPUT = map(Path,sys.argv[1:3])
sys.path.insert(0,str(MODULES))
import endpoint_pricing_v1 as pricing
import openrouter_runner as wire

policy = json.loads((MODULES.parents[2] / "docs/research/model_research_2026-10-04/billing/endpoint-pricing-policy.json").read_bytes())
body = {"model":"test/model","provider":{"only":["test"],"allow_fallbacks":False},"messages":[{"role":"user","content":"Entirely fabricated text"}],"max_tokens":10}
request = wire.canonical(body)
summary = {}
cases = [("request", "0"),("request","0.5"),("input_cache_read","0"),("input_cache_write","1"),("input_cache_write_1h","0")]
for component, quantity in cases:
    identifier = component + "-" + quantity.replace(".","_")
    operation = {"model_id":"test/model","provider_id":"test","request_bytes":request,"request_sha256":hashlib.sha256(request).hexdigest(),"units_upper_bounds":{"prompt":str(len(request)+100),"completion":"10","request":"1"}}
    operation["units_upper_bounds"][component] = quantity
    endpoint = {"data":{"id":"test/model","endpoints":[{"model_id":"test/model","provider_name":"Synthetic provider","tag":"test","pricing":{"prompt":"0","completion":"0",component:"1"}}]}}
    raw = wire.canonical(endpoint)
    case = OUTPUT / identifier
    case.mkdir(parents=True,exist_ok=True)
    (case / "request.bin").write_bytes(request)
    (case / "endpoint.json").write_bytes(raw)
    (case / "policy.json").write_bytes(wire.canonical(policy))
    (case / "operation.json").write_bytes(wire.canonical({key:value for key,value in operation.items() if key != "request_bytes"}))
    try:
        quote = pricing.resolve_endpoint_pricing(raw,operation,policy)
        result = {"accepted":True,"quote":quote}
    except pricing.PricingError as error:
        result = {"accepted":False,"error":str(error)}
    (case / "result.json").write_bytes(wire.canonical(result))
    summary[identifier] = {"accepted":result["accepted"],"error":result.get("error")}
OUTPUT.mkdir(parents=True,exist_ok=True)
(OUTPUT / "summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
