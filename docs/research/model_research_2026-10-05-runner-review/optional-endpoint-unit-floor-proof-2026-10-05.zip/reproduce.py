import json
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix="synthetic-endpoint-review-") as temporary:
    output = Path(temporary)
    for version in ("before", "after"):
        modules = root / version / "loom/tools/structure"
        subprocess.run([sys.executable, str(root / "probe_request_floor.py"), str(modules), str(output / version / "request")], check=True)
        subprocess.run([sys.executable, str(root / "probe_units.py"), str(modules), str(output / version / "units")], check=True)
    before = json.loads((output / "before/request/result.json").read_bytes())
    after = json.loads((output / "after/request/result.json").read_bytes())
    assert before["planning"]["admitted"] and before["planning"]["reservations"] == {"one":"0"}
    assert before["post_count"] == 1 and before["run_result"]["cumulative_actual_usd"] == "1"
    assert not after["planning"]["admitted"] and after["post_count"] == 0
    low_before = json.loads((output / "before/units/summary.json").read_bytes())
    low_after = json.loads((output / "after/units/summary.json").read_bytes())
    assert low_before.keys() == low_after.keys() and len(low_before) == 5
    assert all(row["accepted"] for row in low_before.values())
    assert all(not row["accepted"] for row in low_after.values())
print("All synthetic before/after assertions passed; no HTTP calls")
