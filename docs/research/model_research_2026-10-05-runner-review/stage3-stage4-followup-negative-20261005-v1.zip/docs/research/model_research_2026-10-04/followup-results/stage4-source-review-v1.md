# Stage4 manual source-relative review v1

Completed 2026-10-05T12:17:13.226666+00:00 after published mechanical adapter freeze `a3dc9e7ab18764393ee1ce99b417fdf57b3639c3`. This DATA review applies the unchanged preregistration `9787f92838174075e34e1fa579153abbce6a28f02e57b3d653895d224163c9d8` to all twelve original public stage4 first outputs. It measures agreement with two authored synthetic DEV source commitments, not world truth, unseen holdout accuracy, general model quality or native validation of answer meaning.

All twelve planned opportunities were attempted, readable and mechanically valid. Manual target correctness is **10/12**, full semantic adequacy **9/12**, and source grounding **9/12**; each dimension has zero unavailable outcomes. All twelve actual first-attempt charges are included: **USD 0.163190**. Compiler validity remains a separate **12/12** mechanism result.

Target correctness requires all three case-specific content obligations. Full adequacy additionally includes all applicable common criteria and emitted extras. Grounding checks every source assertion and the scope/direction of proposed relations. Availability means readable for manual evaluation; it does not mean correct. The same criteria apply to both formats. No required depth, link quota, citation syntax, confidence threshold or new semantic oracle was introduced.

| Candidate | Planned/evaluable | Target correct | Full adequacy | Source grounded | Complete first-attempt USD |
| --- | ---: | ---: | ---: | ---: | ---: |
| gpt61_sol:graph_v2 | 2/2 | 2/2 | 2/2 | 2/2 | 0.015497 |
| gpt61_sol:text_json | 2/2 | 2/2 | 2/2 | 2/2 | 0.019107 |
| sonnet55:graph_v2 | 2/2 | 2/2 | 2/2 | 2/2 | 0.024352 |
| sonnet55:text_json | 2/2 | 2/2 | 1/2 | 1/2 | 0.028730 |
| gemini31_pro:graph_v2 | 2/2 | 1/2 | 1/2 | 1/2 | 0.042090 |
| gemini31_pro:text_json | 2/2 | 1/2 | 1/2 | 1/2 | 0.033414 |

The population contains three configured model settings × two formats × two distinct cases: six candidates, two opportunities each, and six matched graph/textJSON pairs. These are not repetitions or twelve independent case types. Costs include every first attempt; no component or failed semantic output is removed. No selector, Pareto winner, quota or ranking is computed here.

| Index in original public RESPONSES | Case | Model setting / arm | Target | Adequacy | Grounding | USD |
| ---: | --- | --- | --- | --- | --- | ---: |
| 0 | correction_a_b | gpt61_sol / graph_v2 | pass | pass | pass | 0.007311 |
| 1 | correction_a_b | gpt61_sol / text_json | pass | pass | pass | 0.007811 |
| 2 | correction_a_b | sonnet55 / graph_v2 | pass | pass | pass | 0.010532 |
| 3 | correction_a_b | sonnet55 / text_json | pass | fail | fail | 0.011986 |
| 4 | correction_a_b | gemini31_pro / graph_v2 | pass | pass | pass | 0.016458 |
| 5 | correction_a_b | gemini31_pro / text_json | pass | pass | pass | 0.00939 |
| 6 | negated_conditional | gpt61_sol / graph_v2 | pass | pass | pass | 0.008186 |
| 7 | negated_conditional | gpt61_sol / text_json | pass | pass | pass | 0.011296 |
| 8 | negated_conditional | sonnet55 / graph_v2 | pass | pass | pass | 0.01382 |
| 9 | negated_conditional | sonnet55 / text_json | pass | pass | pass | 0.016744 |
| 10 | negated_conditional | gemini31_pro / graph_v2 | fail | fail | fail | 0.025632 |
| 11 | negated_conditional | gemini31_pro / text_json | fail | fail | fail | 0.024024 |

All six correction prose targets preserve later user-required B and earlier A as historical. Index3 nevertheless emits `/links/2`: `n_prev --corrects--> n_file`, from the superseded-A node to the current-B node. The exact source states later `ctx_ca2.corrects = ctx_ca1`. Correct prose does not repair that preserved reversed proposal, so required-target correctness passes while full adequacy and grounding fail.

The negative-conditional source supplies only “if validation does not pass, do not publish” and the user’s report that validation is unknown and unconfirmed. It establishes neither pass/failure nor current permission. Indices10/11 correctly report unknown status but add “W związku z tym nie wolno teraz wykonać publikacji” in `publication_decision`/`decision` nodes linked to the source rule or unknown status. A risk rationale can motivate cautious assistant advice; it does not establish a new binding unknown-validation prohibition. These outputs fail `no-current-source-permission`, full adequacy and grounding. No inverse, converse or new outside policy is used to fill the source gap.

Index9 is a disclosed interpretation caveat. Its full answer explicitly preserves the conditional and unknown result, rejects pass/fail inference, and states absence of source permission. The “not yet triggered” phrase is read as no established source trigger, not verified non-failure; “trzeba poczekać” is read as contextual assistant advice in its caveat. A stricter isolated reading could mistake that wording for a new mandatory rule. The primary pass annotation and that alternative reading are retained, and an independent peer agrees with the full-context annotation. Advice needs no magic phrase, but it must retain its advisory scope. Index7 explicitly separates its cautionary recommendation from any new logical prohibition.

The JSON preserves all twelve exact first-choice strings and hashes, twelve independently rendered roots, all **46 nodes**, all **32 emitted optional proposals**, and **120 criterion records**, with response pointers/token byte ranges and exact input source-point IDs, UTF-8 spans, speaker, branch, bindingness, status and chronology. TextJSON’s duplicated public text is checked against the annotation render and does not create a second observation. Token spans are in original first-choice UTF-8 JSON content and include serialized quotes/escapes; public render spans have their own hash and coordinate system. Original private response wrappers are not accessed: their upstream public SHA anchors remain explicitly advertised rather than independently rehashed here.

Of 32 emitted proposals, 31 have compatible direction/target scope and one is the reversed correction. That diagnostic is **not** verified relation grounding or world-truth precision: Gemini’s directed links can represent the model’s proposed dependency/compliance while connecting an unsupported categorical decision, whose grounding fails separately. Empty links would have been valid and incur no absence penalty.

| Configured alias / response projection | Billed-generation model reported by public projection | Provider reported publicly |
| --- | --- | --- |
| `openai/gpt-6.1-sol` | `openai/gpt-6.1-sol-20260929` | OpenAI |
| `anthropic/claude-sonnet-5.5` | `anthropic/claude-sonnet-5.5-20260928` | Anthropic |
| `google/gemini-3.1-pro-preview` | `google/gemini-3.1-pro-preview-20260219` | Google AI Studio |

Aliases, response identities and billed-generation identities remain separate fields. All twelve public normalized rows advertise completed, replay-verified credit billing, unique generation IDs and captured request binding. This review recomputes their Decimal cost sum and preserves those upstream attestations; it does not perform new private or provider billing verification.

The independent peer inspected complete first outputs at indices3,9,10,11, with exact input source evidence. The other eight outputs received this reviewer’s full manual review; a source-only corroborator did not inspect actual outputs. Known authored DEV controls and historical scripted-artifact exposure remain disclosed. No stage3 output, new corpus, holdout, private/key/account file or provider call was used. No executable source, test, original response, source case or preregistration was edited.

Artifact bindings:

- This JSON: `stage4-source-review-v1.json`, SHA256 `375183e53017df69c9d3db42e63eddea9f1fb521634fcc9f9c0dea7b42f048f7`.
- Scoped peer JSON: `stage4-source-peer-review-build-v1.json`, SHA256 `518dabcaec1bec234f12b279448dc0f73f6ec7bf1fc031e2c465f03507d68808`.
- Scoped peer Markdown: `stage4-source-peer-review-build-v1.md`, SHA256 `350ffd607ecb66faa677a1eb95cc66640a678580bcfff18affdbe99c1cb46300`.
- `docs/research/model_research_2026-10-04/followup-semantic-preregistration-v1.json`: `9787f92838174075e34e1fa579153abbce6a28f02e57b3d653895d224163c9d8`.
- `docs/research/model_research_2026-10-04/followup-frontier-reply/final-verified-lineage/stage4/manifest.json`: `89e035f4b664121688634fc7b751d6cbab8e9e8539309581fcd84b659fea142b`.
- `docs/research/model_research_2026-10-04/programme-actual/stage4-final-20261005-v1/NORMALIZED.json`: `9a349e923c61726cfd8c3d68969688705ef07bb27319ae156845c4718e9eec77`.
- `docs/research/model_research_2026-10-04/programme-actual/stage4-final-20261005-v1/REQUESTS.json`: `6841943e62cfbb96e654ccce3ca68d53023e4b458a32d95ba6ff38b8018772bf`.
- `docs/research/model_research_2026-10-04/programme-actual/stage4-final-20261005-v1/RESPONSES.json`: `7f4f0da391dbe82649ce7e76f0fe7d2ae61b96850984f73fbb8a357fbcacba49`.
- `docs/research/model_research_2026-10-04/programme-actual/stage4-final-20261005-v1/MECHANICAL_RESULTS.json`: `19a120bec35cafb442b85cf0fd93f331cd008180c4705bf5712ca3a35d1ec443`.
- `docs/research/model_research_2026-10-04/followup-results/stage4-policy.json`: `6f21e5b1814f6eeddf77f1997361b7a58fed916e18d66a450adbe9d1b759e9ba`.

All counts have full planned denominators. These measured dimensions are suitable for a neutral summary only with their separately frozen source-relative rubric and this audit trace; none is backfilled from mechanical validity or accuracy. No new corpus is authored and no selection is performed by this review.
