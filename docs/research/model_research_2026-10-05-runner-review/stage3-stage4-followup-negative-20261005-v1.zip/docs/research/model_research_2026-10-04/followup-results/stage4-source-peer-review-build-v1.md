# Scoped stage4 manual peer review

This DATA review applies preregistration9787f to public response indices3,9,10,11 after published adaptera3dc9e7 and mechanical export. It does not change criteria or compute a full-stage score or winner.

| Index | Required targets | Full adequacy | Grounding | Reason |
| --- | --- | --- | --- | --- |
| 3 | Pass | Fail | Fail | Prose correctly preserves current B and historical A; optional A-history → corrects → current-B link reverses the source correction. |
| 9 | Pass | Pass | Pass | Full answer preserves unknown validation, rejects both pass/fail inference and automatic permission, and distinguishes no source permission from an established ban. Waiting is contextual caveat/advice; ambiguous wording is retained explicitly. |
| 10 | Fail | Fail | Fail | Unknown status is followed by a categorical current prohibition in a publication_decision node linked to the user conditional as source compliance. |
| 11 | Fail | Fail | Fail | The unknown-state node is followed by an unqualified current prohibition in a decision node depending on source conditional and unknown status. |

The identical rule is used for every model and arm: source permission not established does not entail a new binding prohibition; cautious assistant advice is allowed when its advisory scope remains explicit. Row9's complete answer expressly says the source ban is not yet established and rejects pass/fail inference, so its final waiting caveat is read as advice. The isolated wording could be read more strongly; that alternative is recorded in JSON. Rows10/11 combine categorical wording with decision/source-linked representation, so intended caution does not remove the added gate.

Direction/target compatibility of an optional edge is a narrow diagnostic, not source entailment of its connected node. Gemini edges can compatibly describe the model proposal rationale while the categorical publication decision remains ungrounded. Row3 has the opposite correction direction even though its connected prose is grounded.

The JSON records exact decoded first-content UTF8 spans, original content hashes, proposal pointers, source-point IDs/text/spans and attribution/order/status qualifiers. Mechanical validity stays separate. No stage3/new-corpus material, private ledger, credentials or payer was read, and no executable source was edited.
