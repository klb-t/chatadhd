# Stage3: manual source-relative review, 2026-10-05

Status: author draft; independent semantic peer review pending. The prospective criteria remain unchanged (`9787f92838174075e34e1fa579153abbce6a28f02e57b3d653895d224163c9d8`).

All **12/12** immutable first responses were attempted, returned HTTP200 and are credit-billed in the public normalized evidence, totalling **$0.3170690**. The frozen mechanical adapter rejects **12/12**. Eight complete responses remain interpretable for independent source-relative review; four truncated responses are unavailable. Mechanical invalidity is not counted as semantic failure. These are known authored synthetic DEV cases, not holdout, world-truth or general-model-quality evidence.

The JSON retains all first contents and hashes, source/manifest/config/adapter bindings, observed identities, original mechanical failures, billing/resource fields, and per-criterion exact decoded UTF-8 spans plus input source points. No response was stripped, repaired, retried or compiled under a loosened contract. The complete fenced Sonnet polarity response is read directly as text; its mechanical parse failure remains unchanged.

| Index | Case | Model | Track | Evaluable | Target | Adequacy | Grounding |
|---:|---|---|---|---|---|---|---|
| 0 | repeat | gpt61_sol | graph_completion | yes | unavailable | unavailable | pass |
| 1 | repeat | gpt61_sol | pattern_discovery | yes | pass | pass | pass |
| 2 | repeat | sonnet55 | graph_completion | no | unavailable | unavailable | unavailable |
| 3 | repeat | sonnet55 | pattern_discovery | no | unavailable | unavailable | unavailable |
| 4 | repeat | gemini31_pro | graph_completion | no | unavailable | unavailable | unavailable |
| 5 | repeat | gemini31_pro | pattern_discovery | yes | fail | fail | pass |
| 6 | polarity | gpt61_sol | graph_completion | yes | unavailable | unavailable | pass |
| 7 | polarity | gpt61_sol | pattern_discovery | yes | pass | pass | pass |
| 8 | polarity | sonnet55 | graph_completion | no | unavailable | unavailable | unavailable |
| 9 | polarity | sonnet55 | pattern_discovery | yes | pass | fail | fail |
| 10 | polarity | gemini31_pro | graph_completion | yes | pass | pass | pass |
| 11 | polarity | gemini31_pro | pattern_discovery | yes | pass | fail | fail |

The planned denominator stays 12. Tentative target correctness is **5/12**, semantic adequacy **3/12**, source grounding **6/12**, and semantic evaluability **8/12**. Full target/adequacy qualification is available for only six responses: four are truncated and two GPT completion responses have the unresolved qualifier issue below. Source-grounding qualification is available for all eight complete responses. Unavailable outcomes contribute no success and are retained in the denominator.

| Track | Planned | Evaluable | Target pass | Adequacy pass | Grounding pass | Mechanically valid |
|---|---:|---:|---:|---:|---:|---:|
| graph_completion | 6 | 3 | 1/6 | 1/6 | 3/6 | 0/6 |
| pattern_discovery | 6 | 5 | 4/6 | 2/6 | 3/6 | 0/6 |

| Model | Track | Planned | Evaluable | Target pass | Adequacy pass | Grounding pass |
|---|---|---:|---:|---:|---:|---:|
| gpt61_sol | graph_completion | 2 | 2 | 0/2 | 0/2 | 2/2 |
| gpt61_sol | pattern_discovery | 2 | 2 | 2/2 | 2/2 | 2/2 |
| sonnet55 | graph_completion | 2 | 0 | 0/2 | 0/2 | 0/2 |
| sonnet55 | pattern_discovery | 2 | 1 | 1/2 | 0/2 | 0/2 |
| gemini31_pro | graph_completion | 2 | 1 | 1/2 | 1/2 | 1/2 |
| gemini31_pro | pattern_discovery | 2 | 2 | 1/2 | 0/2 | 1/2 |

Completion and pattern discovery request different tasks. Their success rates do not identify a same-task winner. No model, prompt or method winner is selected in this review.

Two GPT completion responses clearly identify the affirmative `right1 → produces → right2` relation, quote the exact `right-second` source and preserve the existing records. They explicitly leave encoded polarity unspecified and treat positive normalization as unadopted or conditional. The preregistration requires positive qualifier meaning and also allows faithful paraphrase; the difference between an affirmative relation and that deliberately unspecified qualifier remains unresolved here. Core relation recognition and correct support are retained separately. Full target/adequacy are unavailable, rather than silently adding a normalization rule or requiring literal reference identity.

The GPT repeat pattern gives the required two separate positive `permits` occurrences with exact qualifiers and IDs. Its declared label abstraction uses the wrong DTO discriminator, but its meaning is explicit. The GPT polarity result correctly rejects a repeated opposite-sign pattern; its single-witness templates remain source-relative facts, not claimed recurrence or a universal law. Both pattern responses distinguish candidates from verified occurrences and decline to assert empirical group independence.

Gemini repeat emits only the longer left chain, so it misses the required two-occurrence `permits` target. Its actual left-chain witness is grounded, and the right missing edge is explicitly hypothesized. Gemini polarity emits no cross-sign repeated pair, but abstracts left-specific labels while declaring `loss: []`; the prospectively registered declared-abstraction obligation fails. The complete Sonnet polarity response correctly rejects the sign-mismatched recurrence, but falsely assigns second observations to caller source groups and calls those assignments caller-declared; only first observations have such bindings. That unsupported attribution fails overall adequacy and grounding.

The unchanged raw mechanical report records four transformation-report shape errors, two label-abstraction contract errors, five strict JSON failures (four truncations and one complete fenced response), and one top-level-array error. Neither meaningful partial text nor a manually understood schema-invalid proposal becomes an accepted GraphPacket. **Production graph use is not ready: 0/12 first responses satisfy the pinned mechanical contract.** Native C++ execution is false in this evaluation; no native-success or canonical-store claim is made.

DATA: `stage3-source-review-v1.json`, SHA-256 `81f25fc540e7f5c62648c1c6e97f648f1e3d66e3a82a0793f90470ebe33da6ed`. The first responses remain unchanged in `programme-actual/stage3-final-20261005-v1/NORMALIZED.json` (`c94bacb07f791f404fcc09830e7cfd84c6f882cf8eca87c29c352ff228a09a42`) and the mechanical report (`d474b3810c79c5d45bad204f9cda384627edf38fccf0360bf72c75ced271d430`).

## Do wątku 7

Keep protocol/schema repair distinct from semantic adequacy. The branch owner can choose future protocol groups after peer qualification, retaining unresolved meaning distinctions. This review introduces no new gold, corpus, code, policy, budget or paid request.

## Do wątku 1

The source-grounded distinctions can inform future DATA recipes: exact DTO field names and complete serialization need their own protocol instructions; qualifiers and source-versus-inference obligations retain the frozen semantic criteria. No production preset is promoted from mechanically invalid outputs.

Response model aliases and generation-reported dated model IDs remain separate. The observed public normalized generation model IDs are `openai/gpt-6.1-sol-20260929`, `anthropic/claude-sonnet-5.5-20260928` and `google/gemini-3.1-pro-preview-20260219`; response model IDs retain their undated requested aliases. Per-row generation IDs and capture hashes bind that distinction. This manual review performs no new identity authentication.
