# Invented repetition peer review

PASS final source `4eb320b01d4dc4e12c4451d3bd81714e830a52f2de11defceadb2306a2dc6561`, focused43/43. Full exact before/fixed source, tests, source/prepared request files, policy, selection, invented gold and normalized inputs/results are retained.

Replay from any archive directory with `python replay_saved_probes.py --repository /path/to/chatadhd`. Four companion module source hashes are pinned in REVIEW.json. No actual repetition result, private/account/key file, provider call or new corpus is used. Original stage4 manual review remains frozen.

The pending-state comparison explicitly changes caller DATA states and recomputes scientific operation IDs; source request bytes, unit bounds and floors remain identical. Known first labels are separate from credit billing NULL. Present contradictory credit flags reject; this lower supplied-normalized attestation is not private billing replay and does not independently validate API type. The fake API-type variant is retained as an explicit unmeasured boundary, not a claimed repaired negative.

Sibling review owns malformed and duplicate physical hash proofs. These portable witnesses belong in archive-only preservation.
