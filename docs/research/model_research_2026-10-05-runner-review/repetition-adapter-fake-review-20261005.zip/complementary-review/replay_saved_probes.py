"""Offline retained invented-fixture replay. Requires repository companion modules."""
import argparse, hashlib, importlib.util, json, pathlib, sys
p=argparse.ArgumentParser();p.add_argument('--repository',required=True,type=pathlib.Path);p.add_argument('--archive',type=pathlib.Path,default=pathlib.Path(__file__).parent);a=p.parse_args();sys.path.insert(0,str(a.repository.resolve()));root=a.archive.resolve();review=json.loads((root/'REVIEW.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for relative,expected in review['companion_modules_sha256'].items():
    assert sha((a.repository/relative).read_bytes())==expected,(relative,'companion source changed')
def module(folder):
    path=root/folder/'programme_repetition_v1.py';spec=importlib.util.spec_from_file_location('retained_'+folder.replace('-','_'),path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
checks=0
for folder in ['before-pending-billing','after-pending-billing']:
    d=root/folder;m=module(folder);r=m.score(d/'source/manifest.json',(d/'selection.json').read_bytes(),(d/'policy.json').read_bytes(),d/'prepared/manifest.json',(d/'pending-bundle.json').read_bytes(),(d/'gold.json').read_bytes());rec=r['records'][0]
    assert rec['actual_cost_usd'] is None and r['arms'][0]['cost']['total_usd'] is None
    if folder.startswith('before'):assert rec['prediction']['state']=='unavailable' and r['arms'][0]['pooled_source_label_report']['available']==3
    else:assert rec['prediction']['label']=='supported' and r['arms'][0]['pooled_source_label_report']['available']==4
    assert r==json.loads((d/'pending-result.json').read_text())
    checks+=1
for folder in ['before-explicit-billing-contradiction','after-explicit-billing-contradiction']:
    d=root/folder;m=module(folder)
    for name in ['billing-mode-byok','billing-mode-unknown','projection-is-byok-true']:
        try:r=m.score(d/'source/manifest.json',(d/'selection.json').read_bytes(),(d/'policy.json').read_bytes(),d/'prepared/manifest.json',(d/(name+'-bundle.json')).read_bytes(),(d/'gold.json').read_bytes())
        except ValueError as e:
            assert folder.startswith('after') and str(e)=='repetition_credit_attestation_contradiction'
        else:
            assert folder.startswith('before') and r['records'][0]['billing_complete'] is True
            assert r==json.loads((d/(name+'-result.json')).read_text())
        checks+=1
for folder in ['additional-fabricated-matrix','additional-fabricated-matrix-after']:
    d=root/folder;m=module(folder)
    for path in sorted(d.glob('*-bundle.json')):
        kind=path.name.removesuffix('-bundle.json');bs=kind=='bootstrap';policy=d/('bootstrap-policy.json' if bs else 'policy.json');prepared=d/('bootstrap-prepared' if bs else 'prepared')
        try:r=m.score(d/'source/manifest.json',(d/'selection.json').read_bytes(),policy.read_bytes(),prepared/'manifest.json',path.read_bytes(),(d/'gold.json').read_bytes())
        except ValueError as e:assert kind=='pending-no-gen-id' and str(e)=='repetition_generation_identity_invalid'
        else:
            arm=r['arms'][0];record=r['records'][0];assert arm['pooled_source_label_report']['query_count']==4
            if kind=='pending-bound':assert record['prediction']['label']=='supported' and record['actual_cost_usd'] is None
            elif kind=='bootstrap':assert arm['correlated_family_bootstrap']['family_count']==1 and arm['correlated_family_bootstrap']['correctness_all_planned_interval']==[.75,.75]
            elif kind=='baseline':assert arm['pooled_source_label_report']['available']==4 and arm['cost']['complete'] is True
            else:assert record['prediction']['state']=='unavailable' and record['actual_cost_usd'] is None
        if 'r' in locals() and kind!='pending-no-gen-id':assert r==json.loads((d/(kind+'-result.json')).read_text())
        checks+=1
print(json.dumps({'status':'PASS','retained_invocations':checks,'fixture_only':True,'provider_calls':0,'private_reads':0}))
