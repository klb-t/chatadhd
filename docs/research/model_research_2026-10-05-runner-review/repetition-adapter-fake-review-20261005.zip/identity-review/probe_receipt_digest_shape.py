"""Independent entirely invented receipt-binding counterexamples."""
from pathlib import Path
from copy import deepcopy
import sys,json,hashlib,shutil
sys.path.insert(0,'/workspace/scratch/407fe6f6ff42/chatadhd')
from loom.tools.structure import test_programme_repetition_v1 as f
from loom.tools.structure import programme_repetition_v1 as s
OUT=Path(__file__).resolve().parent
source_sha=hashlib.sha256(Path(s.__file__).read_bytes()).hexdigest()
assert source_sha=='ccbf01bfeb60dccd1b4cff852a1bf7d0cedfc7e496387f47936d8c3b213b59a1'
t=f.RepetitionScoreTests();t.setUp()
try:
    baseline=t.bundle();folder=OUT/'receipt-digest-before';folder.mkdir(exist_ok=True)
    shutil.copytree(t.source_dir,folder/'source',dirs_exist_ok=True)
    shutil.copytree(t.output,folder/'prepared',dirs_exist_ok=True)
    (folder/'selection.json').write_bytes(t.selection_raw);(folder/'policy.json').write_bytes(t.policy_raw);(folder/'gold.json').write_bytes(t.gold_raw)
    results={}
    for name,value,unknown in [('empty_receipt_digests','',False),('nonhex_receipt_digests','not-a-sha256',False),('null_receipt_digests_unknown_credit',None,True)]:
        bundle=deepcopy(baseline)
        for key in ('response_sha256','generation_sha256'):
            bundle['rows'][0][key]=value;bundle['responses'][0][key]=value
        if unknown:
            bundle['rows'][0].update(billing_verified=False,billing_replay_verified=False,actual_cost_usd=None)
        result=t.score(bundle)
        (folder/(name+'-bundle.json')).write_bytes(f.canonical(bundle))
        (folder/(name+'-result.json')).write_bytes(f.canonical(result))
        results[name]={'first_prediction':result['records'][0]['prediction'],
          'first_reported_digest':result['records'][0]['response_sha256'],
          'first_generation_digest':result['records'][0]['generation_sha256'],
          'first_actual_cost_usd':result['records'][0]['actual_cost_usd'],
          'first_billing_complete':result['records'][0]['billing_complete'],
          'pooled_source_labels_available':result['arms'][0]['pooled_source_label_report']['available'],
          'cost':result['arms'][0]['cost']}
        assert result['records'][0]['prediction']['state']=='completed'
        assert result['arms'][0]['pooled_source_label_report']['available']==4
        if not unknown:assert result['records'][0]['billing_complete'] is True
    proof={'fabricated_only':True,'source_sha256':source_sha,'results':results}
    (folder/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
finally:t.doCleanups()
