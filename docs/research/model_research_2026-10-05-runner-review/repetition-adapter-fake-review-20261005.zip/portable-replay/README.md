# Standalone repetition fake-negative replay closure

Run from a clean extraction of the combined archive:

```sh
python portable-replay/replay_all.py --archive . --companions portable-replay/closure
```

The closure carries the exact final helper/tests and unchanged companion source
modules/contracts. It requires Python and `jsonschema`; recorded runtime versions
are in `CLOSURE.json`. All scenarios are invented offline source/query/selection/
gold/request/normalized-receipt fixtures. No actual response, payer, ledger,
credential, native binary, environment dump or provider call is used.

The replay verifies 12 native-peer invocations and 26 complementary-peer
invocations, then all 43 unique focused tests with no skips. Retained negative
sources are exact SHA-gated ccbf (malformed digest acceptance), 40af (physical
capture reuse), and 213e7 (explicit credit contradictions and the earlier pending
label boundary). Fixed source is exact 4eb and tests exact 82a. Every saved full
successful output is compared; financial rejections assert their exact guard code.
The source-policy change allowing bound `pending_billing` labels is retained as
explicit caller DATA. It changes derived planned IDs but preserves every original
request byte, prompt hash, unit bound and minimum reservation. Unknown credit
remains null; failed/ambiguous first rows never become completed labels.

`bound-pending-final-4eb-result.json` is a new full replay result using the final
source on the native peer's complete invented input. That peer's original pending
result was produced by exact 213e7. The replay checks that only the recorded helper
code digest changes in this unchanged-output case, then compares the final full
result too. Original before/fixed results are preserved without replacement.
The complementary review discloses two baseline result files reconstructed from
the exact retained 213e7 source; original negative outputs were unchanged.

Orphan-capture and JSON boolean/number-substitution regression tests are included
in final 43; their preventive code-review fixes preceded the SHA-recorded baseline.
They are not represented as newly reconstructed exact historical failures.
Source-label agreement remains separate from credit attestations, native grounding,
semantic adequacy and world truth. Public normalized projections are a lower
attestation boundary, not an independent replay of private/provider bytes or API
type verification. No new corpus or automatic promotion is performed.
