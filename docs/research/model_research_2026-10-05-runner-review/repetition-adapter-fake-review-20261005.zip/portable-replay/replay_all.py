"""Reproduce complete retained fake repetition negatives; never provider I/O."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, subprocess, sys, unittest
sys.dont_write_bytecode = True
p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,default=Path(__file__).resolve().parent.parent)
p.add_argument('--companions',type=Path,default=Path(__file__).resolve().parent/'closure');a=p.parse_args()
archive=a.archive.resolve();own=Path(__file__).resolve().parent;companions=a.companions.resolve()
sha=lambda x:hashlib.sha256(x).hexdigest()
closure=json.loads((own/'CLOSURE.json').read_text())
for name,h in closure['source_sha256'].items():assert sha((companions/name).read_bytes())==h,(name,'closure drift')
sys.path.insert(0,str(companions))
from loom.tools.structure import programme_repetition_v1 as fixed
from loom.tools.structure import test_programme_repetition_v1 as tests
assert sha(Path(fixed.__file__).read_bytes())=='4eb320b01d4dc4e12c4451d3bd81714e830a52f2de11defceadb2306a2dc6561'
assert sha(Path(tests.__file__).read_bytes())=='82aeb0a78b15202901c4bbd5e06e99a23294dcc650fe5f72111a50ad9a83e23d'
def module(path,label,expected):
 assert sha(path.read_bytes())==expected
 spec=importlib.util.spec_from_file_location(label,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def score(m,d,bundle,policy='policy.json',prepared='prepared'):
 return m.score(d/'source/manifest.json',(d/'selection.json').read_bytes(),(d/policy).read_bytes(),d/prepared/'manifest.json',bundle,(d/'gold.json').read_bytes())
def equal_result(result,path):assert result==json.loads(path.read_text()),str(path)
checks=0;identity=archive/'identity-review';other=archive/'complementary-review'
before=module(identity/'candidate-ccbf01bfeb60/loom/tools/structure/programme_repetition_v1.py','negative_ccbf','ccbf01bfeb60dccd1b4cff852a1bf7d0cedfc7e496387f47936d8c3b213b59a1')
fixture=identity/'receipt-digest-before'
for name in ['empty_receipt_digests','nonhex_receipt_digests','null_receipt_digests_unknown_credit']:
 result=score(before,fixture,(fixture/(name+'-bundle.json')).read_bytes());equal_result(result,fixture/(name+'-result.json'))
 assert result['records'][0]['prediction']['state']=='completed' and result['arms'][0]['pooled_source_label_report']['available']==4
 checks+=1
middle=module(identity/'candidate-40afc388a39e/programme_repetition_v1.py','negative_40af','40afc388a39e1878690b4d4dd278c8921cd702da543071591d73130612ddecc3')
for name in ['empty_receipt_digests','nonhex_receipt_digests','null_receipt_digests_unknown_credit']:
 try:score(middle,fixture,(fixture/(name+'-bundle.json')).read_bytes())
 except ValueError as e:assert str(e)=='repetition_first_capture_hash_invalid'
 else:raise AssertionError('middle digest guard failed')
 checks+=1
result=score(middle,fixture,(identity/'duplicate-physical-capture-bundle.json').read_bytes());equal_result(result,identity/'duplicate-physical-capture-result.json')
assert result['records'][0]['billing_complete'] and result['records'][1]['billing_complete'];checks+=1
fresh=identity/'fresh-fixed-hash-probes'
for name,error in [('empty_capture_hash','repetition_first_capture_hash_invalid'),('null_capture_hash','repetition_first_capture_hash_invalid'),('duplicate_success_http_hash','repetition_duplicate_successful_first_capture'),('duplicate_proven_generation_hash','repetition_duplicate_verified_generation_capture')]:
 try:score(fixed,fresh,(fresh/(name+'-bundle.json')).read_bytes())
 except ValueError as e:assert str(e)==error
 else:raise AssertionError('fixed guard failed:'+name)
 checks+=1
result=score(fixed,fresh,(fresh/'bound-pending-bundle.json').read_bytes())
assert result['records'][0]['prediction']['label']=='supported' and result['records'][0]['actual_cost_usd'] is None
assert result['arms'][0]['pooled_source_label_report']['query_count']==4
expected=json.loads((fresh/'bound-pending-result.json').read_text())
# The peer stored this full result at exact intermediate213; the final4eb adds
# only the explicit-credit contradiction guard. Keep both source identities.
expected['code_sha256']['repetition_adapter']=sha(Path(fixed.__file__).read_bytes())
assert result==expected
final_saved=own/'bound-pending-final-4eb-result.json'
if final_saved.exists():equal_result(result,final_saved)
checks+=1
# Complementary peer's complete before/fixed result replay is itself retained.
completed=subprocess.run([sys.executable,str(other/'replay_saved_probes.py'),'--repository',str(companions),'--archive',str(other)],capture_output=True,text=True)
assert completed.returncode==0,completed.stdout+completed.stderr
complementary=json.loads(completed.stdout.strip());assert complementary['status']=='PASS' and complementary['retained_invocations']==26
suite=unittest.defaultTestLoader.loadTestsFromModule(tests);assert suite.countTestCases()==43
runner=unittest.TextTestRunner(verbosity=1);result=runner.run(suite);assert result.wasSuccessful() and not result.skipped
print(json.dumps({'status':'PASS','own_retained_invocations':checks,'complementary_retained_invocations':26,'focused_unique_tests_passed':43,'provider_calls':0,'private_reads':0,'actual_repeat_outputs_read':False,'boundary':'Exact retained draft and final sources with full invented input/output fixtures. Public normalized attestations are not independent private/provider receipt replay.'},sort_keys=True))
