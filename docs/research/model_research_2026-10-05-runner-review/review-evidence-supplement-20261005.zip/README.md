# Archive-only evidence supplement

Retains first failed endpoint-pricing test, unit-floor review source/input/result
trees, and immutable first stage-1 partial output (432 planned, two attempted).

The partial output's sixteen retained file hashes and eight semantic aggregation
fields replay against the exact recovered legacy scoring code. The v1 generic
producer source with SHA c8756798 was not retained and has not been recovered;
the orchestration module also was not snapshotted or source-hashed. Full producer
regeneration is therefore NOT claimed. Artifact inspection and the narrower
semantic replay are independently verified. RECOVERY.json and SEMANTIC_REPLAY.json
state the exact boundary; missing source is not replaced by an invented match.

Current accepted producers live in Git; this first partial tree is archive-only.
No real credential or private account records are included.
