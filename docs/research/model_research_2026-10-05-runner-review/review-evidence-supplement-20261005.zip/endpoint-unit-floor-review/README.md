# Endpoint quantity floors: complete before/after proof

No credential, account access or inference occurs. All inputs are public
endpoint snapshots, synthetic frozen request manifests or fabricated operations.

baseline/: original22 tests, old helper/data (22/22 PASS).
before/: old helper/data with new27 tests:5 rejected expectations fail, plus2
new data-rule tests have setup errors because old data lacks those rule maps.
Those2 setup errors are retained and are not classified as estimator defects.
before-with-new-floor-data/: old helper, new explicit caller-owned floor data,
and the same27 tests:7 failed assertions,0 errors. This independently proves
that the old universal operation ignores both new declarative floor rules.
after/: new helper/data and the identical27 tests (27/27 PASS).

Operational negatives: explicit request quantity0 with a positive flat price,
each of3 cache quantities below declared prompt allowance, and reasoning meeting
the wire limit200 but below declared output allowance400. Data-operation
negatives: caller-owned minimum_value2 ignored and unknown minimum_bound
reference ignored. All component names, values and references remain data.

Replay in each selected phase directory:

    python3 -B -m unittest discover -s loom/tools/structure -p test_endpoint_pricing_v1.py -v

All sources, inputs and first replay outputs are included and hashed. The first
summary parser failed to parse the combined failures/errors form; its summary
and README are retained verbatim under first-summary-*. The corrected manifest
uses the already preserved raw logs and reports failures and errors separately.
Actual declared bounds and quantities for24 frozen frontier bodies remain
unchanged and valid under new rules. Historical policy bytes are preserved.
