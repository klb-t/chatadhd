# Endpoint quantity floors: full before/after proof

No credential, account access or inference occurs. All inputs are public
endpoint snapshots, synthetic frozen request manifests or fabricated operations.

baseline/: original22 tests, old helper/data (22/22 PASS).
before/: the same old helper/data with all27 new tests (7 failing assertions in
5 new test methods; all original tests continue passing).
after/: new helper/data and the identical27 tests (27/27 PASS).

The negative cases demonstrate explicit request quantity0 with a positive flat
price, each of3 explicit cache quantities below the declared prompt allowance,
reasoning meeting the wire limit200 but below the declared output allowance400,
a caller-owned minimum_value2 ignored by old code, and an unknown minimum_bound
reference ignored by old code. New code supports both floor operations
universally; all component names and floor values/references remain policy data.

Replay in each selected phase directory:

    python3 -B -m unittest discover -s loom/tools/structure -p test_endpoint_pricing_v1.py -v

Every source, public input and first replay output is included and hashed.
Old projection policy bytes are preserved in baseline/ and before/; no historical
receipt is rewritten. Actual declared bounds for24 frozen frontier bodies stay
unchanged and valid under the new data rules.
