from pathlib import Path
import json,sys,tempfile
sys.path.insert(0,'/workspace/scratch/407fe6f6ff42/chatadhd/loom/tools/structure')
import programme_native_results_v1 as adapter
import test_programme_native_results_v1 as fixture
ROOT=Path('/workspace/scratch/407fe6f6ff42/chatadhd');BIN=ROOT.parent/'build/loom_candidate_graph_native_tool'
inputs=fixture.fixture(1)
inputs[-1]['validator'].update(executable=str(BIN),expected_binary_sha256=adapter.sha(BIN.read_bytes()),timeout_seconds=30,provenance_files=[])
validator=adapter.NativeValidator(inputs[-1]['validator'])
response=inputs[0]['responses'][0]['projection']['choices'][0]['message']['content']
bundle=adapter.parse(response.encode())['bundles'][0]
payload=adapter.canonical({'packet':inputs[2]['cases'][0]['source_packet'],'bundle':bundle,'vocabulary':inputs[3]})
stdout=validator(payload)['stdout']
with tempfile.TemporaryDirectory(prefix='fabricated-canned-report-') as directory:
 executable=Path(directory)/'canned-report'
 executable.write_text('#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3\nimport sys\nsys.stdout.buffer.write(bytes.fromhex('+repr(stdout.hex())+'))\n')
 executable.chmod(0o755)
 validator.executable=executable
 result=adapter.evaluate(*inputs,validator=validator)
 print(json.dumps({'adapter_sha256':adapter.sha(Path(adapter.__file__).read_bytes()),'policy_binary':inputs[-1]['validator']['executable'],'recorded_binary':result['validator']['binary'],'actual_invoked_executable':str(executable),'actual_invoked_sha256':adapter.sha(executable.read_bytes()),'recorded_binary_sha256':result['validator']['binary_sha256'],'counts':result['counts']},indent=2))
