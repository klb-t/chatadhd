from pathlib import Path
from copy import deepcopy
import hashlib,json,sys,tempfile
sys.path.insert(0,'/workspace/scratch/407fe6f6ff42/chatadhd/loom/tools/structure')
import programme_native_results_v1 as adapter
ROOT=Path('/workspace/scratch/407fe6f6ff42/chatadhd')
BINARY=ROOT.parent/'build/loom_candidate_graph_native_tool'

def fixture():
 policy=adapter.read(ROOT/'docs/research/model_research_2026-10-04/native-results-policy.json')
 case=adapter.read(ROOT/'loom/tests/fixtures/eval/independent_candidate_graph_v1/development_cases.json')['cases'][0]
 packet,bundle=deepcopy(case['source_packet']),deepcopy(case['direct_bundle'])
 vocabulary=adapter.read(ROOT/'loom/tools/structure/candidate_graph_vocabulary.json')
 packet_hash=adapter.digest(packet)
 body={'model':'fabricated/model','messages':[{'role':'user','content':adapter.canonical({'packet_hash':packet_hash,'source_packet':packet}).decode()}]}
 body_hash=adapter.digest(body)
 content=adapter.canonical({'schema_version':2,'packet_hash':packet_hash,'bundles':[bundle,bundle]}).decode()
 response_projection={'choices':[{'message':{'role':'assistant','content':content},'finish_reason':'stop'}]}
 response_hash=adapter.digest(response_projection)
 prepared={'schema':policy['input_schemas']['prepared'],'planned_requests':1,'requests':[{'request':{'id':'fabricated-request','body':body},'request_hash':body_hash,'packet_hash':packet_hash,'case_id':'fabricated-case','method_id':'fabricated-method'}]}
 sources={'schema':policy['input_schemas']['source_inputs'],'cases':[{'id':'fabricated-case','source_packet':packet,'packet_hash':packet_hash}]}
 normalized={'schema':policy['input_schemas']['normalized'],'stage_id':'fabricated-stage','planned_operations':1,'planned_operation_ids':['fabricated-operation'],'requests':[{'operation_id':'fabricated-operation','body':body,'request_sha256':body_hash,'metadata':{'prepared_request_id':'fabricated-request','arm_id':'fabricated-method'}}], 'rows':[{'operation_id':'fabricated-operation','state':'completed','completed':True,'billing_replay_verified':False,'request_sha256':body_hash,'response_sha256':response_hash,'response_ledger_bound':True}], 'responses':[{'operation_id':'fabricated-operation','response_sha256':response_hash,'projection':response_projection}]}
 policy['validator'].update(executable=str(BINARY),expected_binary_sha256=adapter.sha(BINARY.read_bytes()),timeout_seconds=30,provenance_files=[str(ROOT/'loom/tests/compat/candidate_graph_native_tool.cpp')])
 return normalized,prepared,sources,vocabulary,policy

def summary(result):
 return {'counts':result['counts'],'backend':result['validator']['backend'],'native_execution':result['validator']['native_execution'],'policy_digest':result['source_hashes']['policy_canonical'], 'statuses':[r['status'] for r in result['receipts']], 'preserved_content':[c['content'] for r in result['receipts'] for c in r['choices']], 'alternatives':[{'valid':a['native_verified_valid'],'failure':a['failure'],'executed':a['native_execution'],'returncode':a.get('returncode'),'stdout_hex':a.get('stdout_hex'),'stderr_hex':a.get('stderr_hex')} for r in result['receipts'] for c in r['choices'] for a in c['alternatives']]}

inputs=fixture()
real=adapter.evaluate(*inputs)
callback_validator=adapter.NativeValidator(inputs[-1]['validator'])
callback=adapter.evaluate(*fixture(),validator=lambda payload:callback_validator(payload),callback_id='fabricated-callback')
wrong=fixture();good_validator=adapter.NativeValidator(wrong[-1]['validator']);wrong[-1]['validator']['expected_binary_sha256']='0'*64
try: result=adapter.evaluate(*wrong,validator=good_validator);bypass={'accepted':True,'result':summary(result)}
except Exception as error:bypass={'accepted':False,'error':type(error).__name__,'reason':str(error)}
missing=fixture();missing[0]['rows']=[];missing[0]['responses']=[];missing_result=adapter.evaluate(*missing)
transport=[]
with tempfile.TemporaryDirectory(prefix='fabricated-native-process-') as directory:
 for name,body in [('nonzero',"import sys\nsys.stdout.buffer.write(b'raw-partial')\nsys.stderr.buffer.write(b'crash-evidence')\nsys.exit(23)\n"),('malformed',"import sys\nsys.stdout.buffer.write(b'not-json')\n"),('timeout',"import time\ntime.sleep(0.04)\n")]:
  executable=Path(directory)/name;executable.write_text('#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3\n'+body);executable.chmod(0o755)
  x=fixture();x[-1]['validator'].update(executable=str(executable),expected_binary_sha256=adapter.sha(executable.read_bytes()),timeout_seconds=0.001 if name=='timeout' else 30,provenance_files=[])
  transport.append({'case':name,'result':summary(adapter.evaluate(*x))})
out={'adapter_sha256':adapter.sha(Path(adapter.__file__).read_bytes()),'real':summary(real),'callback':summary(callback),'wrong_policy_native_validator_injection':bypass,'missing':summary(missing_result),'transport':transport}
print(json.dumps(out,indent=2))
assert real['counts']['native_verified_valid']==1 and real['counts']['native_bundle_invocations']==2
assert callback['counts']['native_verified_valid']==0 and callback['counts']['native_execution_captures']==0
assert missing_result['counts']['planned']==1 and missing_result['counts']['missing_responses']==1
assert all(not a['valid'] for x in transport for a in x['result']['alternatives'])
