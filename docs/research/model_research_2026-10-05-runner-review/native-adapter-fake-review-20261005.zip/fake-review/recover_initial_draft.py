from pathlib import Path
import hashlib,re
repo=Path('/workspace/scratch/407fe6f6ff42/chatadhd')
p=repo/'loom/tools/structure/programme_native_results_v1.py';s=p.read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:80],s.count(old));s=s.replace(old,new)
replace('import importlib\n','')
replace('def aggregate(values):\n    return False if any(value is False for value in values) else None if any(value is None for value in values) else True\n\n\n','')
replace('            capture["error"] = "native_binary_or_provenance_changed"','            raise NativeResultsError("native_binary_or_provenance_changed")')
replace('        check_schema(report["coverage"], options["accepted_coverage_schema"])\n','')
a=s.index('        for binding in options["accepted_derived_bindings"]:');b=s.index('    elif report["packet_hash"] is not None',a);s=s[:a]+s[b:]
a=s.index('        configured = NativeValidator(policy["validator"])');b=s.index('        provenance = deepcopy(validator.provenance)',a);s=s[:a]+s[b:]
replace('    reference_validation = None\n','')
a=s.index('        configured = reference_policy["validator"]');b=s.index('    for prepared_id, plan in plans.items():',a);s=s[:a]+s[b:]
replace('                        choice_receipt["validator_contract_valid"] = False\n                        if provenance["native_execution"]:\n                            choice_receipt["native_contract_valid"] = False\n','')
replace('(aggregate([choice["native_contract_valid"] for choice in receipt["choices"]])','(all(choice["native_contract_valid"] is True for choice in receipt["choices"])')
replace('(aggregate([choice["validator_contract_valid"] for choice in receipt["choices"]])','(all(choice["validator_contract_valid"] is True for choice in receipt["choices"])')
replace('                                     "partial_abstention" if any(choice["alternatives"] for choice in receipt["choices"]) and all(choice["envelope_valid"] for choice in receipt["choices"]) else\n','')
replace('                         "native_contract_valid": receipt["native_contract_valid"] if len(receipt["choices"]) == 1 else None,\n                         "mechanical_native_contract_valid": receipt["native_contract_valid"], "bundle_count": len(alternatives),','                         "native_contract_valid": receipt["native_contract_valid"], "bundle_count": len(alternatives),')
replace('                       "validator_alternative_attempts": sum(len(choice["alternatives"]) for receipt in receipts for choice in receipt["choices"]),\n                       "native_bundle_invocations": sum(alternative["native_execution"] for receipt in receipts for choice in receipt["choices"] for alternative in choice["alternatives"]),','                       "native_bundle_invocations": sum(len(choice["alternatives"]) for receipt in receipts for choice in receipt["choices"]),')
replace('"validator": provenance, "effective_policy": deepcopy(policy), "new_model_calls": 0','"validator": provenance, "new_model_calls": 0')
replace('                                       "reference_validation": reference_validation,\n','')
raw=s.encode();observed=hashlib.sha256(raw).hexdigest();expected='00618f64bf1bc6e028b5d3e4b096df3de462513de03091c5566bfec87eda92f5'
out=repo.parent/'native-adapter-review-20261005/negative-source-00618f64/loom/tools/structure/programme_native_results_v1.py'
print('candidate hash',observed,'MATCH' if observed==expected else 'NOT MATCH')
if observed==expected:out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
else:(repo.parent/'native-adapter-review-20261005/recovered-initial-candidate-unverified.py').write_bytes(raw)
