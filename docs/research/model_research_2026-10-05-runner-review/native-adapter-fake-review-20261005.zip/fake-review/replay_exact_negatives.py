from pathlib import Path
import importlib.util,json,sys,tempfile
from unittest.mock import patch
ROOT=Path('/workspace/scratch/407fe6f6ff42/chatadhd');REVIEW=ROOT.parent/'native-adapter-review-20261005'
sys.path.insert(0,str(ROOT/'loom/tools/structure'))
import programme_native_results_v1 as fixed
import test_programme_native_results_v1 as fixtures

def load(label):
 p=REVIEW/label/'loom/tools/structure/programme_native_results_v1.py'
 spec=importlib.util.spec_from_file_location(label.replace('-','_'),p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
first=load('negative-source-00618f64');base=REVIEW/'negative-source-00618f64/effective-inputs'
values=[first.read(base/(name+'.json')) for name in ['normalized','prepared','source-inputs','vocabulary','real-effective-policy']]
instance=first.NativeValidator(values[-1]['validator']);values[-1]=first.read(base/'wrong-native-instance-effective-policy.json')
with patch.object(first.subprocess,'run',wraps=first.subprocess.run) as invoke:
 result=first.evaluate(*values,validator=instance)
assert result['counts']['native_verified_valid']==1
initial=json.loads((REVIEW/'draft-probes.json').read_bytes())
assert result['source_hashes']['policy_canonical']==initial['wrong_policy_native_validator_injection']['result']['policy_digest']
proof={'first_expected_hash_bypass':{'source_sha256':first.sha(Path(first.__file__).read_bytes()),'recovered_policy_canonical_sha256':result['source_hashes']['policy_canonical'],'recorded_initial_policy_canonical_sha256':initial['wrong_policy_native_validator_injection']['result']['policy_digest'],'counts':result['counts'],'observed_process_argv':[call.args[0] for call in invoke.call_args_list]}}
second=load('negative-source-70bd2b84');inputs=fixtures.fixture(1);binary=ROOT.parent/'build/loom_candidate_graph_native_tool'
inputs[-1]['validator'].update(executable=str(binary),expected_binary_sha256=second.sha(binary.read_bytes()),timeout_seconds=30,provenance_files=[])
validator=second.NativeValidator(inputs[-1]['validator'])
content=inputs[0]['responses'][0]['projection']['choices'][0]['message']['content'];bundle=second.parse(content.encode())['bundles'][0]
payload=second.canonical({'packet':inputs[2]['cases'][0]['source_packet'],'bundle':bundle,'vocabulary':inputs[3]});stdout=validator(payload)['stdout']
with tempfile.TemporaryDirectory(prefix='fabricated-exact-negative-') as directory:
 executable=Path(directory)/'canned-report';executable.write_text('#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3\nimport sys\nsys.stdout.buffer.write(bytes.fromhex('+repr(stdout.hex())+'))\n');executable.chmod(0o755)
 validator.executable=executable
 with patch.object(second.subprocess,'run',wraps=second.subprocess.run) as invoke:
  result=second.evaluate(*inputs,validator=validator)
 assert result['counts']['native_verified_valid']==1
 observed=[call.args[0] for call in invoke.call_args_list];assert observed==[[str(executable)]]
 proof['second_mutable_instance_bypass']={'source_sha256':second.sha(Path(second.__file__).read_bytes()),'recorded_native_binary':result['validator']['binary'],'recorded_native_binary_sha256':result['validator']['binary_sha256'],'observed_process_argv':observed,'observed_process_binary_sha256':second.sha(executable.read_bytes()),'counts':result['counts']}
print(json.dumps(proof,indent=2))
