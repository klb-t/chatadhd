# Post-collection gold container correction: invented replay supplement

The original prepaid repetition adapter SHA4eb accepted a top-level cases list. The coordinator identified the already-bound public gold format as a dictionary after 192 paid requests were collected, before a score. This supplement preserves an exact4eb failure using ONLY invented dictionaries, cases, requests, source labels and receipt projections. No actual gold labels, repeated outputs, private records, key or provider material is included or inspected.

`before/` holds the exact prepaid adapter/tests plus a full invented source/selection/policy/prepared/gold/bundle and original error. `after/` holds corrected9aec adapter/tests7928 and the complete output from the same unchanged invented input bytes, using explicit runtime `/cases`. `companions/` is the exact pure source/schema closure required to import and execute these modules. The correction leaves preparation configuration and request IDs unchanged; the entire raw gold is hash-bound before JSON-pointer selection. Default empty pointer retains list behavior and fails dictionaries. The selected canonical array hash and pointer are explicit score provenance.

Run in a clean extraction with Python and jsonschema installed:

```sh
python replay.py
```

The script verifies all payload hashes/sizes, SHA-gates exact before/fixed sources, reproduces the original format failure and corrected full output, and executes all 52 focused invented tests. It performs no provider I/O or actual data reads. Missing/invalid paths, wrong selected types, raw gold changes and query inventory mismatches remain failures. Native grounding, semantic adequacy, world truth, holdout and billing attestation boundaries are unchanged. This is a format correction after collection, not a new label, criterion, threshold, request or scientific-outcome tuning.
