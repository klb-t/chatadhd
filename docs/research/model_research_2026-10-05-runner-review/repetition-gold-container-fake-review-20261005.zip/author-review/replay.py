"""Replay exact gold-container before/fixed sources using invented inputs only."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
manifest_path = ROOT / 'MANIFEST.json'
if manifest_path.exists():
    for entry in json.loads(manifest_path.read_bytes())['files']:
        raw = (ROOT / entry['path']).read_bytes()
        assert len(raw) == entry['size_bytes'] and sha(raw) == entry['sha256'], entry['path']
sys.path.insert(0, str(ROOT / 'companions'))

def load(folder, name, expected):
    path = ROOT / folder / name
    assert sha(path.read_bytes()) == expected, str(path)
    spec = importlib.util.spec_from_file_location(folder + '_' + name[:-3], path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

before = load('before', 'programme_repetition_v1.py', '4eb320b01d4dc4e12c4451d3bd81714e830a52f2de11defceadb2306a2dc6561')
fixed = load('after', 'programme_repetition_v1.py', '9aec8378f5e51b78cf7a9bfcb02fbcb1a3d027e3471a0ebdef6ea27d5e8ea560')
d = ROOT / 'before/fixture'
arguments = (d / 'source/manifest.json', (d / 'selection.json').read_bytes(),
             (d / 'policy.json').read_bytes(), d / 'prepared/manifest.json',
             (d / 'bundle.json').read_bytes(), (d / 'gold.json').read_bytes())
for module in (before, fixed):
    try:
        module.score(*arguments)
    except ValueError as error:
        assert str(error) == 'repetition_gold_invalid'
    else:
        raise AssertionError('Default empty selector must retain list-only behavior')
expected_failure = json.loads((ROOT / 'before/result.json').read_bytes())
assert expected_failure['message'] == 'repetition_gold_invalid'
assert expected_failure['exception_type'] == 'ValueError'
result = fixed.score(*arguments, gold_cases_pointer='/cases')
gold = json.loads(arguments[-1])
assert result['gold_selection'] == {'cases_pointer': '/cases',
    'source_sha256': sha(arguments[-1]),
    'selected_array_sha256': sha(fixed.wire.canonical(gold['cases']))}
assert result['planned_operations'] == 8
assert all(arm['pooled_source_label_report']['available'] == 4 for arm in result['arms'])
saved = ROOT / 'after/result.json'
if '--record' in sys.argv:
    saved.write_bytes(fixed.wire.canonical(result) + b'\n')
assert result == json.loads(saved.read_bytes())
sys.modules['programme_repetition_v1'] = fixed
tests = load('after', 'test_programme_repetition_v1.py', '7928da45ba50e8c486f2cf09ffa0d31fa842dce385985d6a231a2d356bc430bc')
tests.r = fixed
suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
assert suite.countTestCases() == 52
tested = unittest.TextTestRunner(verbosity=1).run(suite)
assert tested.wasSuccessful() and not tested.skipped
print(json.dumps({'status': 'PASS', 'exact_before_failure_reproduced': True,
    'fixed_same_invented_raw_gold_and_manifest_reproduced': True,
    'default_list_behavior_preserved': True, 'focused_tests_passed': 52,
    'provider_calls': 0, 'actual_gold_or_model_outputs_read': False,
    'private_material_read': False}, sort_keys=True))
