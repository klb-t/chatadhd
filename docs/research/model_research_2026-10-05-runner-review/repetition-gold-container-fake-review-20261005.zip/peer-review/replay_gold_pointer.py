"""Saved fake-only gold-container regression and independent selector probes."""
from copy import deepcopy
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--record',action='store_true');a=p.parse_args();root=a.archive.resolve()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
for name,digest in json.loads((root/'closure-identity.json').read_bytes())['sha256_by_path'].items():
 assert sha((root/name).read_bytes())==digest,('closure drift',name)
canonical=lambda v:json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
sys.path.insert(0,str(root/'fixed-closure'))
from loom.tools.structure import programme_repetition_v1 as fixed
from loom.tools.structure import test_programme_repetition_v1 as fixtures
assert sha(Path(fixed.__file__).read_bytes())=='9aec8378f5e51b78cf7a9bfcb02fbcb1a3d027e3471a0ebdef6ea27d5e8ea560'
assert sha(Path(fixtures.__file__).read_bytes())=='7928da45ba50e8c486f2cf09ffa0d31fa842dce385985d6a231a2d356bc430bc'
before_path=root/'before-closure/loom/tools/structure/programme_repetition_v1.py';assert sha(before_path.read_bytes())=='4eb320b01d4dc4e12c4451d3bd81714e830a52f2de11defceadb2306a2dc6561'
spec=importlib.util.spec_from_file_location('saved_before_4eb',before_path);before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
def inputs(d):
 return (d/'source/manifest.json',(d/'selection.json').read_bytes(),(d/'policy.json').read_bytes(),d/'projected/manifest.json',(d/'bundle.json').read_bytes(),(d/'gold.json').read_bytes())
def files(d):return {q.relative_to(d).as_posix():sha(q.read_bytes()) for q in d.rglob('*') if q.is_file()}
def save(name,value):
 q=root/(name+'.json')
 if a.record:q.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
 else:assert value==json.loads(q.read_bytes()),name
checks=[]
def guard(name,d,selector,error,gold=None):
 args=list(inputs(d));
 if gold is not None:args[-1]=gold
 try:fixed.score(*args,gold_cases_pointer=selector)
 except (ValueError,KeyError,TypeError,IndexError) as e:
  assert type(e).__name__==error[0] and (error[1] is None or str(e)==error[1]),(name,type(e).__name__,str(e))
  result={'probe':name,'exception':type(e).__name__,'message':str(e),'selector':selector}
 else:raise AssertionError('invalid selector/inventory accepted:'+name)
 checks.append(result)
def build(name,convert):
 d=root/name
 if a.record:
  f=fixtures.RepetitionScoreTests('test_all_first_answers_correct_with_planned_repeat_denominators');f.setUp()
  try:
   f.gold_raw=canonical(convert(json.loads(f.gold_raw)));f.policy['scoring']['gold_sha256']=sha(f.gold_raw);f.policy_raw=canonical(f.policy);b=f.bundle()
   for n,v in [('gold',f.gold_raw),('policy',f.policy_raw),('selection',f.selection_raw),('bundle',canonical(b))]:(f.directory/(n+'.json')).write_bytes(v)
   shutil.copytree(f.directory,d)
  finally:f.doCleanups()
 return d
original=root/'dict-fixture';original_before=files(original)
try:before.score(*inputs(original))
except ValueError as e:assert str(e)=='repetition_gold_invalid';checks.append({'probe':'exact_before_dict_failure','exception':'ValueError','message':str(e)})
else:raise AssertionError('Original source unexpectedly supported dict container')
fixed_dict=fixed.score(*inputs(original),gold_cases_pointer='/cases');save('dict-fixed-result',fixed_dict)
assert fixed_dict['planned_operations']==8 and all(arm['pooled_source_label_report']['available']==4 for arm in fixed_dict['arms'])
assert fixed_dict['gold_selection']=={'cases_pointer':'/cases','source_sha256':sha(inputs(original)[-1]),'selected_array_sha256':sha(canonical(json.loads(inputs(original)[-1])['cases']))}
assert original_before==files(original)
checks.append({'probe':'exact_fixed_dict_pass','planned_operations':8,'all_arms_available':4,'original_inputs_unchanged':True})
guard('dictionary_does_not_autodetect_cases',original,'',('ValueError','repetition_gold_invalid'))
flat=build('flat-list-fixture',lambda cases:cases);old=before.score(*inputs(flat));new=fixed.score(*inputs(flat));save('flat-list-before-result',old);save('flat-list-fixed-result',new)
comparable=deepcopy(new);comparable.pop('gold_selection');comparable['code_sha256']['repetition_adapter']=old['code_sha256']['repetition_adapter'];assert comparable==old
checks.append({'probe':'default_list_legacy_report_equivalence','only_new_fields':['gold_selection','code_sha256.repetition_adapter']})
nested=build('escaped-nested-fixture',lambda cases:{'odd/key':{'a~b':[{'':cases}]},'metadata':{'unselected':True}})
result=fixed.score(*inputs(nested),gold_cases_pointer='/odd~1key/a~0b/0/');save('escaped-nested-result',result)
assert result['gold_selection']['cases_pointer']=='/odd~1key/a~0b/0/' and all(arm['pooled_source_label_report']['available']==4 for arm in result['arms'])
checks.append({'probe':'generic_escaped_nested_array_empty_key','planned_operations':8})
for name,ptr,err in [('missing_path','/missing',('KeyError',None)),('malformed_escape','/ca~2ses',('ValueError','invalid_json_pointer_escape')),('nonpointer_string','cases',('ValueError','json_pointer_required')),('null_pointer',None,('ValueError','json_pointer_required')),('selected_scalar','/invented_metadata/format',('ValueError','repetition_gold_invalid')),('leading_zero_index','/cases/00',('ValueError','json_pointer_array_index_invalid'))]:guard(name,original,ptr,err)
guard('raw_byte_hash_checked_before_missing_selector',original,'/missing',('ValueError','repetition_gold_snapshot_changed'),inputs(original)[-1]+b' ')
missing=build('missing-query-fixture',lambda cases:[dict(cases[0],judgments=cases[0]['judgments'][:1])]);guard('selected_missing_query_inventory',missing,'',('ValueError','repetition_gold_inventory_mismatch'))
def duplicate(cases):
 cases[0]['judgments'].append(deepcopy(cases[0]['judgments'][0]));return cases
dupe=build('duplicate-query-fixture',duplicate);guard('selected_duplicate_query_inventory',dupe,'',('ValueError','repetition_gold_inventory_mismatch'))
with tempfile.TemporaryDirectory(prefix='invented-gold-pointer-cli-') as td:
 output=Path(td)/'result.json';args=['score','--source-manifest',str(original/'source/manifest.json'),'--manifest',str(original/'projected/manifest.json'),'--output',str(output),'--gold-cases-pointer','/cases']
 for name in ['selection','policy','bundle','gold']:args+=['--'+name,str(original/(name+'.json'))]
 env=os.environ.copy();env.pop('PYTHONPATH',None);env.pop('TMPDIR',None)
 completed=subprocess.run([sys.executable,'-B','-m','loom.tools.structure.programme_repetition_v1',*args],cwd=root/'fixed-closure',env=env,capture_output=True)
 assert completed.returncode==0,(completed.stdout+completed.stderr).decode(errors='replace')
 assert json.loads(output.read_bytes())==fixed_dict and json.loads(completed.stdout)=={'new_model_calls':0,'planned_operations':8}
 checks.append({'probe':'actual_cli_runtime_selector','exit_code':0,'full_report_equals_api':True,'pythonpath_unset':True,'tmpdir_unset':True})
assert original_before==files(original)
summary={'status':'PASS','independent_probes':len(checks),'checks':checks,'provider_calls':0,'private_reads':0,'actual_gold_read':False,'actual_repeat_outputs_read':False,'before_source_sha256':sha(before_path.read_bytes()),'fixed_source_sha256':sha(Path(fixed.__file__).read_bytes()),'fixed_tests_sha256':sha(Path(fixtures.__file__).read_bytes())}
save('independent-pointer-review',summary);print(json.dumps(summary,sort_keys=True))
