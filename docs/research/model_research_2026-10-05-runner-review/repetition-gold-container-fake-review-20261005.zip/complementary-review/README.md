# Complementary gold-pointer fake peer

PASS exact9aec/7928 (independent52/52 focused). All fixtures here are invented; no actual gold/repetition responses/private/provider reads.

Run `python replay_saved_gold_pointer.py --companions ../peer-review/fixed-closure` from this archived directory, or pass an equivalent closure root containing loom/tools/structure and companion public schemas. The replay never regenerates fixture/source/prepared bytes. It compares retained preparation snapshots/ASTs, replays nine score/provenance/inventory/hash-before-selector/keyword-only probes and checks saved full successful report objects.

Identical case arrays reached through different pointers retain identical label reports with explicit pointer provenance; different selected gold arrays have different canonical selected-array SHA. The full raw container SHA stays bound. This is an explicit container reader choice, not a paid request, gold rewrite, threshold change or semantic oracle.
