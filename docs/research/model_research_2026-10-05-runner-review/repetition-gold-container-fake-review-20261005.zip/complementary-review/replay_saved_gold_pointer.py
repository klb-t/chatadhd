"""Read-only replay of retained mocked-gold fixtures; no fixture regeneration."""
from pathlib import Path
import argparse,ast,hashlib,importlib.util,json,sys,unittest.mock as mock
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--companions',type=Path,default=Path(__file__).resolve().parent/'../peer-review/fixed-closure');a=p.parse_args();root=a.archive.resolve();sys.path.insert(0,str(a.companions.resolve()));sha=lambda b:hashlib.sha256(b).hexdigest();report=json.loads((root/'REVIEW.json').read_bytes())
from loom.tools.structure import programme_repetition_v1 as companion
assert sha(Path(companion.__file__).read_bytes())==report['source_sha256']
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('retained_before4eb',root/'before4eb.py');fixed=load('retained_fixed9aec',root/'fixed9aec.py');assert sha((root/'fixed9aec.py').read_bytes())==report['source_sha256'];assert sha((root/'before4eb.py').read_bytes())=='4eb320b01d4dc4e12c4451d3bd81714e830a52f2de11defceadb2306a2dc6561'
def files(base):return {str(p.relative_to(base)):sha(p.read_bytes()) for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert files(root/'prepared-before4eb')==files(root/'prepared-fixed9aec')==files(root/'prepared')
args=(root/'source/manifest.json',(root/'selection.json').read_bytes(),(root/'policy.json').read_bytes(),root/'prepared/manifest.json',(root/'bundle.json').read_bytes(),(root/'invented-gold-container.json').read_bytes())
assert old.verify(*args[:3],args[3])==fixed.verify(*args[:3],args[3]);ba={x.name:ast.dump(x,include_attributes=False) for x in ast.parse((root/'before4eb.py').read_text()).body if isinstance(x,ast.FunctionDef)};fa={x.name:ast.dump(x,include_attributes=False) for x in ast.parse((root/'fixed9aec.py').read_text()).body if isinstance(x,ast.FunctionDef)}
for name in report['unchanged_function_ASTs']:assert ba[name]==fa[name]
checks=0
for name in ['first','same','different','missing','duplicate','not-array']:
    expected=report['results'][name]
    try:r=fixed.score(*args,gold_cases_pointer='/'+name+'/cases')
    except (ValueError,KeyError,TypeError) as e:assert not expected['accepted'] and str(e)==expected['error'] and type(e).__name__==expected['error_type']
    else:assert expected['accepted'] and r==json.loads((root/(name+'-result.json')).read_bytes())
    checks+=1
calls=[];pointer=fixed.graph.pointer
with mock.patch.object(fixed.graph,'pointer',side_effect=lambda v,p:(calls.append(p),pointer(v,p))[1]):
    try:fixed.score(*args[:-1],args[-1]+b' ',gold_cases_pointer='/first/cases')
    except ValueError as e:assert str(e)==report['results']['raw-hash-before-selection']['error'] and '/first/cases' not in calls
    else:raise AssertionError('raw hash mismatch admitted')
checks+=1
try:fixed.score(*args,'/first/cases')
except TypeError:checks+=1
else:raise AssertionError('selector not keyword-only')
try:old.score(*args)
except ValueError as e:assert str(e)==report['results']['before-full-container']['error'];checks+=1
else:raise AssertionError('before full container accepted')
assert report['immutable_fake_payload_hashes']=={'source':files(root/'source'),'prepared':files(root/'prepared'),'policy':sha((root/'policy.json').read_bytes()),'selection':sha((root/'selection.json').read_bytes()),'gold':sha((root/'invented-gold-container.json').read_bytes()),'bundle':sha((root/'bundle.json').read_bytes())}
print(json.dumps({'status':'PASS','retained_probes':checks,'unchanged_ASTs':8,'before_fixed_prepared_byte_equality':True,'no_fixture_regeneration':True,'no_private_gold_repeat_or_provider_reads':True}))
