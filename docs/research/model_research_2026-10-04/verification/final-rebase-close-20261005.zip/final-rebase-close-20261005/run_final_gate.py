"""Offline rebase closing gate: unchanged sources, incremental native build, full CTest."""
import hashlib, json, os, re, shutil, subprocess, sys, time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET
REPO=Path('/workspace/scratch/407fe6f6ff42/chatadhd')
BUILD=Path('/workspace/scratch/407fe6f6ff42/build')
OUT=REPO/'docs/research/model_research_2026-10-04/verification/final-rebase-close-20261005'
PREFIXES=('loom/include/','loom/src/','loom/tests/','loom/third_party/','loom/data/','loom/cli/','loom/server/','loom/tools/','engine/','core/')
SINGLE=('loom/CMakeLists.txt','loom/CMakePresets.json')
POLICIES=('docs/research/model_research_2026-10-04/billing/runner-policy.json','docs/research/model_research_2026-10-04/billing/endpoint-pricing-policy.json','docs/research/model_research_2026-10-04/native-results-policy.json','docs/research/model_research_2026-10-04/followup-results/stage3-policy.json','docs/research/model_research_2026-10-04/followup-results/stage4-policy.json','docs/research/model_research_2026-10-04/stage5/label-repetition-v1/repetition-policy.json')
BINS=('loom_tests','loom_compat_tool','loom_candidate_graph_native_tool','cli/loom','server/loom-server','libloom.so.0.1.0')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def snapshot():
    files={};protected=[]
    listed=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=REPO).decode().split('\0')
    for name in sorted(set(listed)):
        if not name or not (name in SINGLE or name.startswith(PREFIXES)): continue
        if 'real-holdout-key' in name: protected.append(name); continue
        p=REPO/name
        if p.suffix.lower() in ('.md','.rst') and not name.startswith('loom/tests/fixtures/'): continue
        if p.is_file(): files[name]=sha(p)
    bins={}
    for name in BINS:
        p=BUILD/name
        if p.exists(): bins[name]={'size':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)}
    return {'at':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),
        'functional_files_sha256':files,'file_count':len(files),
        'scope_rule':'Tracked and untracked functional/native/tool/data files; md/rst excluded except fixtures; six explicit public policies; protected real-holdout-key paths excluded without reading',
        'protected_paths_excluded_without_reading':len(protected),'binaries':bins,
        'public_policy_sha256':{name:sha(REPO/name) for name in POLICIES if (REPO/name).is_file()},
        'native_git_objects':{name:git('rev-parse','HEAD:'+name) for name in ('loom/CMakeLists.txt','loom/CMakePresets.json','loom/include','loom/src','loom/tests','loom/cli','loom/server','loom/third_party','loom/data','engine','core')}}
def run(cmd,log,env=None):
    start=time.monotonic(); proc=subprocess.Popen(cmd,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
    captured=[];last=start
    with (OUT/log).open('wb') as stream:
        for line in proc.stdout:
            captured.append(line);stream.write(line);stream.flush();os.fsync(stream.fileno())
            now=time.monotonic()
            if now-last>=25: print(line.decode(errors='replace').rstrip(),flush=True);last=now
        rc=proc.wait()
    raw=b''.join(captured);assert (OUT/log).read_bytes()==raw
    receipt={'command':cmd,'exit_code':rc,'elapsed_monotonic_seconds':time.monotonic()-start,'stdout_bytes':len(raw),'stdout_sha256':hashlib.sha256(raw).hexdigest(),'capture':'Full subprocess stdout and stderr, each line flushed and fsynced; final exact byte equality'}
    save(log+'.receipt.json',receipt)
    print(json.dumps(receipt),flush=True)
    if rc: print(raw[-3000:].decode(errors='replace'),flush=True)
    return rc
OUT.mkdir(parents=True,exist_ok=True)
before=snapshot();save('build-source-before.json',before)
shutil.copy2(BUILD/'CMakeCache.txt',OUT/'CMakeCache.before.txt')
configure=['/root/.local/bin/cmake','-S',str(REPO/'loom'),'-B',str(BUILD)]
rc=run(configure,'configure.raw.log')
if rc: save('receipt.json',{'gate_green':False,'phase':'configure','exit_code':rc});sys.exit(rc)
rc=run(['/root/.local/bin/cmake','--build',str(BUILD),'-j2'],'build.raw.log')
if rc: save('receipt.json',{'gate_green':False,'phase':'build','exit_code':rc});sys.exit(rc)
shutil.copy2(BUILD/'CMakeCache.txt',OUT/'CMakeCache.after.txt')
freeze=snapshot();save('ctest-source-before.json',freeze)
assert before['functional_files_sha256']==freeze['functional_files_sha256']
assert before['public_policy_sha256']==freeze['public_policy_sha256']
assert all(int(record['mode'],8)&0o111 for record in freeze['binaries'].values())
objects=list(BUILD.rglob('*.o'));invalid=[]
for p in objects:
    with p.open('rb') as f: magic=f.read(4)
    if magic!=b'\x7fELF': invalid.append({'path':str(p.relative_to(BUILD)),'bytes':p.stat().st_size,'magic_hex':magic.hex()})
save('object-integrity.json',{'object_count':len(objects),'invalid_objects':invalid})
if invalid: save('receipt.json',{'gate_green':False,'phase':'object_integrity','invalid_objects':invalid});sys.exit(1)
env=os.environ.copy();env.pop('PYTHONPATH',None);env.pop('TMPDIR',None)
env['LOOM_CANDIDATE_GRAPH_NATIVE_TOOL']=str(BUILD/'loom_candidate_graph_native_tool')
show=['/root/.local/bin/ctest','--test-dir',str(BUILD),'--show-only=json-v1']
showraw=subprocess.check_output(show,cwd=REPO,env=env);(OUT/'ctest-show-only.json').write_bytes(showraw)
inventory=json.loads(showraw);expected=[t['name'] for t in inventory['tests']]
assert len(expected)==len(set(expected)) and expected
cmd=['/root/.local/bin/ctest','--test-dir',str(BUILD),'-j2','--output-on-failure','--test-output-size-passed','10485760','--test-output-size-failed','10485760','--output-junit',str(OUT/'ctest.junit.xml')]
rc=run(cmd,'ctest.raw.log',env)
for name in ('LastTest.log','LastTestsFailed.log'):
    p=BUILD/'Testing/Temporary'/name
    if p.exists(): shutil.copy2(p,OUT/name)
after=snapshot();save('ctest-source-after.json',after)
text=(OUT/'LastTest.log').read_text()
blocks=re.findall(r'^\d+/\d+ Testing: ([^\n]+)\n(.*?)(?=^\d+/\d+ Testing: |\Z)',text,re.M|re.S)
def counts(name,body):
    r={'name':name}
    n=re.search(r'\[doctest\] test cases:\s*(\d+)\s*\|\s*(\d+) passed\s*\|\s*(\d+) failed\s*\|\s*(\d+) skipped',body)
    if n: r['native']=list(map(int,n.groups()))
    a=re.search(r'\[doctest\] assertions:\s*(\d+)\s*\|\s*(\d+) passed\s*\|\s*(\d+) failed',body)
    if a: r['assertions']=list(map(int,a.groups()))
    p=re.findall(r'^Ran (\d+) tests? in ',body,re.M)
    if p: r['python']=int(p[-1])
    r['python_skips']=sum(map(int,re.findall(r'skipped=(\d+)',body)))
    r['explicit_SKIP_markers']=bool(re.search(r'\bSKIP\b',body))
    if name=='cli.smoke': r['smoke_complete']='cli smoke: ok' in body
    if name=='server.smoke': r['smoke_complete']=all(m in body for m in ['OK: all loom-server smoke checks passed','OK: loom-server auth checks passed'])
    return r
last={n:counts(n,b) for n,b in blocks};xmlroot=ET.parse(OUT/'ctest.junit.xml').getroot();xmlcases=xmlroot.findall('.//testcase')
xml={c.attrib['name']:counts(c.attrib['name'],c.findtext('system-out') or '') for c in xmlcases}
native=[r for r in last.values() if 'native' in r];python=[r for r in last.values() if 'python' in r];smokes=[r for r in last.values() if 'smoke_complete' in r]
raw=(OUT/'ctest.raw.log').read_bytes()
console=re.findall(rb'^\s*\d+/\d+ Test\s+#\d+: ([^ ]+)\s+.*?Passed',raw,re.M)
changes=sorted(n for n in set(before['functional_files_sha256'])|set(after['functional_files_sha256']) if before['functional_files_sha256'].get(n)!=after['functional_files_sha256'].get(n))
conditions={
 'ctest_exit_zero':rc==0,'dynamic_inventory_all_entries_executed':set(expected)==set(last)==set(xml) and len(blocks)==len(expected)==len(xmlcases),
 'complete_LastTest_JUnit_per_entry_summaries_match':last==xml,
 'LastTest_all_passed':all('Test Passed.' in b for _,b in blocks),
 'no_JUnit_failure_error_skip':all(not c.findall('failure') and not c.findall('error') and not c.findall('skipped') for c in xmlcases),
 'every_unit_suite_positive_case_count':all(r.get('native',[0])[0]>0 if 'native' in r else r.get('python',0)>0 for r in last.values() if 'smoke_complete' not in r),
 'native_cases_and_assertions_all_passed':all(r['native'][0]==r['native'][1] and r['native'][2]==0 and r['assertions'][0]==r['assertions'][1] and r['assertions'][2]==0 for r in native),
 'two_smokes_complete':len(smokes)==2 and all(r['smoke_complete'] for r in smokes),
 'no_explicit_or_python_skip_events':all(not r['python_skips'] and not r['explicit_SKIP_markers'] for r in last.values()),
 'complete_console_inventory':len(console)==len(set(console))==len(expected) and {n.decode() for n in console}==set(expected),
 'functional_sources_unchanged':not changes,'public_policies_unchanged':before['public_policy_sha256']==after['public_policy_sha256'],
 'binaries_unchanged_during_CTest':freeze['binaries']==after['binaries']}
receipt={'gate_green':all(conditions.values()),'conditions':conditions,'head_at_start':before['head'],'head_at_end':after['head'],'fresh_main_base':'e4109df','build':'Existing build incrementally reconfigured and rebuilt from current rebased native inputs; no clean-build or full-matrix claim',
 'ctest_entries':len(expected),'native_suites':len(native),'native_cases':sum(r['native'][0] for r in native),'native_assertions':sum(r['assertions'][0] for r in native),'unittest_suites':len(python),'unittest_cases':sum(r['python'] for r in python),'smoke_suites':len(smokes),
 'unit_cases_total':sum(r['native'][0] for r in native)+sum(r['python'] for r in python),'functional_files_unchanged':len(before['functional_files_sha256']),'public_policies_unchanged':len(before['public_policy_sha256']),'functional_changed_paths':changes,
 'elapsed_seconds':float(re.search(rb'Total Test time \(real\) = ([0-9.]+) sec',raw).group(1)),
 'ctest_environment_adjustments':{'PYTHONPATH':'unset','TMPDIR':'unset','LOOM_CANDIDATE_GRAPH_NATIVE_TOOL':'explicit build target path'},'per_entry_counts':last}
save('receipt.json',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k!='per_entry_counts'},indent=2),flush=True)
sys.exit(0 if receipt['gate_green'] else 1)
