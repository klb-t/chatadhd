"""Verify captured bytes; do not load a provider or follow references."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_bytes())
for row in manifest['files']:
    path = root / row['path']
    assert path.resolve().is_relative_to(root), row['path']
    raw = path.read_bytes()
    assert len(raw) == row['bytes'], row['path']
    assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
print('Verified', len(manifest['files']), 'retained files')
