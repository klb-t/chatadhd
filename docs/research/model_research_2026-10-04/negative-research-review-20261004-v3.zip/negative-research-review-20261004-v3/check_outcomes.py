"""Assert the seventh negative control and unchanged accepted projection."""
import hashlib
import json
from pathlib import Path
import sys

before, after = [json.loads(Path(p).read_bytes()) for p in sys.argv[1:]]
assert before['tool_sha256'] == '2b8c0bc37c5013363ca43f9988cb0b76860f27513c7a90e560403ff15e45ae71'
assert after['tool_sha256'] == '537589147b8548a86c68de1a9726b6fb423e52aee02ce2a185232ad83a9943b6'
assert before['outcome']['actual'] == 'accepted'
assert (before['outcome']['metric']['numerator'], before['outcome']['metric']['denominator']) == (1, 1)
assert after['outcome']['actual'] == 'rejected'
assert after['outcome']['error'] == 'planned_identity_selection_must_use_identity_pointer'
for outcome in (before, after):
    assert outcome['new_provider_calls'] == outcome['credential_reads'] == 0
root = Path(__file__).resolve().parent
old = (root / 'final-before/packet.json').read_bytes()
new = (root / 'final-after/packet.json').read_bytes()
assert old == new
assert hashlib.sha256(new).hexdigest() == '62fe32c0ac26fa13df69d79545b83a7555d58d50c889e8b8722cf3426964956a'
print('Seventh negative control corrected; accepted packet bytes unchanged')
