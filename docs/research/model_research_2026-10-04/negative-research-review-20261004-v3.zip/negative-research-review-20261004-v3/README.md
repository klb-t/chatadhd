# Negative research review supplementary archive v3

This preserves the seventh negative control and includes the unchanged complete
six-control archive as `previous-six-negatives.zip`. All data is public source,
saved public research receipts or separately authored synthetic mechanism input.
No provider, credential, private export or sealed holdout was accessed. These
results measure arithmetic and projection integrity, not model quality.

The generic metric exporter used `len(match.one_of)` as its planned-identity
denominator without checking that the match pointer selected identities. With
two records in arm `a`, one pass and one failure, `identity_pointer=/id` and
`match={pointer:/arm, one_of:[a]}` yielded 1/1 rather than 1/2. One arm label was
silently mistaken for one planned event. Before output and exact source bytes
are retained. The correction rejects this ambiguous input as
`planned_identity_selection_must_use_identity_pointer`; literal planned-ID
selection still includes missing IDs, and the existing `equals` group filter
still counts both selected records as 1/2.

| Checkpoint | Exporter SHA-256 | Evidence |
|---|---|---|
| Before | `2b8c0bc37c5013363ca43f9988cb0b76860f27513c7a90e560403ff15e45ae71` | Full `source-before/`, `final-before/`, `observed-before.json` |
| After | `537589147b8548a86c68de1a9726b6fb423e52aee02ce2a185232ad83a9943b6` | Full `source-after/`, `final-after/`, `observed-after.json` |

The actual accepted configuration already used literal `/request_id` selectors.
Its packet remains byte-for-byte unchanged at SHA-256
`62fe32c0ac26fa13df69d79545b83a7555d58d50c889e8b8722cf3426964956a`.
Independent review verified 60 unique scripted events (36 retained old frontier,
12 new Stage 3 and 12 new Stage 4), distinct actual scripted producers and
intended real configurations, all raw receipt source hashes, and the original
two Jev ModelProfiles without modification or fictitious new models. The
corrected focused tests pass 14/14. Model semantic quality remains unmeasured
for scripted events; existing profile metrics keep their original dates and
explicitly rebound saved-report evidence.

Each before/after artifact directory preserves all five full output files,
including the 9.7 MB packet with its embedded exact receipt texts. The source
snapshots include the exporter, builder, vocabulary, tests, packet codec,
accounting helper, existing ModelProfile helper and both shared/native schemas.
The negative reproducer closes the exporter's imports using these captured
bytes. It performs no discovery, campaign build, Git command or network call.
`INITIAL_CAPTURE.json` retains the initial source/output receipt;
`MANIFEST.json` lists final paths, byte counts and SHA-256 hashes, excluding only
itself. `ENVIRONMENT.json` records Python and jsonschema package versions.

The nested six-control ZIP remains at SHA-256
`27d54f67e786046548b42834833f7ede4f88c8bae94d5bb621d7712c1be798e8`;
its contained first five-control ZIP is unchanged. No failed input or old
artifact was overwritten by a corrected result.

## Offline reproduction

With Python 3.11 or newer and `jsonschema` installed, extract this archive and
run from its root; every output filename must be new:

```bash
python3 verify_manifest.py
python3 reproduce.py --source before --output /tmp/denominator-before-new.json
python3 reproduce.py --source after --output /tmp/denominator-after-new.json
python3 check_outcomes.py /tmp/denominator-before-new.json /tmp/denominator-after-new.json
```

To reproduce the other six controls, separately extract
`previous-six-negatives.zip` and follow its preserved README. All declared
snapshots, exact inputs, observations and negative results remain available.
