"""Reproduce saved denominator bug from public source; no provider or keys."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', choices=['before', 'after'], required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
sys.path.insert(0, str(bundle / ('source-' + args.source)))
tool = importlib.import_module('loom.tools.structure.method_graph_export_v1')
fixture = json.loads((bundle / 'inputs.json').read_bytes())
source = tool.source_record('fixture.json', b'{}', '2026-10-04')
try:
    metric = tool.make_metric(fixture['specification'], fixture['receipt'], source)
    outcome = {'actual': 'accepted', 'metric': metric}
except ValueError as exc:
    outcome = {'actual': 'rejected', 'error': str(exc)}
result = {'tool_sha256': hashlib.sha256(Path(tool.__file__).read_bytes()).hexdigest(),
          'inputs': fixture, 'source': args.source, 'outcome': outcome,
          'new_provider_calls': 0, 'credential_reads': 0,
          'test_kind': 'synthetic_mechanism_not_model_quality'}
with args.output.open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(outcome, indent=2))
