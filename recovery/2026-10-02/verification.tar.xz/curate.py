"""Build a reversible handoff selection from the pinned public source tree."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/workspace/scratch/04bea79bdb97/chatadhd')
OUT = ROOT.parent
SOURCE = 'af3c81a5ddce70bdf4346a2c8c808ce6cc97b4d0'
paths = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', SOURCE], cwd=ROOT, text=True).splitlines())
main_paths = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', 'origin/main'], cwd=ROOT, text=True).splitlines())
reads = set(json.loads((OUT / 'fixture-read-paths.json').read_text()))
keep = reads | main_paths
required = {
    'docs/research/OWNER_CLARIFICATION_2026-09-30.md',
    'docs/research/THREAT_MODEL_2026-09-30.md',
    'docs/research/CHAT_KNOWLEDGE_CONTEXT_2026-09-30.md',
    'docs/research/CONTEXT_SCOPE_DETAIL_2026-09-30.md',
    'docs/research/retrieval_exploration_v1/SOURCE_PROJECTION_CONTRACT_2026-09-30.md',
    'docs/research/coordination_runtime_v1/README.md',
    'docs/research/RESULTS_2026-09-28.md',
    'docs/research/SEEDING_PROTOCOL_2026-09-29.md',
    'docs/research/JEV_LIVE_PROTOCOL_2026-09-28.md',
}
keep |= required & paths
keep |= {p for p in paths if p.startswith(('docs/research/w3_directed_commitment_v1/prepared_final/', 'docs/research/w6_evidence_2026-09-30/'))}
keep |= {p for p in paths if p.startswith('docs/research/') and p.endswith('.py')}
keep |= {p for p in paths if p.startswith('docs/research/handoff_2026-10-01/') and not p.endswith('saved_cost_audit.json')}

# Literal file references in retained code/configuration and frozen manifests.
# Directory constants are not an instruction to retain every historical run.
pattern = re.compile(r'(?:docs|loom|engine|core)/[A-Za-z0-9_./+@-]+')
for p in paths:
    if p.endswith(('.py', '.cpp', '.h', '.json', '.mjs', '.ts', '.tsx')) and not p.startswith(('docs/research/', 'docs/coordination/')):
        for ref in pattern.findall((ROOT / p).read_text(errors='replace')):
            if ref in paths:
                keep.add(ref)

todo = list(keep)
visited = set()
def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key, val in value.items():
            yield key
            yield from strings(val)
    elif isinstance(value, list):
        for val in value:
            yield from strings(val)

while todo:
    p = todo.pop()
    if p in visited or not p.endswith('.json'):
        continue
    visited.add(p)
    try:
        values = list(strings(json.loads((ROOT / p).read_text())))
    except (ValueError, OSError):
        continue
    for text in values:
        for ref in [text, *pattern.findall(text)]:
            candidates = [ref, str(Path(p).parent / ref)]
            for candidate in candidates:
                if candidate in paths and candidate not in keep:
                    keep.add(candidate)
                    todo.append(candidate)

obsolete = {'docs/HANDOFF_2026-09-28.md', 'docs/CODEX_HANDOFF_2026-09-28.md',
            'docs/HANDOFF_SOL_2026-09-29.md', 'docs/HANDOFF_CONTINUATION_2026-09-30.md',
            'docs/WORK_RECOVERY_2026-09-28.md', 'docs/WORK_STATUS_2026-09-28.md',
            'docs/GPT_OFFLINE_TASKS_2026-09-29.md'}
candidates = {p for p in paths if p.startswith(('docs/research/', 'docs/coordination/', 'loom/tools/seeding/results/'))}
candidates |= obsolete & paths
candidates |= {p for p in paths if p.startswith('loom/tools/structure/') and not p.endswith(('.py', '.md'))
               and any(x in p for x in ('/first', '/native_baseline/', '/native_first/', '/diagnostic', '/results'))}
removed = sorted(candidates - keep)
retained = sorted(candidates & keep)
manifest = {'source_commit': SOURCE, 'main_base': subprocess.check_output(['git','rev-parse','origin/main'], cwd=ROOT,text=True).strip(),
    'method': 'runtime Python file reads plus explicit current contracts and frozen file-reference closure; final uninstrumented CTest required',
    'all_original_main_paths_preserved': not bool(main_paths & set(removed)),
    'retained_fixture_or_contract_paths': retained,
    'archived': [{'path': p, 'bytes': (ROOT/p).stat().st_size, 'sha256': hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in removed]}
(OUT/'curation-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive_files':len(removed),'archive_bytes':sum(p['bytes'] for p in manifest['archived']),
                  'retained_fixture_or_contract_paths':len(retained),'original_main_paths':len(main_paths)}))
if '--apply' in sys.argv:
    backup = OUT/'archived-local'
    for p in removed:
        dst = backup/p
        dst.parent.mkdir(parents=True,exist_ok=True)
        (ROOT/p).rename(dst)
