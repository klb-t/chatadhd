from pathlib import Path
import hashlib,json,statistics

s=Path('/workspace/scratch/04bea79bdb97')
b=json.loads((s/'evidence/n2-baseline/report.json').read_text())
c=json.loads((s/'evidence/n2-candidate/report.json').read_text())
assert len(b['cases'])==len(c['cases'])==18
rows=[]
for before,after in zip(b['cases'],c['cases']):
    assert before['name']==after['name']
    assert before['exit_code']==after['exit_code']==0
    assert all(after[k] for k in ['exact_baseline_output','exact_baseline_seed','exact_baseline_request'])
    x,y=before['measurement'],after['measurement']
    assert len(x['calls'])==len(y['calls'])==3
    assert all(z['same_as_cold'] for z in x['calls']+y['calls'])
    row={'case':before['name'],'claims':x['size'],'theses':x['theses'],'channel':x['channel'],'exact_parity':True}
    for name,m in [('baseline',x),('candidate',y)]:
        row[name]={
            'cold_wall_ms':m['calls'][0]['native_wall_ns']/1e6,
            'warm_wall_median_ms':statistics.median(q['native_wall_ns'] for q in m['calls'][1:])/1e6,
            'cold_cpu_ms':m['calls'][0]['process_cpu_ns']/1e6,
            'warm_cpu_median_ms':statistics.median(q['process_cpu_ns'] for q in m['calls'][1:])/1e6,
            'cold_rss_delta_kib':m['calls'][0]['current_rss_delta_kib'],
            'warm_rss_delta_kib':[q['current_rss_delta_kib'] for q in m['calls'][1:]],
            'max_process_peak_rss_kib':max(q['peak_rss_after_decode_kib'] for q in m['calls'])}
    row['warm_wall_ratio']=row['baseline']['warm_wall_median_ms']/row['candidate']['warm_wall_median_ms']
    row['warm_cpu_ratio']=row['baseline']['warm_cpu_median_ms']/row['candidate']['warm_cpu_median_ms']
    rows.append(row)
result={'schema':'loom.n2.matched_cache_ablation/1','protocol_commit':'9626969bce806b2270d764ebdea3a8e139453de3',
        'protocol_sha256':hashlib.sha256((s/'n2-protocol.md').read_bytes()).hexdigest(),
        'instrument_sha256':c['instrument_sha256'],'baseline_library_sha256':b['library_sha256'],
        'candidate_library_sha256':c['library_sha256'],'cases':rows,'exact_parity_cases':18,
        'calls_per_arm':54,'remote_model_calls':0,'replicates':'one ordered paired matrix, one cold and two warm calls per cell'}
p=s/'chatadhd/docs/verification/2026-10-02';p.mkdir(parents=True,exist_ok=True)
(p/'n2-summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# N2 TF-IDF cache: matched ablation, 2026-10-02','',
'All 18 paired cells have identical seed, request and output bytes. All 54 calls',
'per arm completed; each cell retains one cold and two identical warm outputs.',
'No provider was called. This is computational reuse, not a model-quality result.','',
'The protocol was published before measurement at `9626969bce806b2270d764ebdea3a8e139453de3`.',
'The baseline is the same recovered source with only the production changes of',
'`f899559` reversed, not the originally proposed older integration revision.',
'Both arms use GCC 13, Debug `-O0 -g0`, bundled SQLite and warnings as errors.',
'The unchanged instrument is `loom/tools/benchmarks/context_candidate_cost_v2.py`.',
'Baseline ran first; candidate second. No build/test ran concurrently.','',
'| Claims | Theses | Channel | Cold wall ms, base → cache | Warm wall ms, base → cache | Warm CPU ms, base → cache | Warm wall ratio |',
'|---:|---:|---|---:|---:|---:|---:|']
for row in rows:
    x,y=row['baseline'],row['candidate']
    pair=lambda k:f"{x[k]:.2f} → {y[k]:.2f}"
    lines.append(f"| {row['claims']} | {row['theses']} | {row['channel']} | {pair('cold_wall_ms')} | {pair('warm_wall_median_ms')} | {pair('warm_cpu_median_ms')} | {row['warm_wall_ratio']:.2f}× |")
lines += ['', 'Warm values are medians of two observations. The ratio is baseline/cache,',
'so above 1 means the cache arm was faster in this run. Missing-channel controls',
'measure unrelated path variability; their ratios are not cache benefits.',
'The JSON summary records CPU, cold/warm RSS deltas and process peaks for every',
'cell. Full per-call measurements, fixture bytes, first diagnostics and both',
'output sets are in the recovery archive. RSS is a process snapshot, not exact',
'cache-owned memory. This single fixed-order Debug run cannot establish release',
'throughput, confidence intervals, broad workload gains or model accuracy.',
'The original interrupted diagnostic remains separate and was not relabelled.','']
(p/'N2_TFIDF.md').write_text('\n'.join(lines))
print(json.dumps({'paired_cases':18,'calls_per_arm':54,'tfidf_warm_wall_ratio_range':[min(x['warm_wall_ratio'] for x in rows if x['channel']=='tfidf'),max(x['warm_wall_ratio'] for x in rows if x['channel']=='tfidf')],'control_warm_wall_ratio_range':[min(x['warm_wall_ratio'] for x in rows if x['channel']!='tfidf'),max(x['warm_wall_ratio'] for x in rows if x['channel']!='tfidf')]}))
